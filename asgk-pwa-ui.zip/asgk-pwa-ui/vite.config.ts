import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'
import svgr from 'vite-plugin-svgr'
import { viteStaticCopy } from 'vite-plugin-static-copy'
// @ts-expect-error TODO: поковырять tsconfig, связано с allowSyntheticDefaultImports
import path from 'path'

export default defineConfig({
    resolve: {
        alias: {
            '@app': `${path.resolve(__dirname, './src/app')}`,
            '@pages': `${path.resolve(__dirname, './src/pages')}`,
            '@widgets': `${path.resolve(__dirname, './src/widgets')}`,
            '@features': `${path.resolve(__dirname, './src/features')}`,
            '@entities': `${path.resolve(__dirname, './src/entities')}`,
            '@shared': `${path.resolve(__dirname, './src/shared')}`
        },
        extensions: [
            '.js',
            '.ts',
            '.jsx',
            '.tsx',
            '.json',
            '.scss'
        ],
    },
    plugins: [
        react(),
        svgr({
            include: ['**/*.svg', '**/*.svg?react'],
            exclude: './src/shared/assets/systemLogo/*.svg',
            svgrOptions: {
                icon: true,
            },
        }),
        viteStaticCopy({
            targets: [
                {
                    src: 'pwa/*',
                    dest: 'pwa/',
                },
                {
                    src: 'service-worker.js',
                    dest: '',
                },
                {
                    src: 'devops_config/*',
                    dest: 'devops_config/',
                },
                {
                    // Файл нужен, чтобы не было одного из инцидентов.
                    // Если он пустой, то мы прошли какие-то проверки).
                    // То есть он всегда должен быть пустым) ничего не пишите туда
                    src: 'start_page.html',
                    dest: '',
                },
            ],
        }),
    ],
    base: '/',
    build: {
        sourcemap: true,
        emptyOutDir: true,
        outDir: 'public',
        chunkSizeWarningLimit: 100,
        assetsInlineLimit: 0,
        rollupOptions: {
            output: {
                inlineDynamicImports: false,
                assetFileNames: (assetInfo) => {
                    try {
                        if (
                            assetInfo?.name && assetInfo.name.split('.').at(-1) === 'woff2'
                        ) {
                            // Если это шрифты - для них убираем хэш из итогового названия
                            return 'assets/fonts/[name][extname]'
                        }
                    } catch (e: unknown) {
                        console.log(e as Error)
                    }
                    return 'assets/[name]-[hash][extname]'
                },
            },
            onwarn (warning, warn) {
                if (warning.code === 'MODULE_LEVEL_DIRECTIVE') {
                    return
                }
                warn(warning)
            },
        },
    },
})
