# Frontend-репозиторий проекта МП АСГК (Голос Клиента)

## Содержание

- [О проекте](#about)
- [Установка и запуск](#getting_started)
- [SberMock](#sbermock)
- [Команды используемые на проекте](#commands)
- [Ветвление и правила оформления Pull Request](#how_to_contribute)
- [Установка и запуск backend-приложения](#backend)
- [Подключение к БД](#database)
- [Полезные ссылки](#links)
- [Контакты команды](#team_info)

---
<a name="about"></a>
## О проекте

Frontend-репозиторий проекта МП АС Голос.

МП АС Голос является мобильной версией E2E системы работы с клиентской удовлетворенностью (CSI) - Голос Клиента

В МП реализован функционал:
- Аналитических дашбордов, позволяющих анализировать ключевые показатели клиентской удовлетворенности (CSI/NPS) в различных срезах (по продуктам, опросам, трайбам, сегментам)
- Вычитки комментариев, которые дают наши клиенты в проводимых опросах с целью поиска болей в продуктах и каналах
---

<a name="getting_started"></a>
## Предустановочные шаги
Для успешной установки зависимостей у Вас должен быть доступ к [sberosc.sigma.sbrf.ru](sberosc.sigma.sbrf.ru). 
* Если Вы не можете попасть в раздел Профиль ресурса, необходимо оформить заявку к соответсвующей АС [Confluence](https://confluence.sberbank.ru/pages/viewpage.action?pageId=8699849306#) 
* После получения доступа к sberosc.sigma.sbrf.ru В профиле вы сможете Перевыпустить токен, и скопировав Base64-токен использовать его для .npmrc _authToken=
* Использовать значение токен напрямую - небезопасно, следует скопировать всю строку //sberosc.sigma.sbrf.ru/repo/npm/:_authToken=*ВАШ_ТОКЕН* и добавить в Ваш локальный файл .npmrc 
* Также в Ваш локальный .npmrc должен содержать доступ к банковскому хранилищу пакетов //nexus-ci.delta.sbrf.ru/repository/npm-all/:_auth=ВАШ_ТОКЕН, где ВАШ_ТОКЕН Base64 строка содержащая _login:password_ вашей сигма УЗ

---
## Установка и запуск
Перед установкой зависимостей проверьте минимальные версии окружения и пакетного менеджера:
- node - 18.20.5
- npm - 10.8.2

Также, для их быстрого переключения, рекомендуется установить утилиту управления версиями инструментов JavaScript-тулчейна — [Volta](https://volta.sh/).

Для игнорирования сертификатов можно прописать следующее:
```
npm -g config set strict-ssl false
```

Клонирование репозитория
```
git clone ssh://git@stash.delta.sbrf.ru:7999/asgk/asgk-pwa-ui.git
```

Установка зависимостей
```
npm ci
```

Локальный запуск dev-стенда
```
npm run start
```

### Возможные проблемы при установке

Проблема установки определённого пакета,
например (rollup 2.79.1, vite и тп...) и получением в лог консоли ошибки code E403. 
При этом подзависимость действительно используется в проекте.

**Решение**

Вам следует в ручном режиме завести [заявку](https://jira.sberbank.ru/projects/AHD/issues/AHD-4644?filter=allopenissues) (JIRA-тикет) в пространстве SberOSC.
Для вашей УЗ SberOSC добавят доступ к указанным библиотекам и Вы сможете их установить. (временное решение проблемы)
Также можно перезаписать проблемную зависимость через свойство overrides в package.json или обновить версию пакета до безопасной, что указана в SberOSC.


---
<a name="sbermock"></a>
## Sbermock
На проекте используется банковская АС для мокирования данных Sbermock. У Вас должен быть доступ к [странице](https://sbermock.sigma.sbrf.ru/#/project/72059/emulations).
Если данная страница не открывается, вам следует завести заявку на получения доступа к АС в [СберДруге](https://confluence.sberbank.ru/pages/viewpage.action?pageId=5601264933).

### Возможные проблемы

Если доступ к АС Sbermock у Вас есть, но при выполнении скрипта `npm run start:sbermock` для запроса sudirLogin, Вы получаете ошибку NET::ERR_CERT_AUTHORITY_INVALID, 
то скорее всего это связано с отсутствием с [сертификата](https://confluence.sberbank.ru/pages/viewpage.action?pageId=13020569821). 

**Решение**

Просмотрев данные сертификата (SberCA Root Ext) Вы должны его СКАЧАТЬ и СОХРАНИТЬ на своём компьютере (для MacOS приложение "Связка ключей", выдав ему все разрешения со значением "Всегда доверять").

---
<a name="commands"></a>
## Команды используемые на проекте

* `npm run start` - сборка приложения для разработки
* `npm run start:sbermock` - сборка приложения для разработки с заглушками
* `npm run build:staging` - сборка для тестовой среды
* `npm run build` - сборка для промышленной среды
* `npm run test` - запуск тестов
* `npm run test:coverage` - запуск тестов и формирование отчета покрытия
* `npm run lint` - запуск инспекции директории src инструментами: eslint для js-файлов и stylelint для css-файлов
* `npm run lint:fix` - запуск форматирование директории src инструментами: eslint для js-файлов и stylelint для css-файлов
---
<a name="how_to_contribute"></a>
## Ветвление
* За доступами на push в репозиторий обращаться к: [Лобову Д.А.](dilobov@sberbank.ru) / [Митюшину С.М.](smikmityushin@sberbank.ru)
* Задачи разрабатывается на отдельных ветках под названием JIRA-тикета (CV-N)
* Ветка с задачей отводится от последнего релиза (release/releaseN) или develop, в итоге ветка с вашей задачей должна выглядеть CV-N
* После выполнения задачи, создаём PR(MR) по правилам ниже
* После апрува и мёржа вашей задачи в ветку develop, необходимо оформить новый PR в ветку dev-pipe, для раскатки на dev-стенде
* PR должен быть вида develop –> dev-pipe. Коммит должен быть оформлен аналогичным образом. Далее проходит раскатка на стенд из dev-pipe и тестирование задачи

### Правила оформления Pull Request

1. Коммит(ы) должен содержать названием JIRA-тикета и тезисное описание выполенных доработок н-р: "CV-3535: Фикс названия шрифта"
   PR оформляется в ветку develop
2. Короткое описание в самом PR-е и номер таски
3. Для влития ПР обязательно прохождения ревью от: [Митюшину С.М.](smikmityushin@sberbank.ru)
4. Успешное закрытие всех замечаний (будет отлично ставить реакцию "галочка")
---
<a name="backend"></a>

## Установка и запуск backend-приложения

Для работы с заглушками `npm run start:sbermock`

За доступами к backend-репозиторию обращаться к: [Лобову Д.А.](dilobov@sberbank.ru)

Инструкции по установке, настройке и запуске backend-приложения можно найти в readme файле в его репозитории
[ссылка на Backend-репозиторий](https://stash.delta.sbrf.ru/projects/ASGK/repos/back/browse)
---
<a name="database"></a>

## Подключение к БД

За доступами к базе данных, созданием учетки, и за созданием собственной копии dev-базы обращаться к: [Лобову Д.А.](dilobov@sberbank.ru)

Url для подключения через JDBC:
```
jdbc:postgresql://10.10.206.47:5433/asgk - это dev-база
jdbc:postgresql://10.10.206.47:5433/sigma_login - личная копия dev-базы
```
---
<a name="links"></a>

## Ссылки на ресурсы

* [Jira](https://jira.delta.sbrf.ru/secure/RapidBoard.jspa?rapidView=12144&view=planning&selectedIssue=CV-2489&issueLimit=100)
* [Confluence](https://confluence.delta.sbrf.ru/pages/viewpage.action?pageId=2573928260)
* [Стенд DEV (Мобильная версия)](https://tklds-voice0013.delta.sbrf.ru/)
* [Стенд ПРОМ (Мобильная версия)](https://golos.sberbank.ru)
* [APIStudio](https://apistudio-iamosh.sigma.sbrf.ru/#/projects/31072/specs)
* [Список миграций Postgres](https://confluence.delta.sbrf.ru/pages/viewpage.action?pageId=3520694012)
* [Jenkins](https://sbt-jenkins.delta.sbrf.ru/legacy/job/asgk/)
---

<a name="documentation"></a>

## Описание конкретных моментов разработки

* [CODE_OF_CONDUCT](documentation/CODE_OF_CONDUCT.md) - нормы написания кода

---

<a name="team_info"></a>

## Контакты команды

| Роль                     | ФИО                             | Почта Сигма                    |
|--------------------------|---------------------------------|--------------------------------|
| Владелец продукта        | Нагай Вадим Вадимович           | 21109076@sberbank.ru           |
| CJE                      | Анчевский Леонид Дмитриевич     | ldanchevskiy@sberbank.ru       |
| Lead Frontend-разработки | Митюшин Станислав Михайлович    | smikmityushin@sberbank.ru      |
| Frontend Разработчик     | Серебряков Олег Владимирович    | ovlserebryakov@sberbank.ru     |
| Frontend Разработчик     | Прыткин Артём Андреевич         | AAPrytkin@sberbank.ru          |
| Lead Backend-разработки  | Лобов Дмитрий Игоревич          | dilobov@sberbank.ru            |
| Backend Разработчик      | Мусин Алексий Леонидович        | aleomusin@sberbank.ru          |
| Backend Разработчик      | Созиашвили Давид Теймуразович   | dtsoziashvili@sberbank.ru      |
| Backend Разработчик      | Серков Егор Юрьевич             | eyserkov@sberbank.ru           |
| Инженер DevOps           | Горбачев Игорь Николаевич       | inigorbachev@sberbank.ru       |
| Инженер тестирования     | Наумов Александр Сергеевич      | alsergenaumov@sberbank.ru      |
| Data инженер             | Мирошниченко Денис Васильевич   | dvasmiroshnichenko@sberbank.ru |
| Data инженер             | Шадринцева Милена Андреевна     | mashadrintseva@sberbank.ru     |
| Data инженер             | Дашицыренов Зидабазр Дондокович | zddashitsyrenov@sberbank.ru    |
| Delivery Lead            | Устилко Владимир Александрович  | vaustilko@sberbank.ru          |
| Аналитик                 | Лампель Анна Игоревна           | AILampel@sberbank.ru           |
| Аналитик                 | Беляев Алексей Михайлович       | AMBelyaev@sberbank.ru          |
| Дизайнер                 | Барнацкая Елизавета Игоревна    | eibarnatskaya@sberbank.ru      |

Если у вас остались вопросы, можно писать на почту команды: [asgk_team@sberbank.ru](asgk_team@sberbank.ru)
