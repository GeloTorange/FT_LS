import { defineConfig, mergeConfig } from 'vitest/config'
import vitestConfig from './vite.config'
import react from '@vitejs/plugin-react'
import { resolve } from 'node:path'


export default mergeConfig(vitestConfig, defineConfig({
    plugins: [react()],
    test: {
        alias: {
            '@sbol/clickstream-agent': resolve('./src/__mocks__/clickstream-agent.ts'),
            'react-apexcharts': resolve('./src/__mocks__/react-apexcharts.tsx'),
            'react-device-detect': resolve('./src/__mocks__/react-device-detect.ts'),
            antd: resolve('./src/__mocks__/antd/index.tsx'),
        },
        globals: true,
        environment: 'jsdom',
        setupFiles: './setupTests.ts',
        includeSource: ['src/**/*.{ts,tsx,js,jsx}'],
        testTimeout: 20000,
        coverage: {
            provider: 'v8',
            reporter: ['text', 'html', 'clover', 'json', 'lcov'],
            enabled: true,
            exclude: [
                'src/__testsUtils__/**',
                'src/__mocks__/**',
                'src/App.tsx',
                'src/index.tsx',
                'src/react-app-env.d.ts',
                'src/vite-env.d.ts',
                'src/__mocks__/**',
                'src/**/__tests__/*.mock.{ts,tsx,js,jsx}'
            ],
            include: ['src/**/*.{ts,tsx,js,jsx}']
        },
        css: {
            modules: {
                classNameStrategy: 'non-scoped'
            }
        }
    },
}))
