import { useMemo } from 'react'

// Подумать над тем, чтобы получать сразу список значений.
// Получить значение css переменной
export const useGetCSSVar = (name: string) =>
    useMemo(() =>
        getComputedStyle(document.body).getPropertyValue(name)
    , [name])
