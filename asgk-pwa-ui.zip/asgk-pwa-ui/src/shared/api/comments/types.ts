export type CommentsParams = {
    filter?: {
        clientSegment?: string | null,
        versionSBOLId?: string | null,
        unitId?: string | null,
        tribeId?: string | null,
        productId?: string | null,
        triggerId?: string | null,
        triggerType?: string | null,
        trendId?: string | null,
        trendType?: string | null,
        marks?: number[] | null,
        cmId?: string | null,
        searchWord?: string | null,
        minLength?: string | null,
    }
    orderType?: string,
    orderDirection?: string
    page?: {
        pageSize: number,
        pageIndex: number
    }
    period?: {
        startDate: string,
        endDate: string
    },
    favoritesFirst?: boolean,
}

export interface CommentsData {
    comments: CommentsDataElem[],
    totalComments: number
}

export interface CommentsDataElem {
    answerDate: string
    comment: string
    csi: number
    eventDate: string
    question: string
    cmId: string
    commentId: string
    productName: string
}

export type CommentDetailsParams = {
    cmId: string
    commId: string
}

export interface CommentDetailsData {
    answerDate: string
    cmId: string
    commId: string
    eventDate: string
    productName: string
    question: string
    tribeName: string
    platformVersion: string
    platform: string
    triggerId: number
    triggerName: string
}
