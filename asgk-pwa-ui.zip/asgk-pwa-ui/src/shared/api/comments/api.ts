import requestWrapper from '../../system/requestWrapper'
import { DefaultAggregateType } from '../../types/filters'
import type { Response } from '../../types/response'
import { filterPeriod } from '../../utils/defaultDatesHelper'
import { removeEmpty } from '../../utils/useful'

import type {
    CommentsParams, CommentsData, CommentDetailsParams, CommentDetailsData,
} from './types'


export const getCommentsList = (
    {
        filter = {},
        orderType = 'ANSWER_DATE',
        orderDirection = 'DESC',
        page = {
            pageSize: 100,
            pageIndex: 1,
        },
        period = {
            startDate: filterPeriod[DefaultAggregateType].startDate,
            endDate: filterPeriod[DefaultAggregateType].endDate,
        },
        favoritesFirst = true,
    }: CommentsParams
) => requestWrapper<CommentsData>({
    url: '/mobile/comment/list',
    method: 'post',
    data: {
        filter: removeEmpty(filter),
        orderType,
        orderDirection,
        page,
        period,
        favoritesFirst,
    },
})

export function getCommentInfo (
    {
        cmId,
        commId,
    } : CommentDetailsParams,
): Promise<Response<CommentDetailsData>> {
    return requestWrapper({
        url: '/mobile/comment/details',
        method: 'post',
        data: {
            cmId,
            commId,
        },
    })
}
