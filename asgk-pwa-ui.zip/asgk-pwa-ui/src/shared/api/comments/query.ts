import { createApi, fakeBaseQuery } from '@reduxjs/toolkit/query/react'

import { getCommentsList } from './api'

// Тут будут все запросы по прямой речи
export const commentsApi = createApi({
    reducerPath: 'commentsList',
    baseQuery: fakeBaseQuery(),
    endpoints: (builder) => ({
        getCommentsList: builder.query({
            queryFn: getCommentsList,
        }),
        getInfinityCommentsList: builder.query({
            queryFn: getCommentsList,
            // Чтобы в кеше только одна запись была
            serializeQueryArgs: ({ endpointName }) => endpointName,
            // Логика объединения возвращаемых данных
            merge: (currentCache, newItems, { arg }) => {
                if (arg.page?.pageIndex === 1) {
                    return newItems
                }
                currentCache.comments.push(...newItems.comments)
                currentCache.totalComments = newItems.totalComments
                return currentCache
            },
            // Повторная загрузка при изменении аргументов
            forceRefetch ({ currentArg, previousArg }) {
                return currentArg !== previousArg
            },
        })
    })
})

export const {
    useGetCommentsListQuery,
    useGetInfinityCommentsListQuery,
} = commentsApi
