export { getCommentsList, getCommentInfo } from './api'
export type { CommentsParams, CommentsDataElem, CommentsData, CommentDetailsData } from './types'
export { commentsApi, useGetInfinityCommentsListQuery, useGetCommentsListQuery } from './query'
