import { createApi, fakeBaseQuery } from '@reduxjs/toolkit/query/react'

import { rtkQueryFnAxiosFactory } from '../utils'

import { getDislikeReasons } from './api'
import type { DislikeReason } from './types'

export const insightHubApi = createApi({
    reducerPath: 'insightHub',
    baseQuery: fakeBaseQuery(),
    endpoints: (build) => ({
        getDislikeReasons:  build.query<DislikeReason[], void>({
            queryFn: rtkQueryFnAxiosFactory(getDislikeReasons),
        }),
    })
})

export const { useGetDislikeReasonsQuery } = insightHubApi
