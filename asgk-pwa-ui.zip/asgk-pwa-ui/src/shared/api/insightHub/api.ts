import requestWrapper from '../../system/requestWrapper'

import type { DislikeReason, Question, AskParams, GetQuestionsParams, VoteParams } from './types'

const baseUrl = '/mobile/insight-hub'

export const askQuestion = (params: AskParams) =>
    requestWrapper.post<Question>(`${baseUrl}/ask`, params)

export const cancelQuestion = (questionId: string) =>
    requestWrapper.post<Question>(`${baseUrl}/question/${questionId}/cancel`)

export const voteQuestion = (questionId: string, params: VoteParams = {}) =>
    requestWrapper.post<Question>(`${baseUrl}/question/${questionId}/vote`, params)

export const getPreviousQuestions = (params?: GetQuestionsParams) =>
    requestWrapper.get<Question[]>(`${baseUrl}/questions`, { params })

export const getQuestion = (questionId: string, signal?: AbortSignal) =>
    requestWrapper.get<Question>(`${baseUrl}/question/${questionId}`, signal ? { signal } : {})

export const listenSse = (id: string, signal?: AbortSignal) =>
    requestWrapper.get<ReadableStream, ReadableStream>(`${baseUrl}/sse/${id}`, {
        responseType: 'stream',
        adapter: 'fetch',
        headers: {
            'Accept': 'text/event-stream'
        },
        ...(signal ? { signal } : {})
    })

export const getDislikeReasons = () =>
    requestWrapper.get<DislikeReason[]>(`${baseUrl}/dislike-reasons`)
