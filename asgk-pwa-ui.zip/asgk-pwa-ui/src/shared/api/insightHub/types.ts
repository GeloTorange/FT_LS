export type QuestionData =
    Record<string, string | number | boolean | string[] | number[] | boolean[] | undefined | null> | null | undefined

export interface AskParams {
    content?: string;
    data?: QuestionData;
    ttlSec?: number;
    dialogId?: string;
    primaryId?: string;
}

export interface VoteParams {
    like?: boolean;
    dislikeReasonId?: string;
    comment?: string;
}

export interface DislikeReason {
    id: string;
    reason: string;
    commentRequired?: boolean;
}

export interface GetQuestionsParams {
    before?: string;
    limit?: number;
    dialogId?: string;
}

export interface Question {
    dialogId: string;
    questionId: string;
    question: string;
    questionData?: QuestionData;
    questionedAt: string;
    answer?: string;
    answeredAt?: string;
    error?: string;
    status?: string;
    primaryId?: string;
    isLiked?: boolean;
}
