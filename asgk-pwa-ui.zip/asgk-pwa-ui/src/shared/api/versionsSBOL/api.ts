import requestWrapper from '../../system/requestWrapper'

import type {
    VersionsSBOLResponse,
} from './types'
// урл для получения версий
const baseURL = '/mobile/platformAppVersion'

export const getAllVersionsSBOL = () =>
    requestWrapper.get<VersionsSBOLResponse>(`${baseURL}/list`)
