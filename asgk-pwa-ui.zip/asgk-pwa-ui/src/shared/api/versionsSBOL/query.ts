import { createApi, fakeBaseQuery } from '@reduxjs/toolkit/query/react'

import type { OptionsListSelect } from '../../components/formInputs'
import type { AllListParams } from '../../types/api'
import { formattingVersion } from '../../utils/formatting'

import { getAllVersionsSBOL } from './api'
import { type VersionSBOLItem } from './types'

// Преобразуем версии для опций Select-а и не только
const transformToOptions = ({ platformVersion, platform, id }: VersionSBOLItem) => ({
    label: formattingVersion({ platform, version: platformVersion }),
    value: id.toString(),
})

export const versionsSBOLApi = createApi({
    reducerPath: 'versionsSBOL',
    baseQuery: fakeBaseQuery(),
    endpoints: (builder) => ({
        // Получение списка сегментов для фильтров.
        // AllListParams нужен для общей типизации для SelectFilterInput.
        getAllVersionsSBOLByFilter: builder.query<OptionsListSelect[], AllListParams>({
            queryFn: async () => {
                try {
                    const res = await getAllVersionsSBOL()
                    return {
                        data: res.data.map(transformToOptions)
                    }
                } catch (error) {
                    return { error }
                }
            }
        }),
    })
})

export const {
    useGetAllVersionsSBOLByFilterQuery,
} = versionsSBOLApi
