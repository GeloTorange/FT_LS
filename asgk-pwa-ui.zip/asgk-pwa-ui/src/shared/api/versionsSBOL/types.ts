export interface VersionSBOLItem {
    // В БД number, но в аналитике была строка. Подстраховался на оба варианта
    id: string | number
    platform: string
    platformVersion: string
}

export type VersionsSBOLResponse = VersionSBOLItem[]
