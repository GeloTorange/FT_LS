import type { GeneralFilter, GeneralParams } from '../../types/api'

export enum PainChangingDynamics {
    UP = 'UP',
    DOWN = 'DOWN',
    ZERO = 'ZERO',
}

export type PainsListParams = Pick<
    GeneralParams<
        Pick<GeneralFilter, 'tribeId' | 'productId' | 'measureId'> & {
            forMeasure?: boolean
        }>,
    'filter' | 'page'
>

type ScoreInfo = {
    score: number,
    dynamics: number,
    changingDynamics: PainChangingDynamics
}

export type PainsListDataItem = {
    productId: number
    productName: string
    painId: number,
    painName: string,
    driverName: string,
    tribeScore: ScoreInfo,
    productScore: ScoreInfo
    selected?: boolean
}

export type PainsListDataItemWithSelect = {
    value: number
    label: string
} & PainsListDataItem

export type PainsListData = {
    totalCount: number
    list: PainsListDataItem[]
}

export type PainScoringChart = {
    date: string,
    consultationTotal: number,
    appealTotal: number,
    detractorTotal: number,
    score: number
}

export type PainListMainStaticData = {
    productId: number,
    productName: string,
    painId: number,
    painName: string,
    driverName: string,
    trendId: string,
    chart: PainScoringChart[]
}

export type PainFileParams = {
    tribeId?: number,
    productId?: number
}

export type PainFileResponse = {
    exportTime: number,
    fileName: string,
    type: string,
    fileData: string
}

export type PainFileError = { exportTime: number } | boolean | undefined

export enum SCORING_PAIN_CHART_VALUE {
    tribe = 'TRIBE',
    product = 'PRODUCT',
}

export type PainListMainStaticReqParams = {
    painId: number,
    scoreFilter: SCORING_PAIN_CHART_VALUE
}
