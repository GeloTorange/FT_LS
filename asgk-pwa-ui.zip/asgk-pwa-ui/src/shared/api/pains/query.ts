import { createApi, fakeBaseQuery } from '@reduxjs/toolkit/query/react'

import { getErrorInCatch } from '../utils'

import { getPainFile, getPainListMainStatistic, getPainsList } from './api'
import type {
    PainFileParams,
    PainFileResponse,
    PainListMainStaticData,
    PainListMainStaticReqParams,
    PainsListDataItemWithSelect,
    PainsListParams,
} from './types'


export const painsApi = createApi({
    reducerPath: 'pains',
    baseQuery: fakeBaseQuery(),
    endpoints: (builder) => ({
        getInfinityPainsList: builder.query({
            queryFn: getPainsList,
            // Чтобы в кеше только одна запись была
            serializeQueryArgs: ({ endpointName }) => endpointName,
            // Логика объединения возвращаемых данных
            merge: (currentCache, newItems, { arg }) => {
                if (arg.page?.pageIndex === 1) {
                    return newItems
                }
                currentCache.list.push(...newItems.list)
                return currentCache
            },
            // Повторная загрузка при изменении аргументов
            forceRefetch ({ currentArg, previousArg }) {
                return currentArg !== previousArg
            },
        }),
        getPainListMainStatistic: builder.query<PainListMainStaticData, PainListMainStaticReqParams>({
            queryFn: getPainListMainStatistic,
        }),
        // данные для Select
        getPainsList: builder.query<PainsListDataItemWithSelect[], PainsListParams>({
            queryFn: async (arg, api, e) => {
                try {
                    const res = await getPainsList(arg, api, e)
                    if (res?.data?.list) {
                        return {
                            data: res.data.list.map((item) => ({
                                value: item.painId,
                                label: item.painName,
                                ...item
                            })),
                        }
                    }
                    throw new Error('Не пришли боли')
                } catch (err) {return getErrorInCatch(err)}
            },
        }),
        getPainFile: builder.query<PainFileResponse, PainFileParams>({
            queryFn: async (arg, api, e) => {
                try {
                    const res = await getPainFile(arg, api, e)
                    if (res?.error) {
                        return {
                            ...res,
                            error: res.data,
                        }
                    }
                    if (res?.data) {
                        return { ...res }
                    }
                    throw new Error('Не пришли данные по файлу реестра болей')
                } catch (err) {return getErrorInCatch(err)}
            },
            // не нужно кэшировать, потому что не знаем какой будет таймер с бэка
            keepUnusedDataFor: 0,
        })
    })
})

export const {
    useGetInfinityPainsListQuery,
    useGetPainListMainStatisticQuery,
    useGetPainsListQuery,
    useLazyGetPainFileQuery,
} = painsApi
