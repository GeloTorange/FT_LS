
import type { BaseQueryFn } from '@reduxjs/toolkit/query'

import requestWrapper from '../../system/requestWrapper'
import type { ErrorResponse } from '../../types/response'

import type {
    PainFileError,
    PainFileParams,
    PainFileResponse,
    PainListMainStaticReqParams,
    PainsListData,
    PainsListParams,
} from './types'

const baseUrl = '/mobile/pain'


export const getPainsList: BaseQueryFn<PainsListParams, PainsListData, ErrorResponse> = (
    data = {
        filter: {},
        page: {
            pageIndex: 1,
            pageSize: 100,
        },
    }
) => requestWrapper({
    url: `${baseUrl}/list`,
    method: 'post',
    data,
})


export const getPainListMainStatistic =
  ({ painId, scoreFilter }: PainListMainStaticReqParams) => requestWrapper({
      url: `${baseUrl}/list/mainStatistic`,
      method: 'post',
      data: {
          painId,
          scoreFilter
      },
  })

export const getPainFile: BaseQueryFn<
    PainFileParams, PainFileResponse, PainFileError
> = (data) => requestWrapper({
    url: `${baseUrl}/list/export`,
    method: 'post',
    data,
})
