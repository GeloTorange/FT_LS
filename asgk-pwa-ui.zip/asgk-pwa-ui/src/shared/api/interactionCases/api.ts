import requestWrapper from '../../system/requestWrapper'

import type { InteractionCaseEntity } from './types'

const baseUrl = '/mobile/interactionCase'
export const getInteractionCase = (id: string) => requestWrapper.get<InteractionCaseEntity>(`${baseUrl}/${id}`)
