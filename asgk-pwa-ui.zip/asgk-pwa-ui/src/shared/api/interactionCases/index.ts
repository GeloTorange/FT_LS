export { getInteractionCase } from './api'
export type { InteractionCaseEntity } from './types'