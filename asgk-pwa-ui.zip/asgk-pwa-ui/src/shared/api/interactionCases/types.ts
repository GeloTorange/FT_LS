export interface InteractionCaseEntity {
    appRowId: string,
    tribeName: string,
    factorica: string,
    productName: string,
    subProductName: string,
    subjectName: string,
    subSubjectName: string,
    channelName: string,
    reqNum: string,
    reqCreated: string
}