export const classifierFields = ['driverName', 'factorica'] as const
