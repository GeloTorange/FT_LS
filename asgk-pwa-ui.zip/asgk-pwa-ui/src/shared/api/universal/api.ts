import requestWrapper from '../../system/requestWrapper'
import type { Response } from '../../types/response'

import type { ChangeFavoriteData, ChangeFavoriteParams, BusinessStructureElement , ClassifierValue } from './types'


export function changeFavorite ({
    id,
    type,
    favorite,
}: ChangeFavoriteParams): Promise<Response<ChangeFavoriteData>> {
    return requestWrapper({
        url: '/mobile/change_favorite',
        method: 'post',
        data: {
            id,
            type,
            favorite,
        },
    })
}

export const getBusinessStructure = () =>
    requestWrapper.get<BusinessStructureElement[]>('/business-structure/getBusinessStructure')

export const getClassifierValues = (field: string) => requestWrapper.get<ClassifierValue[]>(`/classifier/${field}`)
