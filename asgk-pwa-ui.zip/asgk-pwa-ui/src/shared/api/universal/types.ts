import type { classifierFields } from './const'

export type ChangeFavoriteParams = {
    id: string,
    type: string,
    favorite: boolean,
}

export interface ChangeFavoriteData {
    favorite: boolean
    objectId: number
    objectType: string
}

export interface BusinessStructureElement {
    id: number | string;
    name: string;
    b2c?: boolean | null;
    level: number;
    children?: BusinessStructureElement[]
}

export type BusinessStructureMap = Record<number | string, BusinessStructureElement>

export interface BusinessStructure {
    structure: BusinessStructureElement[];
    units: BusinessStructureMap;
    tribes: BusinessStructureMap;
    directions: BusinessStructureMap;
    tribesByUnit: Record<number | string, BusinessStructureMap>;
    directionsByTribe: Record<number | string, BusinessStructureMap>;
}

export type ClassifierValue = string
export type ClassifierFields = typeof classifierFields[number]
export type Classifier = Record<ClassifierFields, ClassifierValue[]>
