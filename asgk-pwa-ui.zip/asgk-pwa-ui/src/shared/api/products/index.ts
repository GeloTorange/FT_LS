export { getProductListByTrends, getAllProducts } from './api'

export type {
    ProductListByTrendsParams,
    ProductInfo,
    ProductListByTrendsData,
    AllProductsData,
    AllProductsParams,
    TreeSelectType,
    StructureParams,
} from './types'

export {
    useGetAllProductsByFilterQuery,
    useGetProductListByTrendsQuery,
    productsApi,
    useGetStructureByTreeSelectQuery,
} from './query'
