import requestWrapper from '../../system/requestWrapper'
import { filterPeriod } from '../../utils/defaultDatesHelper'
import { removeEmpty } from '../../utils/useful'

import type {
    AllProductsData,
    AllProductsParams,
    ProductListByTrendsParams, UnitStructure,
} from './types'

const baseURL = '/mobile/product'

export const getProductListByTrends = ({
    filter = {},
    aggregateType = '',
    orderType = '',
    orderDirection = '',
    favoritesFirst = false,
    period = {
        startDate: filterPeriod[aggregateType].startDateShort,
        endDate: filterPeriod[aggregateType].endDate,
    },
    page = {
        pageIndex: 1,
        pageSize: 10,
    },
}: ProductListByTrendsParams) => requestWrapper({
    url: `${baseURL}/listByTrends/top`,
    method: 'post',
    data: {
        filter,
        aggregateType,
        orderType,
        orderDirection,
        favoritesFirst,
        period,
        page,
    },
})

export const getAllProducts = (
    data: AllProductsParams = { },
) => requestWrapper.post<AllProductsData>(
    `${baseURL}/list`,
    removeEmpty(data),
)

export const getStructure = () =>
    requestWrapper.get<UnitStructure[]>(`${baseURL}/getStructure`)
