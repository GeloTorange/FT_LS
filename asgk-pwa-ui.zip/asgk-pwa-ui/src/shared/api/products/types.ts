import type {
    AllListData,
    AllListParams,
    GeneralFilter,
    GeneralParams,
    ParentType,
} from '../../types/api'


export type ProductListByTrendsParams = GeneralParams<Pick<GeneralFilter,
    'trendType' | 'productId' | 'clientSegment' | 'triggerType' | 'triggerId' | 'tribeId'>>

export interface ProductListByTrendsData {
    totalCount: number,
    products: ProductInfo[]
}

export type ProductInfo = {
    id: number | null,
    name: string,
    parent: ParentType,
    index: number | null,
    indexIncr: number | null,
    indexIncrPct: number | null,
    isFavorite: boolean,
}

export type AllProductsParams = Pick<AllListParams, 'triggerId' | 'triggerType' | 'tribeId' | 'trendId'>

export type AllProductsData = Pick<AllListData, 'id' | 'product'>[]

export type UnitStructure = {
    unitId: number,
    unitName: string,
    tribes: TribeStructure[],
}

export type TribeStructure = {
    tribeId: number,
    tribeName: string,
    products: ProductStructure[],
}

export type ProductStructure = {
    productId: number,
    productName: string,
}

export interface TreeSelectType {
    label: string,
    value: string,
    disabled: boolean,
    children?: TreeSelectType[],
}

export type StructureParams = {
    isDisableTribe?: boolean
    isDisableProduct?: boolean
    isDisableUnit?: boolean
}

