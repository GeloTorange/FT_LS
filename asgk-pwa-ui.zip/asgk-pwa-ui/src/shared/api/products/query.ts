import { createApi, fakeBaseQuery } from '@reduxjs/toolkit/query/react'

import { stringifyValueForTree, TreeStructureTypes } from '@shared/utils/forTreeStructure'

import type { OptionsListSelect } from '../../components/formInputs'
import type { AllListParams } from '../../types/api'
import { rtkQueryFnAxiosFactory } from '../utils'

import { getAllProducts, getProductListByTrends, getStructure } from './api'
import type { ProductListByTrendsData, ProductListByTrendsParams, StructureParams, TreeSelectType } from './types'

export const productsApi = createApi({
    reducerPath: 'products',
    baseQuery: fakeBaseQuery(),
    endpoints: (builder) => ({
        // Получение вложенного списка Юнит-Трайб-Продукт
        getStructureByTreeSelect: builder.query<TreeSelectType[], StructureParams | void>({
            queryFn: async (disableParams) => {
                try {
                    const res = await getStructure()

                    return ({ data: res.data.map(unit => ({
                        label: unit.unitName,
                        value: stringifyValueForTree({
                            type: TreeStructureTypes.unitId, id: unit.unitId.toString()
                        }),
                        disabled: Boolean(disableParams?.isDisableUnit),
                        children: unit.tribes.map(tribe => ({
                            label: tribe.tribeName,
                            value: stringifyValueForTree({
                                type: TreeStructureTypes.tribeId, id: tribe.tribeId.toString()
                            }),
                            disabled: Boolean(disableParams?.isDisableTribe),
                            children: tribe.products.map(product => ({
                                label: product.productName,
                                value: stringifyValueForTree({
                                    type: TreeStructureTypes.productId, id: product.productId.toString()
                                }),
                                disabled: Boolean(disableParams?.isDisableProduct),
                            }))
                        })),
                    })) })
                } catch (error) {
                    return ({ error })
                }
            }
        }),
        // Получение списка сегментов для фильтров
        getAllProductsByFilter: builder.query<OptionsListSelect[], AllListParams>({
            queryFn: async (params) => {
                try {
                    const res = await getAllProducts(params)
                    return ({
                        data: res.data.map(({ product, id }) => ({
                            label: product,
                            value: id,
                        }))
                    })
                } catch (error) {
                    return ({ error })
                }
            }
        }),
        // Получение продукта
        getProductListByTrends: builder.query<ProductListByTrendsData, ProductListByTrendsParams>({
            queryFn: rtkQueryFnAxiosFactory(async (params) => getProductListByTrends(params))
        })
    })
})

export const {
    useGetStructureByTreeSelectQuery,
    useGetAllProductsByFilterQuery,
    useGetProductListByTrendsQuery,
} = productsApi
