import { removeEmpty } from '../../utils/useful'

import { commonConfig, setCommonConfig } from './common-config'
import { commonEvent } from './common-event'
import { createTracker } from './tracker'
import type { CommonConfig } from './types'

let isInitialized = false

export const analytics = {
    event: commonEvent,
}

export const initAnalytics = (initConfig: CommonConfig) => {
    if (!isInitialized) {
        try {
            /* comment: из конфига может прийти undefined */
            setCommonConfig(removeEmpty(initConfig))
            createTracker(commonConfig)
            isInitialized = true
        } catch (error: unknown) {
            if (process.env.NODE_ENV === 'development' && import.meta.env.VITE_ERROR_LOG_TOGGLER === 'ON') {
                // comment: Данный вывод логов необходим
                // eslint-disable-next-line no-console
                console.error(error, 'Не удалось создать счетчики')
            }
        }
    } else if (import.meta.env.VITE_ERROR_LOG_TOGGLER === 'ON'){
        // comment: Данный вывод логов необходим
        // eslint-disable-next-line no-console
        console.error('initAnalytics уже была вызвана ранее, повторный вызов запрещен')
    }
    return { ...analytics }
}

export const sendAnalyticEvent = (eventAction: string, value?: string) => analytics.event({ eventAction, value })
