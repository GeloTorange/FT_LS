import type { CommonConfig } from './types'

// НЕ ТРОГАТЬ
//
// psi: {
//     link: 'https://psiclickstream.testonline.sberbank.ru:8097/metrics/inner-partners/voice-client',
//     apiKey: '8e1c20fa7b313138bf95b236ec27dd959fc3e9f3e01200629a0fda655936bdb3',
//
// ift: {
//     link: 'https://iftmpclickstream.testonline.sberbank.ru:8097/metrics/inner-partners/voice-client',
//     apiKey: '868084e9d4c07adb41761327ec129d7fbe0a150414327f46450211cbc28ea708',
// },

const DEFAULT_URL = 'https://int.clickstream.sberbank.ru/metrics/inner-partners/voice-client'
const DEFAULT_API_KEY = 'b74ffe767d86fcc7979d56735eb27e8ac72663699630cd4d975dd65383f7792a'

export const commonConfig: CommonConfig = {
    userId: '',
    url: DEFAULT_URL,
    apiKey: DEFAULT_API_KEY,
    currentStand: '',
}


export const setCommonConfig = (nextConfig: Partial<CommonConfig>): void => {
    Object.assign(commonConfig, nextConfig)
}
