import { getTracker } from './tracker'
import type { Options } from './types'

export const commonEvent = (options: Options) => {
    try {
        const tracker = getTracker()

        tracker.event(options)

    } catch (error: unknown) {
        if (process.env.NODE_ENV === 'development' && import.meta.env.VITE_ERROR_LOG_TOGGLER === 'ON') {
            // comment: нужна тут ошибка
            // eslint-disable-next-line no-console
            console.error(error, 'Не удалось отправить метрику')
        }
    }

    return Promise.resolve([])
}
