import { ClickStream } from './ClickStreamTracker'
import type { CommonConfig } from './types'

let tracker: ClickStream

export const getTracker = (): ClickStream => tracker

export const createTracker = (config: CommonConfig): void => {
    tracker = new ClickStream({
        userId: config.userId,
        currentStand: config.currentStand,
    })
    // Object.assign(tracker, newTracker)
}
