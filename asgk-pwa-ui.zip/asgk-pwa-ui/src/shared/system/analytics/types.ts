export type ClickStreamProps = {
    userId: string,
    currentStand: string,
}

export type Options = {
    eventAction: string,
    value?: string,
}

export type CommonConfig = {
    url?: string,
    apiKey?: string,
    userId: string,
    currentStand: string,
}
