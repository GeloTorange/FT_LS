import { createHashHistory } from 'history'

export const customHistory = createHashHistory()
