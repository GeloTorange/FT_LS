import { MainTabsValues } from '../../types/main'


export const PAGE_ROUTES = {
    MAIN: '/',
    NEW_MAIN: '/new_main',
    NEW_CSI: `/new_main/?tab=${MainTabsValues.CSI}`,
    PAINS: '/pains',
    PAIN: '/pains/:painId',
    MEASURES: '/measures',
    MEASURE: '/measures/:measureId',
    CSI: `/?tab=${MainTabsValues.CSI}`,
    APPEALS: `/?tab=${MainTabsValues.APPEALS}`,
    CONSULTATIONS: `/?tab=${MainTabsValues.CONSULTATIONS}`,
    TRIGGERS: '/triggers',
    TRIGGER: '/triggers/:triggerId',
    TRENDS: '/trends',
    TREND: '/trends/:trendId',
    COMMENTS: '/comments',
    PROFILE: '/profile',
    TOPICS: '/topics',
    TOPICS_SUMMARY: '/summary',
    ADMINISTRATION: '/administration',
    ADMINISTRATION_TRENDS_PARAMS: '/administration/trends',
    ADMINISTRATION_TRIGGERS_PARAMS: '/administration/triggers',
    ADMINISTRATION_EXAMPLES_MANAGEMENT: '/administration/examples',
    ADMINISTRATION_CLASSIFIER: '/administration/classifier',
    ERROR_NETWORK: '/error/network',
    ERROR_REFRESH_TOKEN: '/error/refreshToken',
    ERROR_401: '/error/401',
    ERROR_404: '/error/404',
    ERROR_500: '/error/500',
    INDEFINITE_PATH: '*'
}
