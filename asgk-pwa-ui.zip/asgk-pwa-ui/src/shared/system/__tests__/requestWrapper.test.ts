import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import requestWrapper, { injectStore } from '../requestWrapper'
import { systemErrorNotification } from '@shared/system/notificationCustom'
import { changeStatus } from '@entities/appState'
import { customHistory, PAGE_ROUTES } from '../router'
import { APP_STATUSES } from '../appStatuses'

vi.mock('@shared/system/notificationCustom', () => ({
    systemErrorNotification: vi.fn(),
}))

vi.mock('@entities/appState', () => ({
    changeStatus: vi.fn(),
}))

vi.mock('../router', () => ({
    customHistory: {
        push: vi.fn(),
    },
    PAGE_ROUTES: {
        ERROR_401: '/error-401',
        ERROR_500: '/error-500',
    },
}))

vi.mock('../appStatuses', () => ({
    APP_STATUSES: {
        NETWORK_ERROR: 'NETWORK_ERROR',
    },
}))

vi.mock('axios', () => {
    const mockRequestInterceptor = {
        handlers: [],
        use: vi.fn((fulfilled, rejected) => {
            mockRequestInterceptor.handlers.push({ fulfilled, rejected })
        })
    }

    const mockResponseInterceptor = {
        handlers: [],
        use: vi.fn((fulfilled, rejected) => {
            mockResponseInterceptor.handlers.push({ fulfilled, rejected })
        })
    }

    return {
        default: {
            create: vi.fn(() => ({
                interceptors: {
                    request: mockRequestInterceptor,
                    response: mockResponseInterceptor,
                },
            })),
        },
    }
})

describe('requestWrapper', () => {
    const mockStore = {
        dispatch: vi.fn(),
    }

    const mockToken = 'test-token'
    const mockLocationHash = '#/test-path'

    beforeEach(() => {
        vi.clearAllMocks()
        injectStore(mockStore)

        Object.defineProperty(window, 'location', {
            value: {
                hash: mockLocationHash,
            },
            writable: true,
        })

        vi.stubGlobal('tokenAddToHeader', mockToken)
    })

    afterEach(() => {
        vi.unstubAllGlobals()
    })

    it('добавляет правильные заголовки в запрос', () => {
        const mockConfig = {
            headers: {}
        }

        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access
        const handler = requestWrapper.interceptors.request.handlers[0].fulfilled
        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        const newConfig = handler(mockConfig)

        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
        expect(newConfig.headers['Path-Name-In-The-Address-Bar']).toBe('')
        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
        expect(newConfig.headers.Authorization).toBe(undefined)
    })

    it('не добавляет Authorization если tokenAddToHeader отсутствует', () => {
        vi.stubGlobal('tokenAddToHeader', null)

        const mockConfig = {
            headers: {}
        }

        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access
        const handler = requestWrapper.interceptors.request.handlers[0].fulfilled
        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access
        const newConfig = handler(mockConfig)


        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
        expect(newConfig.headers.Authorization).toBeUndefined()
    })

    it('возвращает данные при успешном ответе без ошибки', () => {
        const mockResponse = {
            data: {
                error: false,
                message: 'Success',
                data: { id: 1 },
            },
        }

        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access
        const handler = requestWrapper.interceptors.response.handlers[0].fulfilled
        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access,
        @typescript-eslint/no-unsafe-call */
        const result = handler(mockResponse)

        expect(result).toEqual(mockResponse.data)
    })

    it('вызывает systemErrorNotification при ответе с ошибкой', () => {
        const mockResponse = {
            data: {
                error: true,
                message: 'Test error message',
            },
        }

        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access
        const handler = requestWrapper.interceptors.response.handlers[0].fulfilled
        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access,
      @typescript-eslint/no-unsafe-call */
        handler(mockResponse)

        expect(systemErrorNotification).toHaveBeenCalledWith({
            message: 'Произошла ошибка',
            description: 'Test error message',
        })
    })

    it('при ошибке сети (ERR_NETWORK) диспатчит NETWORK_ERROR', async () => {
        const mockError = {
            code: 'ERR_NETWORK',
            response: undefined,
        }

        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access
        const handler = requestWrapper.interceptors.response.handlers[0].rejected
        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access,
      @typescript-eslint/no-unsafe-call */
        await expect(handler(mockError)).rejects.toEqual(mockError)

        expect(mockStore.dispatch).toHaveBeenCalledWith(changeStatus(APP_STATUSES.NETWORK_ERROR))
    })

    it('при статусе 401/403 перенаправляет на страницу ошибки 401', async () => {
        const mockError = {
            response: {
                status: 401,
            },
        }

        // comment: нет типизации для тестов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access
        const handler = requestWrapper.interceptors.response.handlers[0].rejected
        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access,
      @typescript-eslint/no-unsafe-call */
        await expect(handler(mockError)).rejects.toEqual(mockError)

        expect(customHistory.push).toHaveBeenCalledWith(PAGE_ROUTES.ERROR_401)
    })

    it('при статусе 404 показывает уведомление', async () => {
        const mockError = {
            response: {
                status: 404,
            },
        }

        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access,
        @typescript-eslint/no-unsafe-call */
        const handler = requestWrapper.interceptors.response.handlers[0].rejected
        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-call */
        await expect(handler(mockError)).rejects.toEqual(mockError)

        expect(systemErrorNotification).toHaveBeenCalledWith({
            message: 'Не найден запрашиваемый функционал',
            description: 'Пожалуйста, свяжитесь с нами с помощью кнопки обратной связи в меню',
        })
    })

    it('при статусе 500 показывает уведомление', async () => {
        const mockError = {
            response: {
                status: 500,
            },
        }

        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access,
      @typescript-eslint/no-unsafe-call */
        const handler = requestWrapper.interceptors.response.handlers[0].rejected
        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-call */
        await expect(handler(mockError)).rejects.toEqual(mockError)

        expect(systemErrorNotification).toHaveBeenCalledWith({
            message: 'Произошла ошибка',
            description: 'Пожалуйста, обновите страницу или попробуйте позже',
        })
    })

    it('при статусе 502 перенаправляет на страницу 500', async () => {
        const mockError = {
            response: {
                status: 502,
            },
        }

        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access,
        @typescript-eslint/no-unsafe-call */
        const handler = requestWrapper.interceptors.response.handlers[0].rejected
        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-call */
        await expect(handler(mockError)).rejects.toEqual(mockError)

        expect(customHistory.push).toHaveBeenCalledWith(PAGE_ROUTES.ERROR_500)
    })

    it('при неизвестном статусе пробрасывает ошибку', async () => {
        const mockError = {
            response: {
                status: 418
            }
        }

        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access,
      @typescript-eslint/no-unsafe-call */
        const handler = requestWrapper.interceptors.response.handlers[0].rejected
        // comment: нет типизации для тестов
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-call */
        await expect(handler(mockError)).rejects.toEqual(mockError)

        expect(systemErrorNotification).not.toHaveBeenCalled()
        expect(customHistory.push).not.toHaveBeenCalled()
        expect(mockStore.dispatch).not.toHaveBeenCalled()
    })
})
