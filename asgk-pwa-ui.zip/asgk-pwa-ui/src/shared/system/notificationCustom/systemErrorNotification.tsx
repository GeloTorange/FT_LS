import clsx from 'clsx'

import { notification } from '@shared/utils/notification'

import { Warning } from '../../assets/icons'

import style from './styles.module.scss'

type Props = {
    message: string,
    description: string,
}

export const systemErrorNotification = ({
    message,
    description,
}: Props) => {
    notification.info({
        className: clsx(style.notification, style.systemNotification),
        description,
        message,
        icon: <Warning />,
    })
}
