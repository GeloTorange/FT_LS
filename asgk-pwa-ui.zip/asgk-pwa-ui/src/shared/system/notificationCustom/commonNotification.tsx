import type { ArgsProps, NotificationPlacement } from 'antd/es/notification/interface'
import clsx from 'clsx'

import { notification } from '@shared/utils/notification'

import { Success, Warning } from '../../assets/icons'

import style from './styles.module.scss'

type Props = {
    message: string,
    placement?: NotificationPlacement,
    type: 'success' | 'warning',
    duration?: ArgsProps['duration'],
}
export const commonNotification = ({
    message,
    placement = 'topRight',
    type,
    duration,
}: Props) => {
    const notificationArgs: {[key: string]: ArgsProps} = {
        success: {
            className: clsx(style.notification, style.notificationSuccess, style.commonNotification),
            description: null,
            placement,
            message,
            icon: <Success />,
            duration,
        },
        warning: {
            className: clsx(style.notification, style.notificationWarning, style.commonNotification),
            description: null,
            placement,
            message,
            icon: <Warning />,
            duration,
        }
    }

    notification.info(notificationArgs[type])
}
