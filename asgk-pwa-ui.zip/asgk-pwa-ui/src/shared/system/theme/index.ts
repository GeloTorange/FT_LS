import {
    getTheme,
    getThemeLocalStorage, getThemeSystem, isDarkMode, setTheme, toggleTheme,
} from './helpers'

export { ThemeProvider } from './ThemeProvider'
export { THEME_VALUE } from './const'

export const themeUtils = {
    isDark: isDarkMode,
    set: setTheme,
    getLocalStorage: getThemeLocalStorage,
    getSystem: getThemeSystem,
    get: getTheme,
    toggle: toggleTheme,
}
