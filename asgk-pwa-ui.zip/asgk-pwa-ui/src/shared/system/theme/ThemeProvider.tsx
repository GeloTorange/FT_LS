import type { FC, PropsWithChildren } from 'react'
import { useEffect } from 'react'

import { setTheme, getTheme } from './helpers'

export const ThemeProvider:FC<PropsWithChildren> = ({ children }) => {
    useEffect(() => {
        setTheme(getTheme())
    }, [])

    return (
        <div>
            {children}
        </div>
    )
}
