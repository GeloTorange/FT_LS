import { THEME_VALUE } from './const'

export const isDarkMode = (): boolean => window.matchMedia('(prefers-color-scheme: dark)').matches

export const getThemeSystem = () =>
    isDarkMode() ? THEME_VALUE.dark : THEME_VALUE.light

export const getThemeLocalStorage = () =>
    localStorage.getItem('theme') as THEME_VALUE || null

export const setTheme = (theme: THEME_VALUE) => {
    document.documentElement.dataset.theme = theme
    localStorage.setItem('theme', theme)
}

export const getTheme = () => getThemeLocalStorage() || getThemeSystem()

export const toggleTheme = () => {
    const theme = getTheme()

    setTheme(theme === THEME_VALUE.dark ? THEME_VALUE.light : THEME_VALUE.dark)
}
