export enum THEME_VALUE {
    dark = 'dark',
    light = 'light',
}
