import type { AxiosError, AxiosInstance, AxiosResponse, InternalAxiosRequestConfig } from 'axios'
import axios from 'axios'

// comment: исключение из FSD для отображения ошибок
// eslint-disable-next-line boundaries/element-types
import { changeStatus } from '@entities/appState'
import { systemErrorNotification } from '@shared/system/notificationCustom'

import { senderApiUrl, tokenAddToHeader } from '../api/apiInstance'
import type { Response } from '../types/response'
import type { TypeStore } from '../types/store'

import { APP_STATUSES } from './appStatuses'
import { PAGE_ROUTES , customHistory } from './router'

const baseURL = senderApiUrl
const timeout = 120000

const requestWrapper: AxiosInstance = axios.create({
    baseURL,
    timeout,
})


let store: TypeStore

export const injectStore = (_store: TypeStore) => {
    store = _store
}

const buildConfig = (config: InternalAxiosRequestConfig): InternalAxiosRequestConfig => {
    const newConfig = { ...config }

    // Поле для ведения статистики по запросам
    newConfig.headers['Path-Name-In-The-Address-Bar'] = document.location.hash.slice(1)

    if (tokenAddToHeader) {
        newConfig.headers.Authorization = tokenAddToHeader
        // тут можно поставить ключ для локальных мок
        // newConfig.headers['private-emulation-key'] = ''
    }
    return newConfig
}

const responseHandler = (
    response: AxiosResponse<Response<any>, any>,
): Response<any>['data'] => {
    if (!response.data.error) {
        return response?.data
    }
    systemErrorNotification({
        message: 'Произошла ошибка',
        description: response?.data?.message,
    })
    return response?.data
}

// Функция обработки ошибок
const onRejected = async (error: AxiosError): Promise<AxiosError> => {
    const { code } = error
    if (code === 'ERR_NETWORK') {
        // Хотел переделать на редирект на главную,
        // но в Mozilla не корректно работает отображение страницы offline. Она ставится от Chromium.
        // Придется оставить использование стора.
        store.dispatch(changeStatus(APP_STATUSES.NETWORK_ERROR))
    }

    const { status } = error?.response || { status: null }
    switch (status) {
        case 401:
        case 403:
            customHistory.push(PAGE_ROUTES.ERROR_401)
            break
        case 404:
            systemErrorNotification({
                message: 'Не найден запрашиваемый функционал',
                description: 'Пожалуйста, свяжитесь с нами с помощью кнопки обратной связи в меню',
            })
            break
        case 500:
            systemErrorNotification({
                message: 'Произошла ошибка',
                description: 'Пожалуйста, обновите страницу или попробуйте позже',
            })
            break
        case 502:
            customHistory.push(PAGE_ROUTES.ERROR_500)
            break
        default:
            break
    }
    return Promise.reject(error)
}

requestWrapper.interceptors.request.use(
    buildConfig,
    (error: AxiosError) => onRejected(error),
)

requestWrapper.interceptors.response.use(
    // comment: TODO вернуться сюда и доделать типизацию
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return
    (response) => responseHandler(response),
    (error: AxiosError) => onRejected(error),
)

export default requestWrapper
