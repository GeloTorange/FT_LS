import { TreeSelect } from 'antd'
import type { TreeSelectProps } from 'antd/es/tree-select'
import clsx from 'clsx'
import type { ChangeEventExtra } from 'rc-tree-select/lib/interface'
import { type ReactNode, type FC, useCallback, useMemo } from 'react'
import { isDesktop } from 'react-device-detect'

import type { GetParamsInTreeStructure } from '@shared/utils/forTreeStructure'
import { toObjTreeStructureValue, toStrTreeStructureValue } from '@shared/utils/forTreeStructure'

import { helperStyles } from '../../styles'

import styles from './styles.module.scss'

type TreeSelectModProps = TreeSelectProps<string | GetParamsInTreeStructure> & { 
    isTagView?: boolean
    isTransformValue?: boolean
}

export const TreeSelectMod: FC<TreeSelectModProps> = ({
    isTagView,
    value,
    loading,
    onChange,
    isTransformValue,
    ...props
}) => {
    const tValue = useMemo(() => {
        if (isTransformValue) {
            return value && toStrTreeStructureValue(value as GetParamsInTreeStructure) || null
        }
        return value
    }, [value, isTransformValue])

    const handleChange: TreeSelectProps['onChange'] = useCallback(
        (inValue: string, labelList: ReactNode[], extra: ChangeEventExtra) => {
            if (onChange) {
                onChange(isTransformValue ? toObjTreeStructureValue(inValue) : inValue, labelList, extra)
            }
        }, 
        [onChange, isTransformValue]
    )

    return (
        <TreeSelect
            value={!loading ? tValue : ''}
            onChange={handleChange}
            size={'large'}
            classNames={{
                popup: {
                    root: styles.dropdown
                }
            }}
            styles={{
                popup: {
                    root: {
                        minWidth: isDesktop ? 360 : 220
                    }
                }
            }}
            className={clsx(
                helperStyles.offOutline,
                isDesktop ? styles.treeSelectDesktop : helperStyles.fullWidth,
                isTagView && styles.tagTreeSelect
            )}
            {...props}
        />
    )
}
