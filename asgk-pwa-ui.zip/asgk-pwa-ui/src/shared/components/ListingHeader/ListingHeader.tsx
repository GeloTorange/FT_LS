import { Col, Row, Space } from 'antd'
import type { ReactNode, FC } from 'react'
import React from 'react'

import { TypographyH1 } from '../typography'

type Props = {
    label: string,
    total?: number | null,
    filterElement: ReactNode | ReactNode[],
    filterTagsElement: ReactNode,
}

export const ListingHeader: FC<Props> = ({
    label,
    total,
    filterElement,
    filterTagsElement,
}) => (
    <Space direction={'vertical'} size={16}>
        <Row gutter={[0, 16]} justify={'space-between'} align={'middle'}>
            <Col>
                <Space>
                    <TypographyH1>{label}</TypographyH1>
                    { total !== undefined && total !== null &&
                            <TypographyH1 type={'secondary'}>
                                {total.toLocaleString('ru-RU')}
                            </TypographyH1>
                    }
                </Space>
            </Col>
            <Col>{filterElement}</Col>
        </Row>
        {filterTagsElement}
    </Space>
)
