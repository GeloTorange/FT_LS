import { Flex, Space } from 'antd'

import { CheckCircleTwoTone } from '../../assets/icons'
import { TypographyBody } from '../typography'

import styles from './styles.module.scss'

export const EndOfScroll = () => (
    <Flex data-testid={'EndOfScroll'} className={styles.padding} justify={'center'} align={'center'}>
        <Space align={'center'} direction={'vertical'} size={10}>
            <CheckCircleTwoTone className={styles.icon} />
            <TypographyBody>
                {'Вы просмотрели все записи'}
            </TypographyBody>
        </Space>
    </Flex>
)
