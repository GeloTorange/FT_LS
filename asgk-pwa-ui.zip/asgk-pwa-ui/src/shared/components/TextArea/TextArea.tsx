import { Input } from 'antd'
import type { TextAreaProps } from 'antd/es/input/TextArea'
import clsx from 'clsx'
import React, { type FC } from 'react'

import styles from './styles.module.scss'


type Props = TextAreaProps
export const TextArea:FC<Props> = ({ ...props }) => (
    <Input.TextArea
        // это дефолтные пропсы их можно переопределить с помощью props
        showCount
        variant={'filled'}
        maxLength={500}
        autoSize={{ minRows: 4, maxRows: 4 }}
        size={'large'}
        // отступ цифр от инпута
        styles={{ count: { bottom: -22 }}}
        {...props}
        className={clsx(styles.textArea, styles.scrollTrack, props?.className)}
    />
)
