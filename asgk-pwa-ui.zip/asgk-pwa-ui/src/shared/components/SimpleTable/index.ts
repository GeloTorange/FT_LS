export { HeaderSimpleTable } from './ui/Header'
export { RowSimpleTable } from './ui/Row'
export { SimpleTable } from './ui/Table'
export type { SimpleTableProps, SimpleTableColumn } from './type'
