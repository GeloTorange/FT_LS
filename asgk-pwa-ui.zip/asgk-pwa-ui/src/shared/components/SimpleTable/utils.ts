import { isDesktop } from 'react-device-detect'

import type { SimpleTableColumn } from './type'

export const isShowColumn = <DataItem extends Record<string, unknown>>(column: SimpleTableColumn<DataItem>) =>
    !(column.hideInMob && !isDesktop)
