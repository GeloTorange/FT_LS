import type { ReactNode } from 'react'

import type { NoDataProps } from '../NoData'

export type SimpleTableColumn<DataItem> = {
    className?: string
    span: number
    render: (rowData: DataItem) => ReactNode
    dataIndex: keyof DataItem
    id: string
    classNameHeader?: string
    title?: ReactNode
    hideInMob?: boolean
}

export type SimpleTableDataSourceItem<DataItem> = DataItem & {
    id: string,
}

type OnClickRow<DataItem> = (rowData: DataItem) => void

export type SimpleTableProps<DataItem extends Record<string, unknown>> = {
    columns: SimpleTableColumn<DataItem>[]
    dataSource: SimpleTableDataSourceItem<DataItem>[]
    onClickRow?: OnClickRow<DataItem>
    className?: string
    // Нужно для скрола
    heightContent?: string
    indentBottomHeader?: number
    isHideTitle?: boolean,
    loaderProps: {
        // лоадер перекрывающий весь контент
        isLoadingMain: boolean,
        // кол-во строк в лоадере
        count?: number
        // высота строки лоадера
        heightRow?: string,
        // лоадер для подгрузки по скролу
        isLoadingInfinity?: boolean,
    }
    noDataProps?: NoDataProps
}
