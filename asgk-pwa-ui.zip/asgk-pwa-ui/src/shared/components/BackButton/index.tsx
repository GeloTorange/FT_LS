import { Space, Typography } from 'antd'
import type { FC } from 'react'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'

import { LeftOutlined } from '../../assets/icons'
import { bodyTypographyStyle } from '../typography'

import styles from './styles.module.scss'

export const BackButton: FC = () => {
    const navigate = useNavigate()
    const [canGoBack, setCanGoBack] = useState(false)

    useEffect(() => {
        setCanGoBack(window.history.length > 1)
    }, [window.history.length])

    const onClick = () => { navigate(-1) }

    return (canGoBack
        ? <Space
            onClick={onClick}
            align={'center'}
            size={'small'}
        >
            <LeftOutlined className={styles.arrowBtn}/>
            <Typography.Link className={bodyTypographyStyle}>{'Назад'}</Typography.Link>
        </Space> : null
    )
}
