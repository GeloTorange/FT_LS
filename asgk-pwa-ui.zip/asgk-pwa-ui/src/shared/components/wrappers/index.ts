import { CardWrapper } from './CardWrapper'
import { FilterWrapper } from './FilterWrapper'
import { HalfCardWrapper } from './HalfCardWrapper'
import { ListingPageWrapper, listingStyles } from './ListingPagesWrapper'
import { ListingInCardWrapper, ListingWrapper, ListingSubWrapper } from './ListingWrapper'
import { ListWrapper } from './ListWrapper'
import { PreviewWrapper, ScrolledContentInPW } from './PreviewWrapper'
import { SorterWrapper } from './SorterWrapper'

// TODO: Нужно переработать wrappers ListingPage, Listing, List
export const Wrappers = {
    Sorter: SorterWrapper,
    Preview: PreviewWrapper,
    ScrolledContentPreview: ScrolledContentInPW,
    ListingPage: ListingPageWrapper,
    Listing: ListingWrapper,
    ListingInCard: ListingInCardWrapper,
    ListingSubWrapper,
    List: ListWrapper,
    Filter: FilterWrapper,
    Card: CardWrapper,
    HalfCard: HalfCardWrapper,
}

// TODO: Использование этого стиля надо заменить подходящей сверху оберткой
export const wrappersStyles = {
    listingPage: listingStyles
}
export type { ListingInCardWrapperProps } from './ListingWrapper/ListingWrapperInCard'

