import { Button, Col, Row } from 'antd'
import type { FC } from 'react'

import { TypographyTitle2 } from '../typography'

import styles from './styles.module.scss'
import { getFilterButtonsStyleConfig } from './utils'

type Props = {
    applyFilters: (flag?: boolean) => void
    resetFilters: () => Promise<void> | void
    changeFilterVisible: () => void,
    disableApply?: boolean
    isLegacy?: boolean,
}

export const FilterButtons: FC<Props> = ({
    applyFilters,
    resetFilters,
    changeFilterVisible,
    disableApply = false,
    isLegacy = true,
}) => {
    const onReset = async () => {
        await resetFilters()
        // TODO: вызов applyFilters это скрытая логика, которая должна быть реализована внутри resetFilters.
        //  Тогда в applyFilters не нужно будет передавать флаг true.
        //  Получается что ф-ия applyFilters, частично содержит логику для resetFilters
        //  (Нарушение Принципа единственной ответственности)
        applyFilters()
        changeFilterVisible()
    }

    const onApply = () => {
        applyFilters(true)
        changeFilterVisible()
    }

    const styleConfig = getFilterButtonsStyleConfig(isLegacy)

    return (
        <Row
            justify={styleConfig.justify}
        >
            <Col span={styleConfig.span}>
                <Row gutter={styleConfig.gutter}>
                    <Col span={12}>
                        <Button
                            size={'large'}
                            onClick={onReset}
                            className={styles.button}
                        >
                            <TypographyTitle2>{'Сбросить'}</TypographyTitle2>
                        </Button>
                    </Col>
                    <Col span={12}>
                        <Button
                            size={'large'}
                            disabled={disableApply}
                            onClick={onApply}
                            type={'primary'}
                            className={styles.button}
                        >
                            <TypographyTitle2>
                                {'Применить'}
                            </TypographyTitle2>
                        </Button>
                    </Col>
                </Row>
            </Col>
        </Row>
    )
}
