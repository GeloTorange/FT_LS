import type { ColProps, RowProps } from 'antd'
import { isDesktop } from 'react-device-detect'

type StyleConfigType = {
    gutter: RowProps['gutter']
    justify: RowProps['justify']
    span: ColProps['span']
}

export const getFilterButtonsStyleConfig = (isLegacy: boolean): StyleConfigType => {
    if (isLegacy) {
        return ({
            gutter: [12, 12],
            justify: 'start',
            span: 24,
        })
    }
    if (isDesktop) {
        return ({
            gutter: [8, 12],
            justify: 'end',
            span: 16,
        })
    }
    return ({
        gutter: [16, 12],
        justify: 'start',
        span: 24,
    })
}