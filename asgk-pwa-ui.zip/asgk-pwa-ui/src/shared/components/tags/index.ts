import { TagChips } from './TagChips'
import { TagCommentMark } from './TagCommentMark'
import { TagCommentDetails } from './TagCommentsDetails'
import { TagCSI } from './TagCSI'
import { TagInfluence, TagInfluenceContentInfo } from './TagInfluence'
import { TagMeasureComplete } from './TagMeasureComplete'
import { TagScore } from './TagScore'

export const Tags = {
    Details: TagCommentDetails,
    Comment: TagCommentMark,
    CSI: TagCSI,
    Influence: TagInfluence,
    InfluenceContentInfo: TagInfluenceContentInfo,
    Chips: TagChips,
    Score: TagScore,
    MeasureComplete: TagMeasureComplete,
}
