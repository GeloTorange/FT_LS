import { Flex, Space } from 'antd'
import clsx from 'clsx'
import type { FC } from 'react'
import React from 'react'

import helperStyles from '../../styles/helpers.module.scss'
import type { OnClickEvent } from '../../types/handlers'
import { Bookmark } from '../Bookmark'
import { Tags } from '../tags'
import { TypographyBody, TypographyTitle2 } from '../typography'

import styles from './styles.module.scss'

type Props = {
    id?: number
    description?: string;
    title: string;
    isFavorite: boolean;
    clickFavorite: OnClickEvent;
}

export const TitleForTriggerAndTrendCard: FC<Props> = ({
    id,
    description,
    title,
    isFavorite,
    clickFavorite,
}) =>
    (
        <Flex justify={'space-between'} align={'start'} gap={'large'}>
            <Space direction={'vertical'} size={0} className={styles.widthTitle}>
                { (description || id) &&
                    <div className={clsx(styles.headerWrapper, helperStyles.fullWidth,)}>
                        {description && (
                            <TypographyBody
                                className={helperStyles.ellipsisOneLine}
                                type={'secondary'}
                            >
                                {description}
                            </TypographyBody>
                        )}
                        { id && <Tags.Chips text={id} prefix={'ID'}/>}
                    </div>
                }
                <TypographyTitle2 className={helperStyles.ellipsisTwoLine} strong>
                    {title}
                </TypographyTitle2>
            </Space>
            <Bookmark isFavorite={isFavorite} onClick={clickFavorite} />
        </Flex>
    )
