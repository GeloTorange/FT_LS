export { TitleForTriggerAndTrendCard } from './TitleForTriggerAndTrendCard'
