import type { DrawerProps } from 'antd/es/drawer'
import type { ModalProps } from 'antd/es/modal'

type OnClose = () => void

export type SystemDialogProps =
    Omit<DesktopDialogProps, 'width' | 'onCancel' > &
    Omit<MobileDialogProps, 'height'> & {
        drawerHeight?: MobileDialogProps['height'],
        modalWidth?: DesktopDialogProps['width'],
    }

export type DesktopDialogProps = Pick<
    ModalProps,
    'forceRender' | 'width' | 'open' | 'closable' | 'title' | 'footer' | 'children' | 'centered' | 'styles' | 
    'destroyOnHidden'
> & {
    // Чтобы event не обрабатывать
    onCancel?: OnClose,
}

export type MobileDialogProps =
    Pick<
        DrawerProps,
        'forceRender' | 'height' | 'open' | 'title' | 'footer' | 'children' | 'destroyOnHidden'
    > & {
        // Чтобы event не обрабатывать
        onClose?: OnClose,
        isDataLoaded?: boolean,
    }
