export type { SystemDialogProps } from './types'
export type { ModalFooterDefaultProps } from './domain/ModalFooterDefault'
export { ModalFooterDefault } from './domain/ModalFooterDefault'
export { SystemDialog } from './SystemDialog'
