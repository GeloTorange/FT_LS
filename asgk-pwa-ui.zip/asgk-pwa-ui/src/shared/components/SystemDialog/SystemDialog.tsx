import type { FC } from 'react'
import { isDesktop } from 'react-device-detect'

import { DesktopDialog } from './Desktop/DesktopDialog'
import { MobileDialog } from './Mobile/MobileDialog'
import type { SystemDialogProps } from './types'

export const SystemDialog: FC<SystemDialogProps> = ({
    title,
    footer,
    forceRender = false,
    open,
    onClose,
    drawerHeight = '100%',
    modalWidth,
    children,
    closable = true,
    // TODO: по хорошему переработать бы UX с дизайнером по этому состоянию (isDataLoaded).
    //  Сделать например лоадер на время загрузки. А в children сделать обработку на наличие данных.
    //  А то если интернет затупил пользователь увидит текста, но не значения(
    isDataLoaded,
    centered = false,
    styles,
    destroyOnHidden
}) => (
    isDesktop
        ? <DesktopDialog
            title={title}
            footer={footer}
            forceRender={forceRender}
            open={open}
            onCancel={onClose}
            closable={closable}
            width={modalWidth}
            centered={centered}
            styles={styles}
            destroyOnHidden={destroyOnHidden}
        >
            {children}
        </DesktopDialog>
        : <MobileDialog
            title={title}
            footer={footer}
            forceRender={forceRender}
            open={open}
            onClose={onClose}
            height={drawerHeight}
            isDataLoaded={isDataLoaded}
            destroyOnHidden={destroyOnHidden}
        >
            {children}
        </MobileDialog>
)
