import { Col, Flex } from 'antd'
import React, { type FC } from 'react'

import { TypographyBody } from '../typography'

import styles from './styles.module.scss'

type Props = {
    // Ширина блока в колонках Grid-а
    span: number,
    // Заголовок
    title: string,
    // Текст под заголовком
    name?: string | number,
    // Подсказка при наведении (если надо будет и для мп, то надо доп стили реализовать)
    clue?: string
}

export const TextWithTitleColBlock: FC<Props> = ({
    span,
    title,
    name,
    clue,
}) =>
    <Col
        span={span}
        className={styles.col}
        title={clue}
    >
        <Flex vertical>
            <TypographyBody
                className={styles.textWrap}
                type={'secondary'}
            >
                {title}
            </TypographyBody>
            <TypographyBody
                className={styles.textWrap}
            >
                {name}
            </TypographyBody>
        </Flex>
    </Col>
