import { CardsSkeleton } from './CardsSkeleton'
import { CommentsSkeleton } from './CommentsSkeleton'
import { GraphLoader } from './GraphLoader'
import { InfoCSICardLoader } from './InfoCSICardLoader'
import { RowLoader } from './RowLoader/RowLoader'

export const Loaders = {
    Cards: CardsSkeleton,
    Comments: CommentsSkeleton,
    Chart: GraphLoader,
    Row: RowLoader,
    InfoCSICard: InfoCSICardLoader,
}
