import { FloatButton } from 'antd'
import React, { useEffect, useRef, useState } from 'react'

export const BackToTopButton = () => {
    const [isVisible, setIsVisible] = useState(false)
    const prevScrollPos = useRef(0)

    useEffect(() => {
        const toggleVisibility = () => {
            const currentScrollPos = window.scrollY

            if (
                (currentScrollPos > 1 && currentScrollPos < prevScrollPos.current) ||
                window.innerHeight + Math.round(currentScrollPos) >= document.body.offsetHeight
            ) {
                setIsVisible(true)
            } else {
                setIsVisible(false)
            }

            prevScrollPos.current = currentScrollPos
        }

        window.addEventListener('scroll', toggleVisibility)

        return () => { window.removeEventListener('scroll', toggleVisibility) }
    }, [isVisible])

    return isVisible ? (<FloatButton.BackTop visibilityHeight={0} />) : null
}
