import { Button } from 'antd'
import clsx from 'clsx'
import React from 'react'
import { isDesktop } from 'react-device-detect'

import { Share } from '@shared/assets/icons'
import { TypographyBody } from '@shared/components/typography'
import { iconColorsStyles } from '@shared/styles'
import { commonNotification } from '@shared/system/notificationCustom'

import styles from './styles.module.scss'

interface SharedButtonProps {
    filtersStr: string;
}

export const SharedButton:React.FC<SharedButtonProps> = ({ filtersStr }) => {
    const onClick = () => {
        const { protocol, host } = window.location

        navigator.clipboard.writeText(
            `${protocol}//${host}/#/${filtersStr}`
        )

        commonNotification({
            message: 'Ссылка скопирована в буфер обмена',
            placement: isDesktop ? 'topRight' : 'top',
            type: 'success'
        })
    }

    return (
        <Button
            type={'text'}
            className={styles.btn}
            onClick={onClick}
            icon={
                <Share
                    className={clsx(
                        styles.info,
                        iconColorsStyles.colorIconSecondary,
                    )}
                />
            }
        >
            {isDesktop && <TypographyBody
                type={'secondary'}
            >
                Поделиться
            </TypographyBody>}
        </Button>
    )
}
