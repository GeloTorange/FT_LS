import type { FC, PropsWithChildren } from 'react'

export const HideOnCSS:FC<PropsWithChildren<{ isHide: boolean }>> = ({ isHide, children }) =>
    <div style={{ display: isHide ? 'none' : 'block' }}>{ children }</div>
