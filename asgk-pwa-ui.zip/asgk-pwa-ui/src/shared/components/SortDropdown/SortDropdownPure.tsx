import { Button, Dropdown } from 'antd'
import type { ReactNode } from 'react'
import React from 'react'

import { SortOutlined } from '../../assets/icons'
import type { OrderType } from '../../types/filters'
import { TypographyBody } from '../typography'

import { modeSortDropdown } from './const'
import type { DefaultProps, OutSetterProps } from './types'

export type SortDropdownPureProps<T extends string> = DefaultProps<T> & OutSetterProps<T>

// Чистый компонент сортировки, где логика установки данных передается в props
export const SortDropdownPure = <T extends string, > ({
    mode, withText, options, value, setValue, disabled,
}: SortDropdownPureProps<T>): ReactNode => {
    const { btnSize, btnClassName, overlayMinWidth } = modeSortDropdown[mode]

    const onSort = (sortOption: OrderType<T>) => () => {
        setValue({
            // name - передаем на всякий случай
            name: sortOption.name,
            orderType: sortOption.orderType,
            orderDirection: sortOption.orderDirection
        })
    }

    const getDropdownLabel = (): string => {
        const result = options.find(
            ({ orderType, orderDirection }) =>
                orderType === value.orderType && orderDirection === value.orderDirection
        )
        return result?.name || ''
    }

    const selectedKeys = [`${value.orderType}_${value.orderDirection}`]

    return (
        <Dropdown
            arrow
            disabled={disabled}
            menu={{
                selectedKeys,
                items: options.map((item) => ({
                    key: `${item.orderType}_${item.orderDirection}`,
                    label: <TypographyBody>{item.name}</TypographyBody>,
                    onClick: onSort(item),
                })),
            }}
            overlayStyle={{ minWidth: overlayMinWidth }}
            mouseLeaveDelay={0.4}
        >
            <Button
                size={btnSize}
                type={'text'}
                icon={<SortOutlined className={btnClassName} />}
            >
                {withText && getDropdownLabel()}
            </Button>
        </Dropdown>
    )
}
