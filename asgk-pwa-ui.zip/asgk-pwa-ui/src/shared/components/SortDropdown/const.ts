import type { ButtonProps } from 'antd'

import { bodyTypographyStyle, h2Style } from '../typography'

import type { Modes } from './types'

export const modeSortDropdown: Record<Modes, {
    overlayMinWidth: number
    btnSize: ButtonProps['size'],
    btnClassName: string
}> = {
    small: {
        overlayMinWidth: 140,
        btnSize: 'small',
        btnClassName: '',
    },
    medium: {
        overlayMinWidth: 180,
        btnSize: 'large',
        btnClassName: bodyTypographyStyle,
    },
    big: {
        overlayMinWidth: 180,
        btnSize: 'large',
        btnClassName: h2Style,
    }
}
