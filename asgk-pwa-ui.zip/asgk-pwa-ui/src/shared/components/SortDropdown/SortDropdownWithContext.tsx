import type { ReactNode } from 'react'
import React, { useContext } from 'react'

import type { OrderDirections } from '../../types/context'
import type { OrderType } from '../../types/filters'
import { UniversalFilterContext } from '../../utils/context'

import { SortDropdownPure } from './SortDropdownPure'
import type { DefaultProps } from './types'


// Компонент сортировки с UniversalFilterContext
export const SortDropdownWithContext = <T extends string, > ({
    mode, withText, options, disabled,
}: DefaultProps<T>): ReactNode => {
    const { filter, setFilter } = useContext(UniversalFilterContext)

    const setValue = (sortOption: OrderType<T>) => {
        setFilter?.((oldFilter) => ({
            ...oldFilter,
            orderType: sortOption.orderType,
            orderDirection: sortOption.orderDirection,
            pageIndex: 1
        }))
    }

    const value: OrderType<T> = {
        orderType: filter.orderType as T,
        orderDirection: filter.orderDirection as OrderDirections,
        // name - для целостности в контекст ее не кидаем
        name: ''
    }

    return (
        <SortDropdownPure
            disabled={disabled}
            withText={withText}
            mode={mode}
            options={options}
            setValue={setValue}
            value={value}
        />
    )
}
