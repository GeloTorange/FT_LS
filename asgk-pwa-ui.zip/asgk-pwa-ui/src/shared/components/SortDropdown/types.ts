import type { OrderType } from '../../types/filters'


export type Modes = 'small' | 'medium' | 'big'
export type OutSetterProps<T extends string> = {
    setValue: (item: OrderType<T>) => void
    value: OrderType<T>
}
export type DefaultProps<T extends string> = {
    mode: Modes,
    withText?: boolean
    disabled?: boolean
    options: OrderType<T>[]
}
