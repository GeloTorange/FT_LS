import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'

// Чтобы не сохранялась позиция скролла при переходе на следующую страницу.
// В МП режиме после закрытия меню не срабатывает данный трюк - используется bodyOverFlowUpdate.
export const ScrollToTop = () => {
    const pathName = useLocation()

    useEffect(() => {
        const timeoutId = setTimeout(() => {
            window.scrollTo({ top: 0, behavior: 'smooth' })
        }, 100)
        return () => {
            clearTimeout(timeoutId)
        }
    }, [pathName])

    return null
}
