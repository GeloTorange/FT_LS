import type { FC, ReactNode } from 'react'

import { ArrowBottomOutlined, ArrowTopOutlined } from '../../assets/icons'

interface PercentViewProps {
    value?: number | null;
    fractional?: boolean;
    digits?: number;
    arrow?: boolean;
    empty?: ReactNode;
}

// @TODO: reuse instead of getViewCSIIncrPct
export const PercentView: FC<PercentViewProps> = ({ value, fractional, arrow, digits, empty }) => {
    if (value === null || value === undefined) {
        return empty === undefined ? '—' : empty
    }
    if (value === 0) {
        return '0%'
    }

    const isPositive = value > 0
    const transformedValue = Math.abs(value * (fractional ? 100 : 1)).toFixed(digits === undefined ? 1 : digits)

    return (
        <>
            {arrow && (isPositive ? <ArrowTopOutlined/> : <ArrowBottomOutlined/>)}
            {!arrow && (isPositive ? '' : '-')}
            {transformedValue}%
        </>
    )
}
