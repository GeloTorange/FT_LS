export interface OptionsListSelect {
    label?: string,
    value?: string | null,
    disabled?: boolean,
}
