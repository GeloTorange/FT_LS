import { Badge } from 'antd'
import React, { type FC } from 'react'

import { TypographyCaption } from '../typography'

// Когда isReverse=true отступ не нужен, он есть от текста
const getGap = (isReverse?: boolean, isLarge?: boolean) => {
    if (!isReverse) {
        return isLarge ? '8px' : '4px'
    }
    return 0
}

type BadgePndProps = {
    color: string
    text: string
    isFirst?: boolean
    isReverse?: boolean
    isLarge?: boolean
}
export const BadgeGraph: FC<BadgePndProps> = ({
    color,
    text,
    isFirst,
    isReverse,
    isLarge = false,
}) => {
    const gap = getGap(isReverse, isLarge)

    return (
        <Badge
            styles={{
                indicator: {
                    width: isLarge ? '12px' : '8px',
                    height: isLarge ? '12px' : '8px',
                    marginTop: '2px'
                },
                root: {
                    display: 'flex',
                    alignItems: 'center',
                    flexDirection: isReverse ? 'row' : 'row-reverse',
                    gap: gap,
                    marginInlineStart: isFirst ? 0 : 6,
                },
            }}
            color={color}
            text={<TypographyCaption style={{ textWrap: 'nowrap' }}>{text}</TypographyCaption>}
        />
    )
}
