import React, { type FC } from 'react'

import { TypographyCaption } from '../typography'

import styles from './styles.module.css'

type BadgeGraphDashedProps = {
    color: string
    text: string
}

export const BadgeGraphDashed: FC<BadgeGraphDashedProps> = ({
    color,
    text,
}) => (

    <div className={styles.badgeContainer}>
        <div className={styles.dashedContainer}>
            <span className={styles.dashedBadge} style={{ backgroundColor: color }} />
        </div>
        <TypographyCaption>{text}</TypographyCaption>
    </div>
)


