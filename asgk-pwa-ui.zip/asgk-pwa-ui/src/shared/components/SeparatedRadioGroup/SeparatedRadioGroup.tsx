import { Radio, type RadioChangeEvent } from 'antd'
import clsx from 'clsx'
import React, { type FC } from 'react'

import { TypographyBody } from '../typography'

import styles from './styles.module.scss'

type Props = {
    defaultValue?: string,
    value: string,
    onChange: (value: RadioChangeEvent) => void,
    tabs: {
        tabValue: string,
        label: string,
    }[]
}

export const SeparatedRadioGroup: FC<Props> = ({
    defaultValue,
    value,
    onChange,
    tabs,
}) => <Radio.Group
    defaultValue={defaultValue}
    onChange={onChange}
    buttonStyle={'solid'}
    value={value}
    className={styles.radioGroup}
>
    {tabs.map(({ tabValue, label }) =>
        <Radio.Button
            key={`${tabValue}+${label}`}
            value={tabValue}
            className={styles.radioBtn}
        >
            <TypographyBody
                className={clsx(
                    styles.radioTxt,
                    value === tabValue && styles.activeRadioTxt
                )}
            >
                {label}
            </TypographyBody>
        </Radio.Button>)}
</Radio.Group>
