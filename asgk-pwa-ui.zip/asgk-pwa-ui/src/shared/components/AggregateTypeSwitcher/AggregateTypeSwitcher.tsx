import { Radio } from 'antd'
import React from 'react'

import type { DynamicFilterContextType, FilterType } from '../../types/context'
import { AggregateTypes } from '../../types/filters'
import { onChangeRadioAggregateType } from '../../utils/CSI'

type Props<T extends FilterType> = {
    setFilter: DynamicFilterContextType<T & {aggregateType: AggregateTypes}>['setFilter'],
    defaultFilter?: AggregateTypes
}
// TODO: ошибка с setFilter должна скорректироваться если сузить типы на страницах,
//  через UniversalFilterContextProvider и useUniversalFilter
export const AggregateTypeSwitcher = <T extends FilterType,>({ setFilter, defaultFilter }: Props<T>) => (
    <Radio.Group
        defaultValue={defaultFilter}
        onChange={onChangeRadioAggregateType(setFilter)}
        buttonStyle={'solid'}
    >
        <Radio.Button value={AggregateTypes.WEEK}>
            {'Н'}
        </Radio.Button>
        <Radio.Button value={AggregateTypes.MONTH}>
            {'М'}
        </Radio.Button>
        <Radio.Button value={AggregateTypes.QUARTER}>
            {'К'}
        </Radio.Button>
    </Radio.Group>
)
