import clsx from 'clsx'
import React from 'react'

import { BookmarkFilled, BookmarkOutlined } from '../../assets/icons'
import { iconColorsStyles } from '../../styles'
import type { OnClickEvent } from '../../types/handlers'

import styles from './styles.module.scss'

type BookmarkProps = {
// Цвет менять в зависимости от места показа
// TODO: Лиза еще вернется с точным цветом по закраске в шапке
    isHeader?: boolean;
    isFavorite?: boolean;
    onClick: OnClickEvent;
}

export const Bookmark = ({ isFavorite, isHeader, onClick }: BookmarkProps) => {
    const BookmarkIcon = isFavorite ? BookmarkFilled : BookmarkOutlined

    return (
        <BookmarkIcon
            onClick={onClick}
            className={clsx(styles.bookmark, !isHeader && iconColorsStyles.colorIconTertiary)}
        />
    )
}
