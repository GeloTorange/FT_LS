export { NoData } from './NoData'
export type { NoDataProps } from './NoData'
