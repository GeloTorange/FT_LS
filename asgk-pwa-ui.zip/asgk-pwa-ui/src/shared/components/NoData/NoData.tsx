import { Empty, Flex } from 'antd'
import clsx from 'clsx'
import type { FC, ReactNode , CSSProperties } from 'react'

import styles from './styles.module.scss'


export type NoDataProps = {
    text?: string
    footer?: ReactNode
    className?: string
    style?: CSSProperties
    isCompactMobile?: boolean
}
export const NoData: FC<NoDataProps> = ({ text, footer, className, style, isCompactMobile }) => (
    <Flex
        data-testid={'NoData'}
        flex={isCompactMobile ? 0 : 1}
        justify={'center'}
        align={'center'}
        vertical
        className={clsx(styles.noDataWrapper, isCompactMobile && styles.compactMobile, className)}
        style={style}
    >
        <Empty
            className={clsx(footer && styles.withFooter)}
            image={Empty.PRESENTED_IMAGE_SIMPLE}
            description={text || 'Нет данных'}
        />
        { footer }
    </Flex>
)
