export type { WatchAllButtonProps } from './WatchAllButton'
export { WatchAllButton } from './WatchAllButton'
