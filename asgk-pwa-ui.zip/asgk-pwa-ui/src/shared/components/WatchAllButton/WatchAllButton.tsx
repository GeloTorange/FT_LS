import { CaretRightOutlined } from '@ant-design/icons'
import { Flex } from 'antd'
import React, { type FC } from 'react'
import type { URLSearchParamsInit } from 'react-router-dom'
import { createSearchParams, useNavigate } from 'react-router-dom'

import { helperStyles } from '../../styles'
import { TypographyBody } from '../typography'

import styles from './styles.module.scss'

export type WatchAllButtonProps = {
    pathname?: string,
    navigatePageSearchParams?: URLSearchParamsInit,
    text?: string,
    width?: string,
}

export const WatchAllButton: FC<WatchAllButtonProps> = ({
    pathname,
    navigatePageSearchParams,
    text,
    width,
}) => {
    const navigate = useNavigate()

    const onClickAll = () => {
        navigate(
            (pathname && !navigatePageSearchParams)
                ? pathname
                : {
                    pathname: pathname,
                    search: createSearchParams(navigatePageSearchParams || {}).toString(),
                }
        )
    }

    return (
        <Flex
            style={{ width: width || 'auto' }}
            onClick={onClickAll}
            justify={'flex-end'}
            className={helperStyles.cursorPointer}
        >
            <TypographyBody type={'secondary'} className={styles.text}>
                {text || 'Смотреть все '}
                <CaretRightOutlined className={styles.icon}/>
            </TypographyBody>
        </Flex>
    )
}
