import { useCallback, useEffect, useRef } from 'react'


export type UseInfinityScrollForComponentOptions = {
    hasMore: boolean
    isLoading?: boolean
    onLoadMore: () => void
    offset?: number,
}

export const useInfinityScrollForComponent = ({
    hasMore,
    isLoading = false,
    onLoadMore,
    offset = 0,
}: UseInfinityScrollForComponentOptions) => {
    const containerRef = useRef<HTMLDivElement | null>(null)

    const handleScroll = useCallback(() => {
        const el = containerRef.current
        if (!el || isLoading || !hasMore) return

        const { scrollTop, scrollHeight, clientHeight } = el

        if (scrollHeight - scrollTop - clientHeight <= offset) {
            onLoadMore()
        }
    }, [isLoading, hasMore, onLoadMore, offset])

    useEffect(() => {
        const el = containerRef.current
        if (!el) return

        el.addEventListener('scroll', handleScroll)

        return () => {
            el.removeEventListener('scroll', handleScroll)
        }

    }, [handleScroll])

    return { containerRef }
}
