import { useCallback, useEffect, useRef } from 'react'


export type UseInfinityScrollOptions = {
    /** Есть ли ещё данные для загрузки */
    hasMore: boolean
    /** Выполняется ли загрузка в данный момент */
    isLoading?: boolean
    /** Обратный вызов вызывается при достижении нижнего предела
     *  и условиях, позволяющих загружать дополнительные данные */
    onLoadMore: () => void
    /** Необязательное смещение (в пикселях) перед абсолютным нижним пределом для начала загрузки */
    offset?: number
}
// Универсальный хук бесконечной прокрутки.
// Добавляет прослушиватель прокрутки окна и активирует onLoadMore, когда пользователь достигает нижней границы.
// Предотвращает дублирование триггеров во время загрузки.
export const useInfinityScroll = ({
    hasMore,
    isLoading = false,
    onLoadMore,
    offset = 0,
}: UseInfinityScrollOptions) => {
    // Предотвращает множественные срабатывания во время одной ожидаемой загрузки
    const lockRef = useRef(false)

    const handleScroll = useCallback(() => {
        // Высота доступного контента
        const bodyHeight = document.body.offsetHeight
        // Кол-во пикселей проскроленных + высота окна браузера
        const currentScroll = window.scrollY + window.innerHeight
        // граница переходя, которую надо загружать (за одну высоту экрана до конца контента)
        const reachedBottom = bodyHeight - window.innerHeight

        if (
            currentScroll + offset >= reachedBottom &&
            hasMore &&
            !isLoading &&
            !lockRef.current
        ) {
            lockRef.current = true
            onLoadMore()
        }
    }, [hasMore, isLoading, onLoadMore, offset])

    useEffect(() => {
        // Снимаем блокировку после завершения загрузки или изменения условий
        // чтобы следующая прокрутка вниз могла снова сработать.
        lockRef.current = false

        document.addEventListener('scroll', handleScroll)
        return () => {
            document.removeEventListener('scroll', handleScroll)
        }
    }, [hasMore, isLoading, onLoadMore, offset])
}
