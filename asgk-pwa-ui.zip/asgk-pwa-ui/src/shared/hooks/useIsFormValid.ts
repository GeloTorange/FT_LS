import type { FormInstance } from 'antd'
import { Form } from 'antd'
import { useState, useEffect } from 'react'

// TODO: сделать передачу типа в FormInstance
export const useIsFormValid = (form: FormInstance) => {
    const [isFormValid, setIsFormValid] = useState(true)

    const values = Form.useWatch([], form)

    useEffect(() => {
        form.validateFields({ validateOnly: true })
            .then((formValues) => {
                setIsFormValid(!Object.values(formValues).length)
            })
            .catch(() => {
                setIsFormValid(true)
            })
    }, [values])

    return isFormValid
}
