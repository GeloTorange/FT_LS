import { useState, useEffect } from 'react'

import { commonNotification } from '../system/notificationCustom'

import { useInfinityScroll } from './useInfinityScroll'

export const useFakeLoadingOnScroll = (maxElementsCount = 100) => {
    const [countOfElements, setCountOfElements] = useState<number>(0)
    const [fakeLoading, setFakeLoading] = useState<boolean>(false)

    // Необходимо для отображения n-го количества строк в зависимости от высоты экрана пользователя при входе
    useEffect(() => {
        const height = document.body.offsetHeight
        setCountOfElements((height - 150) / 60)
    }, [])

    useInfinityScroll({
        hasMore: countOfElements < maxElementsCount,
        isLoading: fakeLoading,
        onLoadMore: () => {
            setFakeLoading(true)
            setTimeout(() => {
                setCountOfElements((prev) => prev + 20)
                setFakeLoading(false)
            }, 1000)
        },
        offset: 1,
    })

    useEffect(() => {
        if (countOfElements >= maxElementsCount) {
            commonNotification({
                message: 'Загружено максимальное количество записей. Установите дополнительные фильтры.',
                placement: 'bottomRight',
                type: 'warning'
            })
        }
    }, [countOfElements])

    return { countOfElements, fakeLoading }
}
