import { useSearchParams } from 'react-router-dom'

// TODO: Добавить возвратный тип для ясности, а то в компонентах
//  как any проставляется у ф-ий getSearchParam, setSearchParams
export const useSearchParamsHook = () => {
    const [searchParams, setSearchParams] = useSearchParams()

    const getSearchParam = (key: string) => searchParams.get(key)

    return { searchParams, getSearchParam, setSearchParams }
}

