import { useCallback, useState } from 'react'

type UsePaginationOptions = {
    pageIndex?: number
    pageSize?: number
}

export type UsePaginationReturnValue = {
    pageIndex: number
    pageSize: number
    onResetPagination: () => void
    onPaginationChange: (page: number, size: number) => void
}

const defaultPageSize = 50

export const usePagination = (options?: UsePaginationOptions): UsePaginationReturnValue => {
    const [pageIndex, setPageIndex] = useState(options?.pageIndex ?? 1)
    const [pageSize, setPageSize] = useState(options?.pageSize ?? defaultPageSize)

    const onPageIndex = useCallback((index: number) => {
        setPageIndex(index)
    }, [pageSize])

    const onPageSize = useCallback((size: number) => {
        setPageIndex(1)
        setPageSize(size)
    }, [])

    const onResetPagination = useCallback(() => {
        setPageIndex(options?.pageIndex ?? 1)
        setPageSize(options?.pageSize ?? defaultPageSize)
    }, [options?.pageIndex, options?.pageSize])

    const onPaginationChange = useCallback((page: number, size: number) => {
        if (pageSize !== size) {
            onPageSize(size)
            onPageIndex(1)
        } else {
            onPageSize(size)
            onPageIndex(page)
        }
    }, [pageSize, onPageSize, onPageIndex])


    return {
        pageIndex,
        pageSize,
        onResetPagination,
        onPaginationChange
    }
}
