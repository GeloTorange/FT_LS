import type { FormInstance } from 'antd'
import { useEffect, useState } from 'react'


export type ErrorsForm = {
    errorFields: {
        name: string[]
    }[]
}
type UseCheckHasErrorsArgs<T> = {
    allValues?: T
    form: FormInstance<T>
    checkErrorFn?: (error: ErrorsForm) => boolean
}
/**
 * Проверка, есть ли ошибки в форме
 *
 * @param form {FormInstance<MeasurePutForm>} - форма
 * @param allValues {MeasurePutForm} - все значения формы
 * @param checkErrorFn {function} - функция для доп проверки ошибок
 *
 * @return boolean - true если есть ошибки
 */
export const useCheckHasErrors = <T>({ form, allValues, checkErrorFn }: UseCheckHasErrorsArgs<T>): boolean => {
    const [hasErrors, setHasErrors] = useState<boolean>(false)

    useEffect(() => {
        form
            .validateFields({ validateOnly: true })
            .then(() => { setHasErrors(false) })
            .catch((errors: ErrorsForm) => {
                setHasErrors(checkErrorFn ? checkErrorFn(errors) : true)
            })
    }, [form, allValues])

    return hasErrors
}
