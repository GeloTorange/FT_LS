import { useMemo } from 'react'
import { useLocation } from 'react-router-dom'

import type { LocationState } from '../types/location'

const defaultState = {}

export const useLocationState = () => {
    const location = useLocation()
    return useMemo(() => (location.state || defaultState) as LocationState, [location])
}
