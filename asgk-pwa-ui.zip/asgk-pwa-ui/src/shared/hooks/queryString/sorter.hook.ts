import { useCallback, useMemo, useRef, useState } from 'react'
import type { NavigateOptions } from 'react-router-dom'
import { useSearchParams } from 'react-router-dom'

import { QueryParam } from './const'
import { SorterParamUtils } from './sorter.utils'
import type { Key, Sorter } from './types'

/**
 * Hook to parse and set sorter data in query string
 * @param permittedFields - sorter fields by which possible to sort
 * @param defaultSorter - default sorter which is used when there is no sorter parameter in query string
 * @param defaultSetterOptions - default options for setSearchParams
 * @return array [
 *    SorterArray<T> - sorter data from query string or default sorter
 *    (sorter?: SorterArray<T>, options?: NavigateOptions) => void - function to set new sorter or
 *                                                                   clear it (set default sorter) in query string
 * ]
 */
export const useQueryStringSorter = <T extends Key>(
    permittedFields: readonly T[],
    defaultSorter: Sorter<T>,
    defaultSetterOptions?: NavigateOptions
): [Sorter<T>, (sorter?: Sorter<T>, options?: NavigateOptions) => void] => {
    const [searchParams, setSearchParams] = useSearchParams()
    const [utils] = useState(new SorterParamUtils(permittedFields, defaultSorter))
    const [defaultOptions] = useState(defaultSetterOptions || {})
    const prevRef = useRef(utils.defaultSorter)

    const sorter = useMemo(() => {
        const sorterSearchParam = searchParams.get(QueryParam.sorter)
        const urlSorter = utils.decode(sorterSearchParam)
        const newSorter = utils.isEqual(prevRef.current, urlSorter) ? prevRef.current : urlSorter
        prevRef.current = newSorter
        return newSorter
    }, [searchParams, utils])

    const sorterSetter = useCallback((newSorter?: Sorter<T>, options?: NavigateOptions) => {
        const urlSearchParams = new URLSearchParams(searchParams)
        urlSearchParams.delete(QueryParam.sorter)
        if (newSorter) {
            const sorterParam = utils.encode(newSorter)
            if (sorterParam) {
                urlSearchParams.set(QueryParam.sorter, sorterParam)
            }
            // reset page
            urlSearchParams.delete(QueryParam.page)
        }
        setSearchParams(urlSearchParams, {
            ...defaultOptions,
            ...(options || {}),
        })
    }, [
        setSearchParams, searchParams, utils, defaultOptions
    ])

    return [sorter, sorterSetter]
}
