export interface Pager {
    page: number;
    size: number;
}

export type Key = string | number | symbol

export interface SorterItem<T extends Key> {
    field: T;
    reverse?: boolean;
}
export type Sorter<T extends Key> = SorterItem<T>[]

// filter types ready to encode for query string
export type PrimitiveFilterValue = string | number | boolean | string[] | number[] | boolean[] | null | undefined
export type PrimitiveFilter<T extends Key> = Partial<Record<T, PrimitiveFilterValue>>

// filter type suitable for use in filters
export type Filter<T extends Key> = Partial<Record<T, unknown>>

export type AppliedFilterFields = Key[]
