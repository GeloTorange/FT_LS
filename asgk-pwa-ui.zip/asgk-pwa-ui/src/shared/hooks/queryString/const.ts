/**
 * Query string param names to use in query string hooks
 */
export enum QueryParam {
    page = '_page',
    pageSize = '_pageSize',
    sorter = '_sorter',
    filter = '_filter',
}
