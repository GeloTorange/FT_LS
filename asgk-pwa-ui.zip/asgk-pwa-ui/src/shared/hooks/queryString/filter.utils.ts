import type { Filter, PrimitiveFilter } from './types'

/**
 * Utility class for useQueryStringFilter
 */
// TODO: Этот класс должен уйти со временем
export class FilterParamUtils<T extends Filter<keyof T>, R extends PrimitiveFilter<keyof R>> {
    readonly defaultFilter: T

    constructor (
        private readonly permittedFields: readonly (keyof T)[],
        defaultFilter: T,
        private readonly toFilter?: (value: R) => T,
        private readonly fromFilter?: (filter: T) => R,
    ) {
        this.defaultFilter = this.canonize(defaultFilter)
    }

    isDefault (filter: T) {
        return this.isEqual(this.defaultFilter, filter)
    }

    getAppliedFields (filter: T) {
        const applied = [] as (keyof T)[]
        for (const field of this.permittedFields) {
            if (
                (this.defaultFilter[field] && !filter[field]) ||
                (!this.defaultFilter[field] && filter[field]) ||
                !this.isEqual({ [field]: this.defaultFilter[field] } as T, { [field]: filter[field] } as T)
            ) {
                applied.push(field)
            }
        }
        return applied
    }

    encode (filter: T) {
        const canonized = this.canonize(filter)
        return this.isEqual(canonized, this.defaultFilter)
            ? ''
            : JSON.stringify(this.fromFilter ? this.fromFilter(canonized) : canonized)
    }

    encodeRaw (urlSearchParams: URLSearchParams, filter: T) {
        this.clearRaw(urlSearchParams)
        const canonized = this.canonize(filter)
        if (!this.isEqual(canonized, this.defaultFilter)) {
            const converted = this.fromFilter ? this.fromFilter(canonized) : (canonized as PrimitiveFilter<keyof T>)
            Object.keys(converted).forEach(key => {
                urlSearchParams.set(key, JSON.stringify(canonized[key as keyof T]))
            })
        }
        return urlSearchParams
    }

    encodeAsIs (filter: T) {
        const canonized = this.canonize(filter)
        // comment: для удобства
        // eslint-disable-next-line no-nested-ternary
        return this.isEqual(canonized, this.defaultFilter)
            ? ''
            : this.fromFilter ? this.fromFilter(canonized) : canonized
    }

    decode (filterQueryString: string | null): T {
        if (!filterQueryString) {
            return this.defaultFilter
        }
        try {
            const parsed = JSON.parse(filterQueryString) as R
            if (!parsed || parsed.constructor !== Object) {
                throw new Error('is not an object')
            }
            return this.canonize(this.toFilter ? this.toFilter(parsed) : (parsed as unknown as T))
        } catch {
            return this.defaultFilter
        }
    }

    clearRaw (urlSearchParams: URLSearchParams) {
        for (const key of this.permittedFields) {
            urlSearchParams.delete(key as string)
        }
        return urlSearchParams
    }

    decodeAsIs (filterQueryString: string | null): T {
        if (!filterQueryString) {
            return this.defaultFilter
        }
        try {
            const searchParams = new URLSearchParams(filterQueryString)
            const paramsJson: Record<string, string | number> = {}
            for (const [key, value] of searchParams.entries()) {
                const intValue = parseInt(value, 10)
                if (!isNaN(intValue) && intValue.toString() === value) {
                    paramsJson[key] = intValue
                } else {
                    paramsJson[key] = value
                }
            }
            const parsed = JSON.parse(JSON.stringify(paramsJson)) as R
            if (!parsed || parsed.constructor !== Object) {
                throw new Error('is not an object')
            }
            const result = this.canonize(this.toFilter ? this.toFilter(parsed) : (parsed as unknown as T))
            if (Object.keys(result).length === 0) {
                throw new Error('no any property in object')
            }
            return result
        } catch {
            return this.defaultFilter
        }
    }

    isEqual (extFilter1: T, extFilter2: T) {
        const filter1 = this.fromFilter ? this.fromFilter(extFilter1) : (extFilter1 as unknown as R)
        const filter2 = this.fromFilter ? this.fromFilter(extFilter2) : (extFilter2 as unknown as R)
        if (Object.keys(filter1).length !== Object.keys(filter2).length) {
            return false
        }
        const keys = Object.keys(filter1) as (keyof R)[]
        for (let idx = 0; idx < keys.length; idx++) {
            const key = keys[idx]
            const value = filter1[key]
            if (Array.isArray(value)) {
                const value2 = filter2[key]
                if (!Array.isArray(value2) || (value.length !== value2.length)) {
                    return false
                }
                for (let idx2 = 0; idx2 < value.length; idx2++) {
                    if (value[idx2] !== value2[idx2]) {
                        return false
                    }
                }
            } else if (value !== filter2[key]) {
                return false
            }
        }
        return true
    }

    rowValue (filter: T): R {
        return this.fromFilter ? this.fromFilter(filter) : (filter as unknown as R)
    }

    private canonize (filter: T): T {
        const canonized = {} as T;
        (Object.keys(filter) as (keyof T)[]).forEach((key) => {
            if (this.permittedFields.includes(key)) {
                const value = filter[key]
                const isEmptyValue = (value === undefined) || (value === null) ||
                  (typeof value === 'string' && !(value as string).trim()) ||
                  (typeof value === 'object' && Array.isArray(value) && !value.length) ||
                  (typeof value === 'object' && !Object.keys(value).filter(fld => {
                      const val = (value as T)[fld as keyof T]
                      return (val !== undefined) && (val !== null)
                  }).length)
                if (!isEmptyValue) {
                    canonized[key] = value
                }
            }
        })
        return canonized
    }
}
