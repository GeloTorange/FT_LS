import type { Pager } from './types'

/**
 * Utility class for useQueryStringPager
 */
export class PagerParamUtils {
    public readonly defaultPager: Pager

    constructor (defaultPageSize: number) {
        this.defaultPager = { page: 0, size: defaultPageSize } as const
    }

    encode (pager: Pager) {
        const targetPager = this.canonizePager(pager)
        const page = targetPager.page === 0 ? '' : targetPager.page.toString()
        const size = targetPager.size === this.defaultPager.size ? '' : targetPager.size.toString()
        return [page, size]
    }

    decode (pageStr: string | null, sizeStr: string | null): Pager {
        return this.canonizePager({
            page: parseInt(pageStr as string, 10),
            size: parseInt(sizeStr as string, 10),
        })
    }

    private canonizePager (pager: Pager) {
        const { page, size } = pager
        return {
            page: page > 0 ? page : this.defaultPager.page,
            size: size > 0 ? size : this.defaultPager.size,
        }
    }

    isEqual (pager1: Pager, pager2: Pager) {
        return (pager1.page === pager2.page) && (pager1.size === pager2.size)
    }

}
