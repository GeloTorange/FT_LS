import { useCallback, useMemo, useRef, useState } from 'react'
import type { NavigateOptions } from 'react-router-dom'
import { useSearchParams } from 'react-router-dom'

/**
 * Hook to parse and set arbitrary string data in query string
 * @param paramName - query string param name
 * @param defaultValue - default param value (is used when there is no pager parameter in query string)
 * @param defaultSetterOptions - default options for setSearchParams
 * @return array [
 *    T - data from query string or default value
 *    (pager?: T, clearKeys?: boolean | string[], options?: NavigateOptions) => void - function to set data or
 *                                                          clear it (set default value) in query string.
 *                                                          clearKeys - clear other params (all or by given list)
 * ]
 */
export const useQueryStringParam =
  <T extends string>(
      paramName: string,
      defaultValue?: T,
      defaultSetterOptions?: NavigateOptions
  ):
  [T | undefined, (value?: T, clearKeys?: boolean | string[], options?: NavigateOptions) => void] => {
      const [searchParams, setSearchParams] = useSearchParams()
      const [defaultOptions] = useState(defaultSetterOptions || {})
      const prevRef = useRef(defaultValue)

      const param = useMemo(() => {
          const value = searchParams.get(paramName) as T
          if (value === null) {
              return defaultValue
          }
          const newValue = prevRef.current === value ? prevRef.current : value
          prevRef.current = value
          return newValue
      }, [searchParams, defaultValue, paramName])

      const paramSetter = useCallback((newValue?: T, clearKeys?: boolean | string[], options?: NavigateOptions) => {
          const urlSearchParams = new URLSearchParams(searchParams)
          let keysToClear = [paramName]
          if ((clearKeys !== undefined) && (clearKeys !== false)) {
              keysToClear = keysToClear.concat(clearKeys === true ? Array.from(urlSearchParams.keys()) : clearKeys)
          }
          for (const key of keysToClear) {
              urlSearchParams.delete(key)
          }
          if ((newValue !== undefined) && (newValue !== defaultValue)) {
              urlSearchParams.set(paramName, newValue)
          }
          setSearchParams(urlSearchParams, {
              ...defaultOptions,
              ...(options || {}),
          })
      }, [
          setSearchParams,
          searchParams,
          paramName,
          defaultValue,
          defaultOptions
      ])

      return [param, paramSetter]
  }
