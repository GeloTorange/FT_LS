import { useCallback, useMemo, useRef, useState } from 'react'
import type { NavigateOptions } from 'react-router-dom'
import { useSearchParams } from 'react-router-dom'

import { QueryParam } from './const'
import { FilterParamUtils } from './filter.utils'
import type { Filter, PrimitiveFilter, AppliedFilterFields } from './types'

/**
 * Hook to parse and set filter data in query string
 * @param permittedFields - filter fields by which possible to filter
 * @param defaultFilter - default filter which is used when there is no filter parameter in query string
 * @param toFilter - function to convert query string parsed filter values to filter values which are used in components
 * @param fromFilter - function to convert used in components filter values to values which are encoded in query string
 * @param defaultSetterOptions - default options for setSearchParams
 * @return array [
 *    Filter - filter data from query string or default sorter
 *    (filter?: T, options?: NavigateOptions) => void - function to set new filter
 *                                                      or clear it (set default filter) in query string
 *    (filter?: T) => string - function to generate query string for given filter
 *                             (returns string like '<filter_param>=<encoded_filter_value>')
 *    boolean - is filter applyed (not equal to default filter) 
 *    R - raw filter (suitable for query string or api call)
 * ]
 */
export const useQueryStringFilter = <T extends Filter<keyof T>, R extends PrimitiveFilter<keyof R>>(
    permittedFields: readonly (keyof T)[],
    defaultFilter: T,
    toFilter?: (value: R) => T,
    fromFilter?: (filter: T) => R,
    defaultSetterOptions?: NavigateOptions
): [
    T,
    (filter?: T, options?: NavigateOptions) => void,
    (filter?: T) => string,
    AppliedFilterFields,
    R,
] => {
    const [searchParams, setSearchParams] = useSearchParams()
    const utils = useMemo(() => new FilterParamUtils(permittedFields, defaultFilter, toFilter, fromFilter),
        [
            permittedFields, defaultFilter, toFilter, fromFilter
        ])
    const [defaultOptions] = useState(defaultSetterOptions || {})
    const prevRef = useRef(utils.defaultFilter)

    const filter = useMemo(() => {
        const filterSearchParam = searchParams.get(QueryParam.filter)
        const decoded = utils.decode(filterSearchParam)
        const newFilter = utils.isEqual(prevRef.current, decoded) ? prevRef.current : decoded
        prevRef.current = newFilter
        return newFilter
    }, [searchParams, utils])

    const filterSetter = useCallback((newFilter?: T, options?: NavigateOptions) => {
        const urlSearchParams = new URLSearchParams(searchParams)
        urlSearchParams.delete(QueryParam.filter)
        if (newFilter) {
            const filterParam = utils.encode(newFilter)
            if (filterParam) {
                urlSearchParams.set(QueryParam.filter, filterParam)
            }
            // reset page
            urlSearchParams.delete(QueryParam.page)
        }
        setSearchParams(urlSearchParams, {
            ...defaultOptions,
            ...(options || {}),
        })
    }, [
        setSearchParams, searchParams, utils, defaultOptions
    ])

    const generateQueryString = useCallback((filterLocal?: T) => {
        if (!filterLocal) {
            return ''
        }
        const encoded = utils.encode(filterLocal)
        return encoded ? `${QueryParam.filter}=${encoded}` : ''
    }, [utils])

    const appliedFields = useMemo(() => utils.getAppliedFields(filter), [filter])

    const rawFilter = useMemo(() => utils.rowValue(filter), [filter])

    return [
        filter, filterSetter, generateQueryString, appliedFields, rawFilter
    ]
}

export const useQueryStringFilterAsIs = <T extends string, P extends Filter<T>>(
    permittedFields: T[],
    defaultFilter: P,
    toFilter?: (value: PrimitiveFilter<T>) => P,
    fromFilter?: (filter: P) => PrimitiveFilter<T>,
    defaultSetterOptions?: NavigateOptions
): [P, (filter?: P, options?: NavigateOptions) => void,
    (filter?: P) => string, initialPageFilterChanged:boolean, (setInitialPageFilterChanged:boolean) => void] => {
    const [searchParams, setSearchParams] = useSearchParams()
    const [utils] = useState(new FilterParamUtils(permittedFields, defaultFilter, toFilter, fromFilter))
    const [defaultOptions] = useState(defaultSetterOptions || {})
    const prevRef = useRef(utils.defaultFilter)
    const [initialPageFilterChanged, setInitialPageFilterChanged] = useState(true)

    const filter = useMemo(() => {
        const filterSearchParam = searchParams.toString()
        const decoded = utils.decodeAsIs(filterSearchParam)
        const newFilter = utils.isEqual(prevRef.current, decoded) ? prevRef.current : decoded
        prevRef.current = newFilter
        setInitialPageFilterChanged(false)
        return newFilter
    }, [searchParams, utils])

    const filterSetter = useCallback((newFilter?: P, options?: NavigateOptions) => {
        let urlSearchParams = new URLSearchParams(searchParams)
        const additionalFilters: Record<string, string | null> = {}
        for (const key of searchParams.keys()) {
            if (newFilter && !Object.keys(newFilter).includes(key)) {
                additionalFilters[key] = urlSearchParams.get(key)
            }
            if (permittedFields.includes(key as T)) {
                urlSearchParams.delete(key)
            }
        }
        if (newFilter) {
            const filterParam = utils.encodeAsIs(newFilter)
            urlSearchParams = new URLSearchParams(filterParam as string[][] | Record<string, string> | string)
            Object.keys(additionalFilters).forEach(filterName => {
                urlSearchParams.append(filterName, additionalFilters[filterName] as string)
            })
        }
        setSearchParams(urlSearchParams, {
            ...defaultOptions,
            ...(options || {}),
        })
    }, [
        setSearchParams, searchParams, utils, defaultOptions
    ])

    const generateQueryString = useCallback((filterParam?: P) => {
        if (!filterParam) {
            return ''
        }
        const encoded = utils.encodeAsIs(filterParam)
        const urlSearchParams = new URLSearchParams(encoded as string[][] | Record<string, string> | string)
        return encoded ? urlSearchParams.toString() : ''
    }, [utils])

    return [
        filter, filterSetter, generateQueryString, initialPageFilterChanged, setInitialPageFilterChanged
    ]
}
