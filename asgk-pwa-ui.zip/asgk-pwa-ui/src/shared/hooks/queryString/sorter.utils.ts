import type { SorterItem, Sorter, Key } from './types'

/**
 * Utility class for useQueryStringSorter
 */
export class SorterParamUtils<T extends Key> {
    readonly defaultSorter: Sorter<T>

    constructor (
        private readonly permittedFields: readonly T[],
        defaultSorter: Sorter<T>,
    ) {
        this.defaultSorter = this.canonize(defaultSorter)
    }

    encode (sorter: Sorter<T>) {
        const canonized = this.canonize(sorter)
        return this.isEqual(canonized, this.defaultSorter) ? '' : JSON.stringify(canonized)
    }

    decode (sorterQueryString: string | null): Sorter<T> {
        if (!sorterQueryString) {
            return this.defaultSorter
        }
        const sorter: Sorter<T> = []
        try {
            const parsed = JSON.parse(sorterQueryString) as Sorter<T>
            if (!Array.isArray(parsed)) {
                throw new TypeError('is non an array')
            }
            for (let idx = 0; idx < parsed.length; idx++) {
                const item = parsed[idx]
                if (this.permittedFields.includes(item.field)) {
                    sorter.push(this.canonize(item))
                }
            }
        } catch {
            return this.defaultSorter
        }
        return sorter
    }

    isEqual (sorters1: Sorter<T>, sorters2: Sorter<T>) {
        if (sorters1.length !== sorters2.length) {
            return false
        }
        for (let idx = 0; idx < sorters1.length; idx++) {
            const item1 = sorters1[idx]
            const item2 = sorters2[idx]
            if ((item1.field !== item2.field) || (!!item1.reverse !== !!item2.reverse)) {
                return false
            }
        }
        return true
    }

    private canonize (sorter: SorterItem<T>): SorterItem<T>
    private canonize (sorter: Sorter<T>): Sorter<T>
    private canonize (sorter: SorterItem<T> | Sorter<T>): SorterItem<T> | Sorter<T> {
        const transformer = (item: SorterItem<T>): SorterItem<T> => ({
            field: item.field,
            reverse: item.reverse || undefined,
        })
        return Array.isArray(sorter)
            ? sorter.map(transformer)
            : transformer(sorter)
    }
}
