import { beforeEach, describe, expect, it, vi } from 'vitest'
import { renderHook } from '@testing-library/react'
import { useLocationState } from '../useLocationState'

const mockUseLocation = vi.fn()
vi.mock('react-router-dom', () => ({
    useLocation: () => mockUseLocation() as Record<string, unknown>,
}))

describe('useLocationState', () => {
    beforeEach(() => {
        vi.clearAllMocks()
    })

    it('should return default state', () => {
        mockUseLocation.mockImplementation(() => ({ some: 'value' }))
        const { result } = renderHook(() => useLocationState())
        expect(result.current).toEqual({})
    })

    it('should return location state', () => {
        mockUseLocation.mockImplementation(() => ({ state: { c: 1 }}))
        const { result } = renderHook(() => useLocationState())
        expect(result.current).toEqual({ c: 1 })
    })
})
