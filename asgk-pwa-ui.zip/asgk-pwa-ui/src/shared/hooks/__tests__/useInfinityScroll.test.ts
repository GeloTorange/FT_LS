import { renderHook } from '@testing-library/react-hooks'
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { useInfinityScroll } from '../useInfinityScroll'

// Утилита для диспатча события scroll на document
const fireScroll = () => {
    document.dispatchEvent(new Event('scroll'))
}

// Шпионы на подписку/отписку
const addEventListenerSpy = vi.spyOn(document, 'addEventListener')
const removeEventListenerSpy = vi.spyOn(document, 'removeEventListener')

describe('useInfinityScroll', () => {
    let scrollY = 0

    beforeEach(() => {
        vi.clearAllMocks()
        // Значения окна и документа по умолчанию
        vi.spyOn(window, 'innerHeight', 'get').mockReturnValue(1000)
        vi.spyOn(document.body, 'offsetHeight', 'get').mockReturnValue(3000)
        scrollY = 0
        vi.spyOn(window, 'scrollY', 'get').mockImplementation(() => scrollY)
    })

    it('должен подписаться и отписываться на событие scroll при монтировании и размонтировании', () => {
        const { unmount } = renderHook(() => {
            useInfinityScroll({ hasMore: true, isLoading: false, onLoadMore: vi.fn() })
        } )
        expect(addEventListenerSpy).toHaveBeenCalledWith('scroll', expect.any(Function))
        unmount()
        expect(removeEventListenerSpy).toHaveBeenCalledWith('scroll', expect.any(Function))
    })

    it('должен вызвать onLoadMore при достижении нижней границы', () => {
        const onLoadMore = vi.fn()

        renderHook(() => {
            useInfinityScroll({ hasMore: true, isLoading: false, onLoadMore })
        } )

        // На старте ещё не у нижней границы: scrollY = 0, текущий скролл 1000, нижняя граница 2000
        fireScroll()
        expect(onLoadMore).not.toHaveBeenCalled()

        // Доскролливаем до нижней границы: scrollY = 1000 (текущий скролл = 2000)
        scrollY = 1000
        fireScroll()
        expect(onLoadMore).toHaveBeenCalledTimes(1)
    })

    it('не должен вызывать onLoadMore, если идёт загрузка (isLoading = true)', () => {
        const onLoadMore = vi.fn()

        // Подготавливаем позицию сразу у нижней границы
        scrollY = 1000

        renderHook(() => {
            useInfinityScroll({ hasMore: true, isLoading: true, onLoadMore })
        } )

        fireScroll()
        expect(onLoadMore).not.toHaveBeenCalled()
    })

    it('не должен вызывать onLoadMore, когда hasMore = false', () => {
        const onLoadMore = vi.fn()
        scrollY = 1000

        renderHook(() => {
            useInfinityScroll({ hasMore: false, isLoading: false, onLoadMore })
        } )

        fireScroll()
        expect(onLoadMore).not.toHaveBeenCalled()
    })

    it('должен учитывать offset и триггерить раньше', () => {
        const onLoadMore = vi.fn()

        // При offset = 200, триггер наступает при scrollY >= 800
        const offset = 200

        renderHook(() => {
            useInfinityScroll({ hasMore: true, isLoading: false, onLoadMore, offset })
        } )

        // Ещё рано
        scrollY = 700
        fireScroll()
        expect(onLoadMore).not.toHaveBeenCalled()

        // Достигли сработки раньше низа
        scrollY = 800
        fireScroll()
        expect(onLoadMore).toHaveBeenCalledTimes(1)
    })

    it('не должен вызывать onLoadMore повторно, пока действует блокировка', () => {
        const onLoadMore = vi.fn()

        renderHook(() => {
            useInfinityScroll({ hasMore: true, isLoading: false, onLoadMore })
        } )

        // Первая сработка
        scrollY = 1000
        fireScroll()
        expect(onLoadMore).toHaveBeenCalledTimes(1)

        // Повторные скроллы не должны вызывать пока lock не снят
        fireScroll()
        fireScroll()
        expect(onLoadMore).toHaveBeenCalledTimes(1)
    })

    it('должен снова сработать после снятия блокировки при изменении isLoading', () => {
        const onLoadMore = vi.fn()

        const { rerender } = renderHook(
            ({ hasMore, isLoading }) => {
                useInfinityScroll({ hasMore, isLoading, onLoadMore })
            },
            { initialProps: { hasMore: true, isLoading: false }}
        )

        // Первая сработка
        scrollY = 1000
        fireScroll()
        expect(onLoadMore).toHaveBeenCalledTimes(1)

        // Снимаем блокировку изменением зависимости (isLoading)
        rerender({ hasMore: true, isLoading: true })
        rerender({ hasMore: true, isLoading: false })

        // Снова скроллим — должен сработать повторно
        fireScroll()
        expect(onLoadMore).toHaveBeenCalledTimes(2)
    })
})
