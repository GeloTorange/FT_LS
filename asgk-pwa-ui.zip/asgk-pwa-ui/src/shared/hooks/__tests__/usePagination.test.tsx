import { renderHook, act } from '@testing-library/react-hooks'
import { usePagination } from '../usePagination'


describe('usePagination hook', () => {
    // Инициализация с дефолтными значениями
    it('should initialize with default values', () => {
        const { result } = renderHook(() => usePagination())

        expect(result.current.pageIndex).toBe(1)
        expect(result.current.pageSize).toBe(50)
    })

    // Инициализация с кастомными значениями
    it('should initialize with custom values', () => {
        const { result } = renderHook(() =>
            usePagination({ pageIndex: 3, pageSize: 25 })
        )

        expect(result.current.pageIndex).toBe(3)
        expect(result.current.pageSize).toBe(25)
    })

    //  Сброс пагинации
    it('should reset pagination with onResetPagination', () => {
        const { result } = renderHook(() =>
            usePagination({ pageIndex: 2, pageSize: 20 })
        )

        // Изменяем значения
        act(() => {
            result.current.onPaginationChange(4, 30)
        })

        // Проверяем изменения
        expect(result.current.pageIndex).toBe(1)
        expect(result.current.pageSize).toBe(30)

        // Сбрасываем
        act(() => {
            result.current.onResetPagination()
        })

        // Проверяем возврат к начальным значениям
        expect(result.current.pageIndex).toBe(2)
        expect(result.current.pageSize).toBe(20)
    })

    //  Обработка изменения только страницы
    it('should handle page change with onPaginationChange', () => {
        const { result } = renderHook(() =>
            usePagination({ pageIndex: 2, pageSize: 25 })
        )

        act(() => {
            result.current.onPaginationChange(3, 25)
        })

        expect(result.current.pageIndex).toBe(3)
        expect(result.current.pageSize).toBe(25)
    })

    // Обработка изменения размера страницы
    it('should handle page size change with onPaginationChange', () => {
        const { result } = renderHook(() =>
            usePagination({ pageIndex: 3, pageSize: 25 })
        )

        act(() => {
            result.current.onPaginationChange(1, 50)
        })

        expect(result.current.pageIndex).toBe(1)
        expect(result.current.pageSize).toBe(50)
    })

    // Обработка одновременного изменения страницы и размера
    it('should prioritize size change over page change', () => {
        const { result } = renderHook(() =>
            usePagination({ pageIndex: 3, pageSize: 25 })
        )

        act(() => {
            result.current.onPaginationChange(5, 50)
        })

        // При изменении размера страница всегда сбрасывается на 1
        expect(result.current.pageIndex).toBe(1)
        expect(result.current.pageSize).toBe(50)
    })

    // Проверка стабильности функций
    it('should maintain stable function references', () => {
        const { result, rerender } = renderHook(() =>
            usePagination({ pageIndex: 1, pageSize: 10 })
        )

        // Сохраняем первоначальные ссылки
        const initialReset = result.current.onResetPagination
        const initialChange = result.current.onPaginationChange

        // Триггерим ререндер
        rerender()

        // Проверяем, что ссылки остались те же
        expect(result.current.onResetPagination).toBe(initialReset)
        expect(result.current.onPaginationChange).toBe(initialChange)
    })

    // Проверка расчета offset при разных сценариях
    it('should calculate offset correctly in various scenarios', () => {
    // Сценарий 1: Начальное состояние
        const { result } = renderHook(
            ({ options }) => usePagination(options),
            { initialProps: { options: { pageIndex: 3, pageSize: 20 }}}
        )

        // Сценарий 2: Изменение страницы
        act(() => {
            result.current.onPaginationChange(4, 20)
        })

        // Сценарий 3: Изменение размера страницы
        act(() => {
            result.current.onPaginationChange(1, 30)
        })

        expect(result.current.pageSize).toBe(30)
    })

    // Сброс при изменении начальных параметров
    it('should reset to new initial values when props change', () => {
        const { result, rerender } = renderHook(
            ({ options }) => usePagination(options),
            { initialProps: { options: { pageIndex: 2, pageSize: 20 }}}
        )

        // Изменяем параметры
        rerender({ options: { pageIndex: 3, pageSize: 30 }})

        // Сбрасываем
        act(() => {
            result.current.onResetPagination()
        })

        // Проверяем сброс к новым начальным значениям
        expect(result.current.pageIndex).toBe(3)
        expect(result.current.pageSize).toBe(30)
    })

    // Комплексный сценарий
    it('should handle complex pagination workflow', () => {
        const { result } = renderHook(() => usePagination())

        // Шаг 1: Переход на 3-ю страницу
        act(() => {
            result.current.onPaginationChange(3, 50)
        })
        expect(result.current.pageIndex).toBe(3)
        expect(result.current.pageSize).toBe(50)

        // Шаг 2: Изменение размера страницы
        act(() => {
            result.current.onPaginationChange(1, 100)
        })
        expect(result.current.pageIndex).toBe(1)
        expect(result.current.pageSize).toBe(100)

        // Шаг 3: Переход на 5-ю страницу
        act(() => {
            result.current.onPaginationChange(5, 100)
        })
        expect(result.current.pageIndex).toBe(5)
        expect(result.current.pageSize).toBe(100)

        // Шаг 4: Сброс
        act(() => {
            result.current.onResetPagination()
        })
        expect(result.current.pageIndex).toBe(1)
        expect(result.current.pageSize).toBe(50)
    })
})
