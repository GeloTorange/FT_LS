import { describe, it, expect } from 'vitest'
import dayjs from 'dayjs'

import { useGetCommentLink } from '../comment'
import { renderHook } from '@testing-library/react'
import { WrapWithUniversalContext } from '../../../__testsUtils__/wrapper-testing-library'

describe('useGetCommentLink', () => {
    const mockDate1 = dayjs('2024-01-01')
    const mockDate2 = dayjs('2024-01-02')

    it('должен вернуть ссылку с датами из periodArray', () => {
        const { result } = renderHook(() => useGetCommentLink('123'), {
            wrapper: WrapWithUniversalContext({
                filter: {
                    periodArray: [mockDate1, mockDate2],
                    // это старая реализация, надо доп проверку, что она ушла
                    period: { startDate: mockDate1, endDate: mockDate2 },
                    startDate: mockDate1,
                    endDate: mockDate2,
                },
            })
        })

        expect(result.current).toBe('comments?cmId=123&startDate=2024-01-01&endDate=2024-01-02')
    })

    it('должен вернуть только cmId, старая реализация не работает больше', () => {
        const { result } = renderHook(() => useGetCommentLink('123'), {
            wrapper: WrapWithUniversalContext({
                filter: {
                    periodArray: null,
                    period: null,
                    startDate: '01.02.2024',
                    endDate: '01.03.2024',
                },
            }) })

        expect(result.current).toBe('comments?cmId=123')
    })

    it('должен вернуть только cmId если дат нет', () => {
        const { result } = renderHook(() => useGetCommentLink('123'), {
            wrapper: WrapWithUniversalContext({
                filter: {
                    periodArray: null,
                    period: null,
                    startDate: null,
                    endDate: null,
                },
            })
        })

        expect(result.current).toBe('comments?cmId=123')
    })
})
