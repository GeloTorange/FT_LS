import { renderHook } from '@testing-library/react-hooks'
import { describe, it, expect, vi, beforeEach } from 'vitest'

import { useWindowSize } from '../useWindowSize'
import { waitFor } from '@testing-library/dom'


const addEventListener = vi.spyOn(window, 'addEventListener')
const removeEventListener = vi.spyOn(window, 'removeEventListener')

describe('useWindowSize', () => {
    beforeEach(() => {
        vi.clearAllMocks()
    })

    it('должен вернуть начальную ширину экрана', () => {
        const { result } = renderHook(() => useWindowSize())
        expect(result.current).toBe(1024)
    })

    it('должен подписаться на событие resize при монтировании', () => {
        renderHook(() => useWindowSize())
        expect(addEventListener).toHaveBeenCalledWith('resize', expect.any(Function))
    })

    it('должен отписаться от события resize при размонтировании', () => {
        const { unmount } = renderHook(() => useWindowSize())
        unmount()
        expect(removeEventListener).toHaveBeenCalledWith('resize', expect.any(Function))
    })

    it('должен обновить ширину при вызове события resize', async () => {
        vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(1024)

        const { result } = renderHook(() => useWindowSize())

        vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(800)

        // Вызываем событие resize
        window.dispatchEvent(new Event('resize'))

        // Ожидаем, пока значение обновится
        await waitFor(() => {
            expect(result.current).toBe(800)
        })
    })
})
