import { renderHook, act } from '@testing-library/react-hooks'
import { describe, it, expect, vi, beforeEach } from 'vitest'

import type { UseInfinityScrollOptions } from '../useInfinityScroll'
import { useFakeLoadingOnScroll } from '../useFakeLoadingOnScroll'


// Мокаем useInfinityScroll, чтобы перехватывать переданные опции и не вешать реальный слушатель скролла
const mockUseInfinityScroll = vi.fn<(options: UseInfinityScrollOptions) => void>()
vi.mock('../useInfinityScroll', () => ({
    useInfinityScroll: (options: UseInfinityScrollOptions) => { mockUseInfinityScroll(options) },
}))

// Мокаем уведомления, чтобы проверить их вызов при достижении лимита
const mockCommonNotification = vi.fn()
vi.mock('../../system/notificationCustom', () => ({
    commonNotification: (args: unknown) => { mockCommonNotification(args) },
}))

describe('useFakeLoadingOnScroll', () => {
    beforeEach(() => {
        vi.clearAllMocks()
        // По умолчанию высота документа
        vi.spyOn(document.body, 'offsetHeight', 'get').mockReturnValue(1200)
        // Фейковые таймеры для контроля setTimeout
        vi.useFakeTimers()
    })

    it('инициализирует countOfElements на основе высоты документа', async () => {
        // (750 - 150) / 60 = 10
        vi.spyOn(document.body, 'offsetHeight', 'get').mockReturnValue(750)

        const { result, waitFor } = renderHook(() => useFakeLoadingOnScroll())

        // Ждём применения эффекта и установки начального значения
        await waitFor(() => {
            expect(result.current.countOfElements).toBe(10)
        })
        expect(result.current.fakeLoading).toBe(false)

        // Проверяем, что useInfinityScroll получил корректные опции
        // Последний вызов — после применения эффекта с реальным значением
        const options = mockUseInfinityScroll.mock.calls.at(-1)?.[0] as UseInfinityScrollOptions
        expect(options.hasMore).toBe(true)
        expect(options.isLoading).toBe(false)
        expect(options.offset).toBe(1)
        expect(typeof options.onLoadMore).toBe('function')
    })

    it('onLoadMore ставит fakeLoading=true и увеличивает countOfElements на 20 через 1000мс', async () => {
        // Начальное значение: (750 - 150) / 60 = 10
        vi.spyOn(document.body, 'offsetHeight', 'get').mockReturnValue(750)
        const { result, waitFor } = renderHook(() => useFakeLoadingOnScroll())

        await waitFor(() => {
            expect(result.current.countOfElements).toBe(10)
        })

        const { onLoadMore } = mockUseInfinityScroll.mock.calls.at(-1)?.[0] as UseInfinityScrollOptions
        expect(onLoadMore).toBeDefined()

        // Тригерим догрузку
        act(() => { onLoadMore() })
        expect(result.current.fakeLoading).toBe(true)

        // Проматываем время на 1с
        await act(async () => {
            vi.advanceTimersByTime(1000)
        })

        await waitFor(() => {
            expect(result.current.fakeLoading).toBe(false)
            // 10 + 20
            expect(result.current.countOfElements).toBe(30)
        })

        // И опции для useInfinityScroll должны обновиться (fakeLoading=false)
        const latest = mockUseInfinityScroll.mock.calls.at(-1)?.[0] as UseInfinityScrollOptions
        expect(latest.isLoading).toBe(false)
    })

    it('показывает уведомление при достижении лимита 100 и устанавливает hasMore=false', async () => {
        // Сделаем так, чтобы сразу было 100 элементов: (6150 - 150)/60 = 100
        vi.spyOn(document.body, 'offsetHeight', 'get').mockReturnValue(6150)

        const { waitFor } = renderHook(() => useFakeLoadingOnScroll())

        // Дождёмся эффекта уведомления
        await waitFor(() => {
            expect(mockCommonNotification).toHaveBeenCalledTimes(1)
        })

        // Проверим параметры уведомления
        const payload = mockCommonNotification.mock.calls[0][0] as {
            message: string
            placement: string
            type: string
        }
        expect(payload).toEqual({
            message: 'Загружено максимальное количество записей. Установите дополнительные фильтры.',
            placement: 'bottomRight',
            type: 'warning',
        })

        // Последний вызов useInfinityScroll должен быть с hasMore=false
        const latest = mockUseInfinityScroll.mock.calls.at(-1)?.[0] as UseInfinityScrollOptions
        expect(latest.hasMore).toBe(false)
    })

    it('не превышает лимит: hasMore остаётся true, если элементов меньше 100', async () => {
        // (3150 - 150)/60 = 50
        vi.spyOn(document.body, 'offsetHeight', 'get').mockReturnValue(3150)

        renderHook(() => useFakeLoadingOnScroll())

        // Последний вызов — после эффекта установки countOfElements
        const latest = mockUseInfinityScroll.mock.calls.at(-1)?.[0] as UseInfinityScrollOptions
        expect(latest.hasMore).toBe(true)
        expect(mockCommonNotification).not.toHaveBeenCalled()
    })

    it('многократные onLoadMore увеличивают количество записей ступенчато', async () => {
        // Старт: (1350 - 150)/60 = 20
        vi.spyOn(document.body, 'offsetHeight', 'get').mockReturnValue(1350)
        const { result, waitFor } = renderHook(() => useFakeLoadingOnScroll())
        await waitFor(() => { expect(result.current.countOfElements).toBe(20) })

        const getOnLoadMore = () => (
            mockUseInfinityScroll.mock.calls.at(-1)?.[0] as UseInfinityScrollOptions
        ).onLoadMore

        // 1-я догрузка
        act(() => { getOnLoadMore()() })
        await act(async () => { vi.advanceTimersByTime(1000) })
        await waitFor(() => { expect(result.current.countOfElements).toBe(40) })

        // 2-я догрузка
        act(() => { getOnLoadMore()() })
        await act(async () => { vi.advanceTimersByTime(1000) })
        await waitFor(() => { expect(result.current.countOfElements).toBe(60) })
    })
})
