import { renderHook } from '@testing-library/react'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { usePreserveFilterOnMainMenuNavigate } from '../usePreserveFilterOnMainMenuNavigate'

const mockUseLocationState = vi.fn(() => ({}))
vi.mock('../useLocationState', () => ({
    useLocationState: () => mockUseLocationState() as Record<string, unknown>,
}))

describe('usePreserveFilterOnMainMenuNavigate', () => {
    beforeEach(() => {
        vi.clearAllMocks()
    })

    it('should not call setter on empty fromMainMenu location state', () => {
        const setFilter = vi.fn()

        const { rerender } = renderHook(
            (filter) => { usePreserveFilterOnMainMenuNavigate(filter || { a: 1 }, setFilter) }
        )
        expect(setFilter).not.toBeCalled()

        rerender({ c: 2 })
        expect(setFilter).not.toBeCalled()
    })

    it('should call setter on non-empty fromMainMenu location state', () => {
        mockUseLocationState.mockImplementation(() => ({ fromMainMenu: true }))
        const setFilter = vi.fn()

        const { rerender } = renderHook(
            (filter) => { usePreserveFilterOnMainMenuNavigate(filter || { a: 1 }, setFilter) }
        )
        expect(setFilter).not.toBeCalled()

        rerender({ c: 2 })
        expect(setFilter).toBeCalledWith({ a: 1 })
    })
})
