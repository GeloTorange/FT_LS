import { describe, it, expect, vi } from 'vitest'
import { useSearchParams } from 'react-router-dom'
import { useSearchParamsHook } from '../useSearchParamsHook'


// Мокаем react-router-dom
vi.mock('react-router-dom', () => ({
    useSearchParams: vi.fn()
}))

describe('useSearchParamsHook', () => {
    it('должен возвращать объект с searchParams, getSearchParam и setSearchParams', () => {
        const mockSearchParams = new URLSearchParams('test=123')
        const mockSetSearchParams = vi.fn()

        vi.mocked(useSearchParams).mockReturnValue([mockSearchParams, mockSetSearchParams])

        const { searchParams, getSearchParam, setSearchParams } = useSearchParamsHook()

        expect(searchParams).toBe(mockSearchParams)
        expect(typeof getSearchParam).toBe('function')
        expect(setSearchParams).toBe(mockSetSearchParams)
    })

    it('getSearchParam должен возвращать значение параметра по ключу', () => {
        const mockSearchParams = new URLSearchParams('test=123&foo=bar')
        vi.mocked(useSearchParams).mockReturnValue([mockSearchParams, vi.fn()])

        const { getSearchParam } = useSearchParamsHook()

        expect(getSearchParam('test')).toBe('123')
        expect(getSearchParam('foo')).toBe('bar')
        expect(getSearchParam('unknown')).toBeNull()
    })

    it('setSearchParams должен вызывать оригинальный setSearchParams', () => {
        const mockSetSearchParams = vi.fn()
        vi.mocked(useSearchParams).mockReturnValue([new URLSearchParams(), mockSetSearchParams])

        const { setSearchParams } = useSearchParamsHook()
        const newParams = { newParam: 'value' }

        setSearchParams(newParams)

        expect(mockSetSearchParams).toHaveBeenCalledTimes(1)
        expect(mockSetSearchParams).toHaveBeenCalledWith(newParams)
    })
})
