import { useEffect, useRef } from 'react'

import { useLocationState } from './useLocationState'

/**
 * Оставить текущий фильтр при навигации из главного меню на эту же страницу
 * @param filter текущий фильтр
 * @param setFilter сеттер для устаовки фильтра
 * @return void
 */
export const usePreserveFilterOnMainMenuNavigate = <T extends Partial<Record<keyof T, unknown>>>(
    filter: T,
    setFilter: (arg: T) => void,
) => {
    const locationState = useLocationState()
    const prevFilterRef = useRef<T>()

    useEffect(() => () => {
        // для корректной установки предыдущего фильтра в dev-режиме (при двойном монтировании)
        prevFilterRef.current = undefined
    }, [])

    useEffect(() => {
        // оставить текущий фильтр при навигации из главного меню на эту же страницу
        if (locationState.fromMainMenu && prevFilterRef.current) {
            setFilter(prevFilterRef.current)
        }
        prevFilterRef.current = filter
    }, [locationState, setFilter, filter])
}
