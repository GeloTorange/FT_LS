import { useRef, useState } from 'react'

/**
 * Hook factory to fetch data and cache them
 * @param fetcher - fetch function to fetch data (chane of the functions leads to new data request)
 * @param ttlSec - cache TTL (empty or negative value is infinite caching unless fetcher is changed)
 * @return array [
 *    T | unndefined - fetched data,
 *    boolean - fetching status (is data loading),
 *    Error - fetching error
 * ]
 */
export const fetchDataHookFactory = <T>(fetcher: () => Promise<T>, ttlSec?: number) =>
    (): [T | undefined, boolean, Error | undefined] => {
        const [data, setData] = useState<T | undefined>()
        const [error, setError] = useState<Error | undefined>()
        const fetchTimestampRef = useRef(0)
        const prevFetcher = useRef<() => Promise<T>>()
        const isFetchingRef = useRef(false)

        const isTtlExpired = (ttlSec !== undefined) && (ttlSec > 0) &&
            ((fetchTimestampRef.current + ttlSec * 1000) < Date.now())
        const isFetcherChanged = prevFetcher.current !== fetcher

        if (!isFetchingRef.current && (isFetcherChanged || isTtlExpired)) {
            fetchTimestampRef.current = Date.now()
            isFetchingRef.current = true
            prevFetcher.current = fetcher
            setError(undefined)
            setData(undefined)
            fetcher()
                .then(setData)
                .catch(setError)
                .finally(() => {
                    isFetchingRef.current = false
                })
        }

        return [data, isFetchingRef.current, error]
    }