import type { Dayjs } from 'dayjs'
import { useContext } from 'react'

import type { FilterContextType } from '../types/context'
import { UniversalFilterContext } from '../utils/context'


type GetCommentLink = {
    cmId: string
    startDate?: Dayjs | string
    endDate?: Dayjs | string
}

const getCommentLink = ( { cmId, startDate, endDate }: GetCommentLink) => {
    const getDate = () => {
        if (startDate && endDate) {
            return `&startDate=${
                typeof startDate === 'string' ? startDate : startDate?.format('YYYY-MM-DD')
            }&endDate=${
                typeof endDate === 'string' ? endDate : endDate?.format('YYYY-MM-DD')
            }`
        }
        return ''
    }

    return `comments?cmId=${cmId}${getDate()}`
}
// Вернет ссылку для конкретного комментария
export const useGetCommentLink = ( cmId: string) => {
    const { filter: { periodArray }} = useContext<FilterContextType>(UniversalFilterContext)

    return getCommentLink({
        cmId,
        startDate: periodArray?.[0],
        endDate: periodArray?.[1],
    })
}
