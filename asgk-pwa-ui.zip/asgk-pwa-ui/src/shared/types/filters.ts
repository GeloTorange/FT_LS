import type { FormInstance } from 'antd'
import type { Dayjs } from 'dayjs'

import type { OrderDirections , FilterType } from './context'

export type ExtraFilterFormData = {
    appealType?: string,
    factorica?: string | null,
}

// Все возможные значения в форме фильтра (выделил отдельно от FilterType для удобства)
export type FilterFormData = Pick<FilterType,
    'clientSegment' |
    'versionSBOLId' |
    'triggerId' |
    'triggerType' |
    'trendId' |
    'trendType' |
    // marks - без null для корректной синхронизации в onOpen
    'marks' |
    'cmId' |
    'searchWord' |
    'minLength' |
    'periodArray' |
    'structure' |
    'is300' |
    'lowScore'
> & ExtraFilterFormData

export enum AggregateTypes {
    DAY = 'DAY',
    WEEK = 'WEEK',
    MONTH = 'MONTH',
    QUARTER = 'QUARTER',
    ADAPTIVE = 'ADAPTIVE',
}

export const DefaultAggregateType = AggregateTypes.WEEK

export type PaginationParameters = {
    pageIndex: number;
    pageSize: number;
}

export type OrderType<T extends string> = {
    orderType: T,
    orderDirection: OrderDirections,
    name: string,
}

export type FilterFormProps = {
    form: FormInstance<FilterFormData>,
    lastReset?: Date | null,
}

export type GenerateFilterParams = Pick<FilterType,
    'clientSegment' |
    'structure' |
    'unitId' |
    'tribeId' |
    'productId' |
    'triggerId' |
    'triggerType' |
    'trendId' |
    'versionSBOLId' |
    'cmId' |
    'searchWord' |
    'trendType'
> & {
    periodArray?: [Dayjs, Dayjs] | [string, string];
} & ExtraFilterFormData
