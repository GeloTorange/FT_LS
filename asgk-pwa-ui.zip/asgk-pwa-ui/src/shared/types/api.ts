import type { Dayjs } from 'dayjs'

// TODO: эти типы надо сгруппировать по смыслу. Иначе превратится в "свалку" типов
export type GeneralParams<F> = {
    filter: F,
    aggregateType?: string,
    orderType?: string | null,
    orderDirection?: string | null,
    favoritesFirst?: boolean,
    page?: Page,
    period?: PeriodType,
}

export type PeriodType = {
    startDate?: string | Dayjs,
    endDate?: string | Dayjs,
}

export type Page = {
    pageSize: number,
    pageIndex: number,
}

export type GeneralFilter = {
    trendId?: string | null,
    triggerId?: number | string | null,
    tribeId?: string | null,
    painId?: string | null,
    measureId?: string | null,
    productId?: string | null,

    versionSBOLId?: string | null,

    triggerType?: string | null,
    trendType?: string | null,

    clientSegment?: string | null,

    searchWord?: string | null,

    minLength?: number | null,
    marks?: number[],

    startDate?: string,
    endDate?: string,
}

export type StatisticData = {
    date: string
    csi: number
    csiIncr: number | null,
    countAnswers: number,
    answerIncr: number | null,
    countSend: number,
    responseRate: number,
}

export type StatisticsCSI = {
    data: StatisticData[],
    uniqDates: string[]
}

export interface MainStatisticData {
    totalCount: number,
    triggers: TriggerInfo[]
}

export type TriggerInfo = {
    id: number,
    name: string,
    triggerType: number,
    favorite: boolean,
    csi: number,
    csiIncr: number,
    csiIncrPct: number,
    countAnswers: number,
    answerIncr: number,
    parent?: ParentType,
    statistics: StatisticsCSI
}

export type ParentType = {
    id: number,
    name: string,
    parent?: {
        id: number,
        name: string,
        parent: null,
    }
}

export type AllListParams = {
    unitId?: string | null,
    tribeId?: string | null,
    triggerId?: string | null,
    triggerType?: string | null,
    productId?: string | null,
    trendId?: string | null,
    clientSegment?: string | null,
    forTrends?: boolean,
}

export interface AllListData {
    id?: string,
    uuid?: string,
    triggerTypeId? : string,
    product?: string,
    trigger?: string,
    ownerGroupId?: string,
    ownerGroupName?: string,
    name?: string,
}

export type Trend = {
    index: number | null,
    indexIncr: number | null,
    indexIncrPct: number | null,
}
