export type ErrorResponse = boolean | undefined
export interface Response<T> {
    data: T
    message: string
    error: ErrorResponse
}
