// comment: Исключение так как Redux не совсем корректно ложится на FSD
// eslint-disable-next-line import/no-unresolved,boundaries/element-types,boundaries/entry-point
import type { store } from '@app/store'

export type RootState = ReturnType<typeof store.getState>
export type TypeStore = typeof store
