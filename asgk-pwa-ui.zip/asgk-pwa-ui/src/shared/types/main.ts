export enum MainTabsValues {
    MAIN = 'MAIN',
    CSI = 'CSI',
    APPEALS = 'APPEALS',
    CONSULTATIONS = 'CONSULTATIONS',
}
