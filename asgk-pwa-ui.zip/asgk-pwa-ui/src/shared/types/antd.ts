export type FormItemPushProps<T> = {
    // name: string - // это есть, но не используется в дочерних
    value?: T
    onChange?: (value: T) => void
}
