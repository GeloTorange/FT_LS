export enum ListingTypes {
    TRIGGER = 'TRIGGER',
    TREND = 'TREND',
}
