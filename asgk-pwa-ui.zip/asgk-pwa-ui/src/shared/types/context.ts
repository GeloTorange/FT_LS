import type { Dayjs } from 'dayjs'
import type React from 'react'

import type { TrendTypes } from '../api/trends'

import type { AggregateTypes } from './filters'


export type FilterContextType = {
    filter: FilterType,
    setFilter: React.Dispatch<React.SetStateAction<FilterType>> | null
}

export type FilterType = {
    clientSegment?: string | null,
    orderType?: CSIOrderTypes | TrendsOrderTypes | CommentOrderTypes | string,
    orderDirection?: OrderDirections | string,
    aggregateType?: AggregateTypes,
    periodArray?: [Dayjs, Dayjs],
    unitId?: string | null,
    tribeId?: string | null,
    productId?: string | null,
    triggerId?: string | null,
    triggerType?: string | null,
    trendId?: string | null,
    trendType?: TrendTypes | null,
    versionSBOLId?: string | null,
    // в Прямой речи
    cmId?: string | null,
    searchWord?: string | null,
    // marks - без null для корректной синхронизации в onOpen
    marks?: number[],
    minLength?: string | null,
    structure?: string | null,
    is300?: boolean,
    lowScore?: boolean,
    pageIndex?: number
} & ExtraFilterType

type ExtraFilterType = {
    appealType?: string,
    factorica?: string | null,
    summaryId?: string | null
}

export enum TrendsOrderTypes {
    TREND_RATIO_PCT = 'TREND_RATIO_PCT',
    TREND_RATIO_PCT_INCR = 'TREND_RATIO_PCT_INCR',
}

export enum CSIOrderTypes {
    COUNT_ANSWERS = 'COUNT_ANSWERS',
    CSI_INCR = 'CSI_INCR',
    CSI = 'CSI',
    ALPHABET = 'ALPHABET',
    INDEX = 'INDEX',
}

export enum CommentOrderTypes {
    ANSWER_DATE = 'ANSWER_DATE',
    COMMENT_LENGTH = 'COMMENT_LENGTH',
    MARK = 'MARK',
}

export enum OrderDirections {
    ASC = 'ASC',
    DESC = 'DESC',
}

// Позволяет уточнить какие поля фильтра точно есть на этой странице
export type PageFilter<F extends FilterType> = F & FilterType

// Позволяет расширить тип FilterContextType, чтобы можно было использовать точечный тип
export type DynamicFilterContextType<T extends FilterType> = {
    filter: T,
    setFilter: React.Dispatch<React.SetStateAction<T>> | null
}
