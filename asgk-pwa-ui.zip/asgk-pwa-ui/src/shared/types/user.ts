import type { Roles } from '../system/router'

export interface UserData {
    exp?: string
    user: SudirUser
    token: string
    usersToken: UsersToken
}

type TableValueType = string | null


export interface SudirUser {
    id: number
    login: string
    emploeeid: string
    name: string
    position: string
    mail: string
    subscribe: number
    mail_sigma: TableValueType
    subscribe_sigma: number
    phone: string
    tribe: number
    roles: Roles[]
    rolesStr: string
    currentFio: string
    ownerGroupId: number
    ownerGroupConfirm: boolean
    sudirLogin: string
    last_login: TableValueType
}

export interface UsersToken {
    id: number
    token: string
    user_id: number
    date: string
    user: TokenUser
}

export interface TokenUser {
    id: number
    login: string
    emploeeid: string
    name: string
    position: string
    mail: string
    subscribe: number
    mail_sigma: string
    subscribe_sigma: number
    phone: string
    tribe: number
    roles: Roles[]
    rolesStr: string
    currentFio: string
    ownerGroupId: number
    ownerGroupConfirm: boolean
    sudirLogin: string
    last_login: string
}
