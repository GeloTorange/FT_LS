import type { MouseEvent } from 'react'

export type OnClickEvent = (e: MouseEvent) => void
