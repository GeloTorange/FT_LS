export type TooltipOptions = {
    seriesIndex: number,
    dataPointIndex: number,
    series: number[][]
    w: {
        globals: {
            categoryLabels: {
                date: string,
                countAnswers: number,
            }[],
            lastXAxis: {
                categories: string[]
            }
        }
    }
}

export const GraphAggregateFormats: { [key: string]: string } = {
    WEEK: 'DD.MM',
    MONTH: 'MMM',
    QUARTER: 'Q [кв] YY',
}
