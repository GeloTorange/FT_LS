export const bodyOverFlowUpdate = (isMenuLinkClickMob?: boolean) => (open: boolean) => {
    if (open) {
        document.body.style.top = `-${window.scrollY}px`
        document.body.style.position = 'fixed'
    } else {
        const scrollY = document.body.style.top
        document.body.style.position = ''
        document.body.style.top = ''
        // Для менюшки в МП надо при закрытии скролить вверх
        window.scrollTo(0, isMenuLinkClickMob ? 0 : Math.abs(parseInt(scrollY || '0', 10)))
    }
}
