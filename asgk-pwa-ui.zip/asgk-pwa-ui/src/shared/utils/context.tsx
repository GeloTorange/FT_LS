import { createContext, useContext, type PropsWithChildren } from 'react'

import type { DynamicFilterContextType, FilterContextType, FilterType } from '../types/context'


export const UniversalFilterContext = createContext<FilterContextType>({
    filter: {},
    setFilter: null
})

// Провайдер универсального фильтра с расширенной типизацией
export const UniversalFilterContextProvider = <T extends FilterType, >({
    children,
    filter,
    setFilter,
}: PropsWithChildren<DynamicFilterContextType<T>>) =>
    <UniversalFilterContext.Provider value={{ filter, setFilter } as unknown as FilterContextType}>
        {children}
    </UniversalFilterContext.Provider>

// Хук для получения контекста универсального фильтра с расширенной типизацией
export const useUniversalFilter = <F extends FilterType>() => {
    const context = useContext(UniversalFilterContext)

    if (!context){
        throw new Error('filter Context is undefined')
    }

    return context as unknown as DynamicFilterContextType<F>
}
