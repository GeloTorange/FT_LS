import dayjs, { type Dayjs } from 'dayjs'
import type { ChangeEvent } from 'react'

import { GraphAggregateFormats } from '../types/apexchart'
import { AggregateTypes } from '../types/filters'

import { DATE_FORMAT } from './defaultDatesHelper'

type FormattingVersion = {
    platform?: string
    version?: string
}

// Форматирует версию и платформу SBOL-а перед отображением
export const formattingVersion = ({ platform, version }: FormattingVersion) => {
    if (!platform) return '-'
    if (platform.toLowerCase() === 'web') {
        return 'Web'
    }
    if (platform.toLowerCase().includes('неизв')) {
        return 'Неизвестная платформа'
    }
    return `${version || '-'} (${platform})`
}

// Форматирование дат относительно AggregateTypes.
export const dateFormatter = (aggregateType: AggregateTypes) => (val: string) => {
    if (aggregateType === AggregateTypes.MONTH) {
        // окт
        return dayjs(val)
            .format(GraphAggregateFormats[aggregateType])
            .substring(0, 3)
    }
    // 05.10 или 1кв 24
    return dayjs(val)
        .format(GraphAggregateFormats[aggregateType])
}

// Парсим строку JSON безопасно
export const parseStrSafety = <T,>(value?: string | null ) => {
    let valueObj = null
    try {
        valueObj = value ? JSON.parse(value) as T : null
    } catch (e) {
        // comment: если в JSON.parse что-то пошло не так
        // eslint-disable-next-line no-console
        console.error(e)
    }

    return valueObj
}

// Функция для форматирования строки с ограничением длины
export const formatStringWithLimit = (str: string, maxLength: number) =>
    str.length > maxLength ? `${str.slice(0, maxLength)}...` : str

// Форматирование диапозона даты
export const formatDateRange = (start: Dayjs, end: Dayjs) =>
    `${dayjs(start).format('DD/MM/YYYY')} - ${dayjs(end).format('DD/MM/YYYY')}`

// Форматирование даты в формат для отображения (date формат 'YYYY-MM-DD')
export const dateToUIFormat = (date?: string | null, isShortYear?: boolean) =>
    date ? dayjs(date).format(DATE_FORMAT[isShortYear ? 'FRONTEND_SHORT_YEAR' : 'FRONTEND']) : '—'

const numberFormat = new Intl.NumberFormat(
    // В локали 'en-GB': К, М, В, Т
    'en-GB', {
        // сокращает длинные числа до более короткой формы (например, 1000 → 1K, 1000000 → 1M)
        notation: 'compact',
        // использует краткие обозначения (K, M, B, T), без пробелов
        compactDisplay: 'short',
    } as Intl.NumberFormatOptions
)

// Округляет до целых чисел и добавляет преписки:
//  K = тысячи (thousands),
//  M = миллион (million),
//  B = billion (миллиард),
//  T = trillion (триллион).
export const numShort = (number: number) => numberFormat.format(Number(number))

// То же самое, что numShort, но не показывает нуль
export const numShortWithoutZero = (val: number) => val ? numShort(val) : ''

export const onFormatedFromInputEventToString =
    (onChange: (value: string) => void) =>
        (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => { onChange(event.target.value) }
