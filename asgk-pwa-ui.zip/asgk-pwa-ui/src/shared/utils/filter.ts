import type { Dayjs } from 'dayjs'
import dayjs from 'dayjs'
import { useContext } from 'react'

import { TopicType } from '@shared/api/topics'
import { TRIGGER_TYPES_OPTIONS } from '@shared/api/triggers'

import { useSearchParamsHook } from '../hooks/useSearchParamsHook'
import { useWindowSize } from '../hooks/useWindowSize'
import type { FilterContextType, FilterType } from '../types/context'
import type { FilterFormData, GenerateFilterParams } from '../types/filters'

import { UniversalFilterContext } from './context'
import { DATE_FORMAT } from './defaultDatesHelper'
import { toObjTreeStructureValue } from './forTreeStructure'

// Обработка структуры
const structureProcessing = (structure?: string | null) => {
    const result: Record<string, string> = {}
    if (structure) {
        // Достаем unitId, tribeId, productId и чистим от пустых значений
        const { unitId, tribeId, productId } = toObjTreeStructureValue(structure)
        // надо именно так вставлять данные, чтобы вдруг лишние поля не проскочили
        if (unitId) {
            result.unitId = unitId
        }
        if (tribeId) {
            result.tribeId = tribeId
        }
        if (productId) {
            result.productId = productId
        }
    }
    return result
}

// Есть точки вызова, где даты передаются как строка
const formatDateValue = (value: string | Dayjs) =>
    typeof value === 'string' ? String(value) : dayjs(value).format(DATE_FORMAT.BACKEND)

// Возвращает объект строк для записи в params урла
export const generateFilterParams = (params: GenerateFilterParams) => {
    const result: Record<string, string> = {}
    // Берем только эти поля из всех, что передали
    const fieldsString = [
        'clientSegment',
        'unitId',
        'tribeId',
        'productId',
        'triggerType',
        'triggerId',
        'cmId',
        'searchWord',
        'trendType',
        'trendId',
        'versionSBOLId',
        'appealType',
        'factorica',
    ] as const
    // Все обычные поля приводим к строке
    fieldsString.forEach(field => {
        if (params[field]) {
            result[field] = String(params[field])
        }
    })
    const { structure, periodArray } = params

    // Даты обрабатываем
    if (periodArray) {
        result.startDate = formatDateValue(periodArray[0])
        result.endDate = formatDateValue(periodArray[1])
    }

    return {
        ...result,
        ...structureProcessing(structure)
    }
}

const applyDefaultFilter = {
    summaryId: null
}

type ApplyFilters = {
    values: FilterFormData
    isApply?: boolean
}
// Хук возвращает ф-ию применения фильтров для страницы "Прямая речь"
export const useApplyFiltersAfterForm = () => {
    const {
        setFilter
    } = useContext<FilterContextType>(UniversalFilterContext)
    const { setSearchParams } = useSearchParamsHook()

    return ({ values: valuesFilter, isApply }: ApplyFilters) => {
        if (isApply) {
            setSearchParams(
                generateFilterParams({ ...valuesFilter }),
                { replace: true }
            )
        }
        // TODO: когда уберем isApply, убрать это в reset
        const structureObj = isApply ? {} : { tribeId: null, productId: null }
        const appealType = isApply ? {} : { appealType: TopicType.appeal }
        // необходимо проставлять pageIndex = 1 для сохранения работоспособности
        // логики бесконечной загрузки прямой речи
        setFilter?.((filter) => ({
            ...filter,
            ...valuesFilter,
            ...structureObj,
            ...appealType,
            ...applyDefaultFilter,
            pageIndex: 1
        }))
    }
}

// TODO: везде где "as NonNullable<FilterType['periodArray']>"
//  - надо сузить типизацию в рамках рефакторинга этих страниц. Как пример TrendPage
export const getPeriodFromFilter = (periodArray: NonNullable<FilterType['periodArray']>) => ({
    startDate: periodArray[0].format(DATE_FORMAT.BACKEND),
    endDate: periodArray[1].format(DATE_FORMAT.BACKEND),
})

// В фильтрах есть связанные поля, тут регулируется их связь, как для формы так и для фильтров в тэгах
export const linkedFilterRules = (changedValues: FilterFormData ) => {
    switch (Object.keys(changedValues)[0]) {
        case 'structure':
            return {
                triggerType: TRIGGER_TYPES_OPTIONS[0].value,
                triggerId: null,
                trendId: null
            }
        case 'triggerType':
            return {
                triggerId: null,
                trendId: null
            }
        case 'triggerId':
            return {
                trendId: null
            }
        case 'marks':
            return {
                lowScore: false
            }
        case 'minLength':
            return {
                is300: false
            }
        default:
            return {}
    }
}


const MIN_WIDTH_SHOW_FULL_HEADER_FILTER = 1304
// Получить флаг узкий ли экран для фильтров в шапке
export const useIsShortWindowForFilter = () =>
    useWindowSize() < MIN_WIDTH_SHOW_FULL_HEADER_FILTER
