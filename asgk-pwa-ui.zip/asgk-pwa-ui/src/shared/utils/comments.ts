export const getCommentsTotalString = (total: number | null | undefined) => {
    if (total === null || total === undefined) {
        return null
    }

    if (total > 10000) {
        return (`${(10000).toLocaleString('ru-RU')}+`)
    }

    return (total.toLocaleString('ru-RU'))
}
