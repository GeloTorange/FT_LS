import { Space } from 'antd'
import React from 'react'

import { ArrowTopOutlined, ArrowBottomOutlined } from '../assets/icons'

// Возвращает прибыль или убыль значения в процентах
export function getProfitOrLossPercent (valIncr: number | null, valIncrPct: number | null) {
    if (valIncr === null || valIncrPct === null) {
        return '-'
    }

    const valIncrValue = Math.abs(valIncr).toFixed(2)
    const valIncrPctValue = Math.abs(valIncrPct).toFixed(1)

    if (valIncr === 0) {
        return `${valIncrValue} (${valIncrPctValue}%)`
    }

    const sign = valIncr > 0 ? '+' : '-'
    const Arrow = valIncr > 0 ? <ArrowTopOutlined /> : <ArrowBottomOutlined />

    return (
        <Space.Compact>
            {`${sign} ${valIncrValue} (`} {Arrow} {`${valIncrPctValue}%)`}
        </Space.Compact>
    )
}
