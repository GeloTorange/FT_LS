import type { ReactNode } from 'react'
import { flushSync } from 'react-dom'
import { createRoot } from 'react-dom/client'

export const toHtml = (node: ReactNode) => {
    const div = document.createElement('div')
    const root = createRoot(div)
    flushSync(() => { root.render(node) })
    return div.innerHTML
}
