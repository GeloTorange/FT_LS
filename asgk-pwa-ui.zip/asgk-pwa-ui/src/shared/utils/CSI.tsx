import type { RadioChangeEvent } from 'antd'
import { Space } from 'antd'
import type { MouseEvent } from 'react'


import { changeFavorite } from '../api/universal'
import { ArrowTopOutlined, ArrowBottomOutlined } from '../assets/icons'
import type { DynamicFilterContextType } from '../types/context'
import type { AggregateTypes } from '../types/filters'
import type { ListingTypes } from '../types/listingTypes'

// Определение окраски CSI
export function getTagColor (CSI: number): string {
    if (CSI <= 3) {
        return 'Red'
    }
    if (CSI > 3 && CSI <= 4) {
        return 'Yellow'
    }
    return 'Green'
}

export const getCommentsTagColor = (CSI: number): string => {
    switch (true) {
        case CSI <= 3:
            return 'Red'
        case CSI === 4:
            return 'Yellow'
        default :
            return 'Green'
    }
}

type ClickFavoriteArg = {
    id: number | string,
    isFavorite?: boolean,
    type: ListingTypes,
    loadData: () => void,
}
// Добавление/удаление избранного
export const clickFavorite = ({
    id,
    isFavorite,
    type,
    loadData,
}: ClickFavoriteArg) => (e: MouseEvent): void => {
    changeFavorite({ id: `${id}`, type, favorite: !isFavorite })
        .finally(() => { loadData() })

    e.stopPropagation()
}

export const getViewCSIIncrPct = (value?: number | null, isShared = false) => {
    if (value === null || value === undefined) {
        return '—'
    }

    const mask = isShared ? ' п.п.' : '%'

    if (value !== 0) {
        return (
            <Space.Compact>
                {value > 0 ? <ArrowTopOutlined/> : <ArrowBottomOutlined/>}
                {`${Math.abs(value).toFixed(1)}${mask}`}
            </Space.Compact>
        )
    }
    return `0${mask}`
}

export const onChangeRadioAggregateType = <T, >(
    setFilter: DynamicFilterContextType<T & {aggregateType: AggregateTypes}>['setFilter'],
) => (
    event: RadioChangeEvent,
) => {
    setFilter?.((filter) =>
        ({
            ...filter,
            aggregateType: event.target.value as AggregateTypes
        })
    )
}
