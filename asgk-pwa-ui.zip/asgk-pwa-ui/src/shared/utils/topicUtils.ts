import type { DatePickerProps, FormInstance } from 'antd'
import type { DefaultOptionType } from 'antd/es/select'
import type { Dayjs } from 'dayjs'
import dayjs from 'dayjs'

import type { SorterItem } from '../hooks/queryString'

export const optionsSorter = (a: DefaultOptionType, b: DefaultOptionType) => {
    const labelA = a.label || ''
    const labelB = b.label || ''
    /* comment: для удообства */
    /* eslint-disable-next-line no-nested-ternary */
    return (labelA < labelB) ? -1 : (labelA > labelB ? 1 : 0)
}

export const generateSortKey = <T extends string>(sorter: SorterItem<T>[]) => sorter.reduce((acc, item) =>
    `${acc}-${item.field}_${item.reverse ? 'desc' : 'asc'}`, '')

export const getDisabledStartDate = (form: FormInstance< { endDate?: Dayjs }>): DatePickerProps['disabledDate'] => 
    (current) => 
        (current > (form.getFieldsValue()?.endDate as Dayjs)) || (current < dayjs().subtract(6, 'month').startOf('day'))

export const getDisabledEndDate = (form: FormInstance<{ startDate?: Dayjs }>): DatePickerProps['disabledDate'] => 
    (current) =>
        (current < (form.getFieldsValue()?.startDate as Dayjs)) || (current > dayjs().endOf('day'))
