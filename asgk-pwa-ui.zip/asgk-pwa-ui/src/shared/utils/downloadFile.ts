type DownloadFileFromBase64 = {
    base64Data: string,
    typeFile: string,
    nameFile: string
}

export const downloadFileFromBase64 = ({
    base64Data,
    typeFile,
    nameFile
}: DownloadFileFromBase64) => {
    try {
        // 1️⃣ Очистка base64 (удаляем префикс, пробелы и переносы строк)
        const cleanBase64 = base64Data
            .replace(/^data:[^;]+;base64,/, '')
            .replace(/\s/g, '')
            .replace(/ /g, '+')

        // 2️⃣ Конвертация в бинарный массив
        const byteCharacters = atob(cleanBase64)
        const byteNumbers = new Array(byteCharacters.length)
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i)
        }

        const blob = new Blob([new Uint8Array(byteNumbers)], { type: typeFile })

        // 3️⃣ Создание временного URL и скачивание
        const url = URL.createObjectURL(blob)
        // debugger
        const link = document.createElement('a')
        link.href = url
        link.download = `${nameFile}.${typeFile}`
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        URL.revokeObjectURL(url)
    } catch (error) {
        // comment: важно вывести ошибку в консоль
        // eslint-disable-next-line no-console
        console.error('Ошибка при скачивании файла:', error)
    }
}
