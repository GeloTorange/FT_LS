import { Space } from 'antd'
import type { ReactNode } from 'react'
import React from 'react'

import { ArrowTopOutlined, ArrowBottomOutlined } from '../assets/icons'
import { TypographyBody } from '../components/typography'

export const getArrowValue = (value: number | null, suffix = '%'): ReactNode => {
    if (value === null) {
        return '-'
    }

    const absValue = Math.abs(value).toFixed(1)
    if (value > 0) {
        return (
            <>
                <ArrowTopOutlined data-testid={'arrow-top'} />
                {`${absValue}${suffix}`}
            </>
        )
    }
    if (value < 0) {
        return (
            <>
                <ArrowBottomOutlined data-testid={'arrow-bottom'} />
                {`${absValue}${suffix}`}
            </>
        )
    }
    return `${value}${suffix}`
}

export const getRightArrow = (value: number | null): ReactNode => (
    <Space.Compact style={{ marginLeft: 'auto' }}>
        <TypographyBody type={'secondary'}>{getArrowValue(value)}</TypographyBody>
    </Space.Compact>
)
