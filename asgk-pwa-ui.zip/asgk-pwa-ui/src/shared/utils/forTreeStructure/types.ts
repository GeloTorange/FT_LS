
export enum TreeStructureTypes {
    unitId = 'unitId',
    tribeId = 'tribeId',
    productId = 'productId',
}

export type ParsedStructureValue = Record<TreeStructureTypes, string | null>

export type ParamsStringifyValueForTree = {
    type: TreeStructureTypes,
    id: string
}

export type GetParamsInTreeStructure = {
    unitId: string | null
    tribeId: string | null
    productId: string | null
}
