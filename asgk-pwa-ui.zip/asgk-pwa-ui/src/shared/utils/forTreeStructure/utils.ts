import { parseStrSafety } from '../formatting'

import type { GetParamsInTreeStructure, ParamsStringifyValueForTree, ParsedStructureValue } from './types'
import { TreeStructureTypes } from './types'

// Делаем value для TreeSelect по структуре Сбера
export const stringifyValueForTree = ({ type, id }: ParamsStringifyValueForTree) =>
    JSON.stringify({ [type]: id })

// Получить значение, объект из TreeSelect, вида `{ tribeId: '123', productId: null }` из строки JSON
export const toObjTreeStructureValue = (value?: string | null ): ParsedStructureValue => {
    const initialFilter = {
        [TreeStructureTypes.unitId]: null,
        [TreeStructureTypes.tribeId]: null,
        [TreeStructureTypes.productId]: null,
    }
    const parsedStr = parseStrSafety(value)

    if (!parsedStr) {
        return initialFilter
    }

    return {
        ...initialFilter,
        ...parsedStr || null
    }
}

// Получить строку из объекта с tribeId и productId. Получится {"tribeId":"123"} для TreeSelect
export const toStrTreeStructureValue = ({
    unitId,
    tribeId,
    productId,
}: GetParamsInTreeStructure) => {
    const types = [
        { type: TreeStructureTypes.unitId, id: unitId },
        { type: TreeStructureTypes.tribeId, id: tribeId },
        { type: TreeStructureTypes.productId, id: productId }
    ]

    const foundType = types.find(({ id }) => id) as ParamsStringifyValueForTree | null

    if (foundType) {
        return stringifyValueForTree(foundType)
    }
    return null
}
