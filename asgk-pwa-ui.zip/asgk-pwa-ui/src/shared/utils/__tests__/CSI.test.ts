import { describe, it, expect } from 'vitest'
import { clickFavorite, getCommentsTagColor, getTagColor, getViewCSIIncrPct, onChangeRadioAggregateType } from '../CSI'
import type { RadioChangeEvent } from 'antd'
import { AggregateTypes } from '../../types/filters'
import type { FilterType } from '../../types/context'
import { ListingTypes } from '../../types/listingTypes'
import { changeFavorite } from '../../api/universal'
import { render } from '@testing-library/react'
import type { MouseEvent } from 'react'


describe('getCommentsTagColor', () => {
    it('должен возвращать "Red" для CSI <= 3', () => {
        expect(getCommentsTagColor(1)).toBe('Red')
    })

    it('должен возвращать "Yellow" для CSI === 4', () => {
        expect(getCommentsTagColor(4)).toBe('Yellow')
    })

    it('должен возвращать "Green" для CSI > 4', () => {
        expect(getCommentsTagColor(5)).toBe('Green')
    })
})

describe('getTagColor', () => {
    it('должен возвращать "Red" для значений <= 3', () => {
        expect(getTagColor(3)).toBe('Red')
    })

    it('должен возвращать "Yellow" для значений > 3 и <= 4', () => {
        expect(getTagColor(4)).toBe('Yellow')
    })

    it('должен возвращать "Green" для значений > 4', () => {
        expect(getTagColor(5)).toBe('Green')
    })
})


describe('clickFavorite', () => {
    vi.mock('../../api/universal', () => ({
        changeFavorite: vi.fn(() => Promise.resolve())
    }))
    const mockLoadData = vi.fn()
    const mockEvent = { stopPropagation: vi.fn() }

    afterEach(() => {
        vi.clearAllMocks()
    })

    it('вызывает changeFavorite с правильными аргументами (добавление в избранное)', async () => {
        const id = 123
        const type = ListingTypes.TREND

        const handler = clickFavorite({
            id,
            isFavorite: false,
            type,
            loadData: mockLoadData
        })

        handler(mockEvent as never as MouseEvent)

        // Проверяем вызов changeFavorite
        expect(changeFavorite).toHaveBeenCalledWith({
            id: '123',
            type: ListingTypes.TREND,
            favorite: true,
        })

        await new Promise(process.nextTick)
        expect(mockLoadData).toHaveBeenCalled()
    })

    it('вызывает changeFavorite с правильными аргументами (удаление из избранного)', async () => {
        const id = 'abc'
        const type = ListingTypes.TRIGGER

        const handler = clickFavorite({
            id,
            isFavorite: true,
            type,
            loadData: mockLoadData
        })

        handler(mockEvent as never as MouseEvent)

        expect(changeFavorite).toHaveBeenCalledWith({
            id: 'abc',
            type: ListingTypes.TRIGGER,
            favorite: false,
        })

        await new Promise(process.nextTick)
        expect(mockLoadData).toHaveBeenCalled()
    })

    it('вызывает stopPropagation на событии', () => {
        const handler = clickFavorite({
            id: 456,
            isFavorite: false,
            type: ListingTypes.TREND,
            loadData: mockLoadData,
        })

        handler(mockEvent as never as MouseEvent)

        expect(mockEvent.stopPropagation).toHaveBeenCalled()
    })
})

describe('getViewCSIIncrPct', () => {
    it('возвращает "—" для undefined', () => {
        expect(getViewCSIIncrPct(undefined)).toBe('—')
    })

    it('возвращает "—" для null', () => {
        expect(getViewCSIIncrPct(null)).toBe('—')
    })

    it('возвращает "0%" для нулевого значения', () => {
        expect(getViewCSIIncrPct(0)).toBe('0%')
    })

    it('возвращает "0 п.п." для нуля в режиме isShared', () => {
        expect(getViewCSIIncrPct(0, true)).toBe('0 п.п.')
    })

    it('возвращает корректный JSX для положительных значений', () => {
        const { container } = render(getViewCSIIncrPct(2.5))
        expect(container).toMatchSnapshot()
    })

    it('возвращает корректный JSX для отрицательных значений', () => {
        const { container } = render(getViewCSIIncrPct(-3.14))
        expect(container).toMatchSnapshot()
    })

    it('возвращает корректный JSX для isShared режима', () => {
        const { container } = render(
            getViewCSIIncrPct(1.23, true)
        )
        expect(container).toMatchSnapshot()
    })
})

describe('onChangeRadioAggregateType', () => {
    const mockFilter: FilterType = {
        clientSegment: 'test',
        aggregateType: AggregateTypes.MONTH
    }

    const mockSetFilter = vi.fn()

    it('должен обновлять aggregateType в фильтре', () => {
        const handler = onChangeRadioAggregateType(mockSetFilter)
        const mockEvent = {
            target: { value: AggregateTypes.WEEK }
        } as RadioChangeEvent

        handler(mockEvent)

        expect(mockSetFilter).toHaveBeenCalled()

        // comment: закомментировано для типов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        const updater = mockSetFilter?.mock.calls[0][0]
        expect(typeof updater).toBe('function')

        // comment: закомментировано для типов
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-call
        const result = updater(mockFilter)
        expect(result).toEqual({
            ...mockFilter,
            aggregateType: AggregateTypes.WEEK
        })
    })
})


