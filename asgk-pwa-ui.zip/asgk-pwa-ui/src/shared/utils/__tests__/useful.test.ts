import {
    checkIsDirty,
    formatedDate,
    onReloadPage,
    removeEmpty,
    truncateText,
} from '../useful'
import 'dayjs/locale/ru'
import dayjs from 'dayjs'

dayjs.locale('ru')

describe('removeEmpty', () => {
    it('должен возвращать объект без пустых значений', () => {
        const obj = {
            key1: 'value1',
            key2: null,
            key3: undefined,
            key4: '',
            key5: 'value5',
            key6: 0,
            key7: NaN,
        }

        const result = removeEmpty(obj)

        expect(result).toEqual({
            key1: 'value1',
            key5: 'value5',
            key6: 0,
        })
    })

    it('должен возвращать пустой объект, если все значения пустые', () => {
        const obj = {
            key1: null,
            key2: undefined,
            key3: '',
            key4: [],
            key5: NaN,
        }

        const result = removeEmpty(obj)

        expect(result).toEqual({})
    })

    it('должен возвращать исходный объект, если нет пустых значений', () => {
        const obj = {
            key1: 'value1',
            key2: {},
            key3: 0,
            key4: ['123'],
        }

        const result = removeEmpty(obj)

        expect(result).toEqual(obj)
    })
})


describe('Тестирование функции onReloadPage', () => {
    const original = window.location

    beforeAll(() => {
        Object.defineProperty(window, 'location', {
            configurable: true,
            value: { reload: vi.fn() },
        })
    })

    afterAll(() => {
        Object.defineProperty(window, 'location', { configurable: true, value: original })
    })

    it('Функция должна вызывать метод reload у объекта window.location', () => {
        // Выполняем функцию
        onReloadPage()

        // Проверяем, был ли вызван метод reload
        expect(global.window.location.reload).toHaveBeenCalledTimes(1)
    })
})


describe('Тестирование функции formatedDate', () => {
    it('<- вернёт корректную строку', () => {
        const formattedDate = formatedDate('2022-01-01')
        expect(formattedDate).toBe('01.01.2022')
    })

    it('<- вернёт корректную строку с кастомным форматом', () => {
        const formattedDate = formatedDate('2022-01-01', 'YYYY-MM-DD')
        expect(formattedDate).toBe('2022-01-01')
    })

    it('<- вернёт корректную строку с кастомным форматом MMMM', () => {
        const formattedDate = formatedDate('2022-01-01', 'MMMM')
        expect(formattedDate).toBe('январь')
    })

    it('<- вернёт пустую строку', () => {
        const daitring = 'invalid-date'
        const expectedFormattedDate = ''
        const formattedDate = formatedDate(daitring)
        expect(formattedDate).toBe(expectedFormattedDate)
    })
})

describe('truncateText', () => {
    it('должен обрезать текст до указанного лимита и добавить суффикс', () => {
        const result = truncateText('Это очень длинный текст', 10)
        expect(result).toBe('Это очень ...')
    })


    it('должен использовать пользовательский суффикс', () => {
        const result = truncateText('Текст с кастомным суффиксом', 10, ' [..]')
        expect(result).toBe('Текст с ка [..]')
    })

    it('должен работать с пустым текстом', () => {
        const result = truncateText('', 10)
        expect(result).toBe('')
    })

    it('должен работать с текстом, равным точно лимиту', () => {
        const result = truncateText('Ровно десять символов', 26)
        expect(result).toBe('Ровно десять символов')
    })

    it('должен обрезать текст даже при небольшом лимите', () => {
        const result = truncateText('abc', 2)
        expect(result).toBe('ab...')
    })
})

describe('checkIsDirty', () => {
    it('должен вернуть false, если все значения совпадают', () => {
        const snapshot = { a: 1, b: 'test', c: [1, 2], d: null }
        const values = { a: 1, b: 'test', c: [1, 2], d: null }
        expect(checkIsDirty(snapshot, values)).toBe(false)
    })

    it('должен вернуть true, если есть разница в примитивных типах', () => {
        const snapshot = { a: 1, b: 'test' }
        const values = { a: 1, b: 'another' }
        expect(checkIsDirty(snapshot, values)).toBe(true)
    })

    it('должен вернуть true, если есть разница в массивах', () => {
        const snapshot = { a: [1, 2] }
        const values = { a: [1, 3] }
        expect(checkIsDirty(snapshot, values)).toBe(true)
    })

    it('должен вернуть false, если массивы одинаковые', () => {
        const snapshot = { a: [1, 2] }
        const values = { a: [1, 2] }
        expect(checkIsDirty(snapshot, values)).toBe(false)
    })

    it('должен вернуть true, если длина массивов отличается', () => {
        const snapshot = { a: [1, 2] }
        const values = { a: [1, 2, 3] }
        expect(checkIsDirty(snapshot, values)).toBe(true)
    })

    it('должен корректно работать с undefined и null', () => {
        const snapshot = { a: null, b: undefined }
        const values = { a: null, b: undefined }
        expect(checkIsDirty(snapshot, values)).toBe(false)
    })

    it('должен вернуть true, если поле было удалено', () => {
        const snapshot = { a: 1 }
        const values = {}
        expect(checkIsDirty(snapshot, values)).toBe(true)
    })

    it('должен вернуть true, если добавлено новое поле', () => {
        const snapshot = {}
        const values = { a: 1 }
        expect(checkIsDirty(snapshot, values)).toBe(true)
    })
})
