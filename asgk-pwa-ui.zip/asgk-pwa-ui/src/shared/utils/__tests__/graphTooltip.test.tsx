import { render } from '@testing-library/react'

import { getRightArrow } from '../graphTooltip'

describe('getRightArrow', () => {
    it('должен возвращать "-" если значение равно null', () => {
        const { getByText } = render(getRightArrow(null))

        expect(getByText('-')).toBeInTheDocument()
    })

    it('должен возвращать значение и иконку стрелку вверх', () => {
        const { getByText, queryByTestId } = render(getRightArrow(10))

        expect(getByText('10.0%')).toBeInTheDocument()
        expect(queryByTestId('arrow-top')).toBeInTheDocument()
    })

    it('должен возвращать значение и иконку стрелку вниз', () => {
        const { getByText, queryByTestId } = render(getRightArrow(-10))

        expect(getByText('10.0%')).toBeInTheDocument()
        expect(queryByTestId('arrow-bottom')).toBeInTheDocument()
    })

    it('должен возвращать 0', () => {
        const { getByText, queryByTestId } = render(getRightArrow(0))

        expect(getByText('0%')).toBeInTheDocument()
        expect(queryByTestId('arrow-top')).not.toBeInTheDocument()
        expect(queryByTestId('arrow-bottom')).not.toBeInTheDocument()
    })
})
