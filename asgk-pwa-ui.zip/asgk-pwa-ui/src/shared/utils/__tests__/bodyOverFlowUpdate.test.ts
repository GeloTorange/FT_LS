import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { bodyOverFlowUpdate } from '../bodyOverFlowUpdate'

describe('bodyOverFlowUpdate', () => {
    beforeEach(() => {
        vi.spyOn(window, 'scrollTo').mockImplementation(() => {})
    })

    afterEach(() => {
        vi.restoreAllMocks()
        document.body.style.position = ''
        document.body.style.top = ''
    })

    it('должен фиксировать body и сохранять позицию скролла при open = true', () => {
        window.scrollY = 500
        bodyOverFlowUpdate()(true)

        expect(document.body.style.position).toBe('fixed')
        expect(document.body.style.top).toBe('-500px')
    })

    it('должен восстанавливать скролл и убирать фиксацию при open = false', () => {
        document.body.style.top = '-300px'
        document.body.style.position = 'fixed'

        bodyOverFlowUpdate()(false)

        expect(document.body.style.position).toBe('')
        expect(document.body.style.top).toBe('')
        expect(window.scrollTo).toHaveBeenCalledWith(0, 300)
    })

    it('должен сбрасывать скролл и убирать фиксацию при open = false и isMenuLinkClickMob=true', () => {
        document.body.style.top = '-300px'
        document.body.style.position = 'fixed'

        bodyOverFlowUpdate(true)(false)

        expect(document.body.style.position).toBe('')
        expect(document.body.style.top).toBe('')
        expect(window.scrollTo).toHaveBeenCalledWith(0, 0)
    })

    it('должен корректно обрабатывать отсутствие scrollY при open = false', () => {
        bodyOverFlowUpdate()(false)

        expect(document.body.style.position).toBe('')
        expect(document.body.style.top).toBe('')
        expect(window.scrollTo).toHaveBeenCalledWith(0, 0)
    })
})
