import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { downloadFileFromBase64 } from '../downloadFile'

describe('downloadFileFromBase64', () => {
    let createUrlSpy: ReturnType<typeof vi.spyOn>
    let revokeUrlSpy: ReturnType<typeof vi.spyOn>
    let appendSpy: ReturnType<typeof vi.spyOn>
    let removeSpy: ReturnType<typeof vi.spyOn>
    let clickSpy: ReturnType<typeof vi.spyOn>

    beforeEach(() => {
        // Поллифилим методы URL, если их нет в JSDOM
        if (!(URL as unknown as { createObjectURL?: unknown }).createObjectURL) {
            // добавляем метод в среду теста
            URL.createObjectURL = () => ''
        }
        if (!(URL as unknown as { revokeObjectURL?: unknown }).revokeObjectURL) {
            // добавляем метод в среду теста
            URL.revokeObjectURL = () => {}
        }

        // Шпионы на URL и DOM
        // @ts-expect-error - достаточно типизации
        createUrlSpy = vi.spyOn(URL, 'createObjectURL').mockReturnValue('blob:mock')
        revokeUrlSpy = vi.spyOn(URL, 'revokeObjectURL').mockImplementation(() => {})
        // @ts-expect-error - достаточно типизации
        appendSpy = vi.spyOn(document.body, 'appendChild')
        // @ts-expect-error - достаточно типизации
        removeSpy = vi.spyOn(document.body, 'removeChild')
        clickSpy = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {})
    })

    afterEach(() => {
        vi.restoreAllMocks()
    })

    it('скачивает файл из base64: создает Blob, ссылку, кликает и ревокает URL', () => {
        // base64 для слова "hello" с префиксом и лишними пробелами/переносами
        const base64 = 'data:text/csv;base64, aGVs\n bG8='

        let createdLink = null as HTMLAnchorElement | null
        const origCreateElement = document.createElement.bind(document)
        const createElementSpy = vi
            .spyOn(document, 'createElement')
            .mockImplementation((tagName: string) => {
                const el = origCreateElement(tagName)
                if (tagName.toLowerCase() === 'a') {
                    createdLink = el as HTMLAnchorElement
                }
                return el
            })

        downloadFileFromBase64({
            base64Data: base64,
            typeFile: 'text/csv',
            nameFile: 'report',
        })

        // Проверяем создание URL
        expect(createUrlSpy).toHaveBeenCalledTimes(1)
        const blobArg = createUrlSpy.mock.calls[0][0] as Blob
        expect(blobArg).toBeInstanceOf(Blob)
        expect(blobArg.type).toBe('text/csv')
        expect(blobArg.size).toBeGreaterThan(0)

        // Проверяем работу со ссылкой и DOM
        expect(createElementSpy).toHaveBeenCalledWith('a')
        expect(appendSpy).toHaveBeenCalled()
        expect(clickSpy).toHaveBeenCalledTimes(1)
        expect(removeSpy).toHaveBeenCalled()
        expect(revokeUrlSpy).toHaveBeenCalledWith('blob:mock')

        // Проверяем атрибут download согласно текущей реализации
        expect(createdLink?.download).toBe('report.text/csv')
    })

    it('логирует ошибку, если atob выбрасывает исключение', () => {
        const atobSpy = vi.spyOn(globalThis, 'atob').mockImplementation(() => {
            throw new Error('bad base64')
        })
        const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})

        downloadFileFromBase64({ base64Data: 'not-base64', typeFile: 'text/csv', nameFile: 'file' })

        expect(consoleSpy).toHaveBeenCalled()
        // Не должен создаваться объект URL
        expect(URL.createObjectURL).not.toHaveBeenCalled()

        atobSpy.mockRestore()
        consoleSpy.mockRestore()
    })
})
