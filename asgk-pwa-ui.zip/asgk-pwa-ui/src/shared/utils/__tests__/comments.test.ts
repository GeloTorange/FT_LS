import { getCommentsTotalString } from '../comments'

describe('getCommentsTotalString', () => {
    it('Должна вернуть "> 10 000" для значений больше 10000', () => {
        const result = getCommentsTotalString(11000)
        expect(result).toBe(`${(10000).toLocaleString('ru-RU')}+`)
    })

    it('Должна вернуть локализированное число для значений меньше или равных 10000', () => {
        const result = getCommentsTotalString(2500)
        expect(result).toBe((2500).toLocaleString('ru-RU'))
    })

    it('Должна вернуть 0 для 0', () => {
        const result = getCommentsTotalString(0)
        expect(result).toBe((0).toLocaleString('ru-RU'))
    })

    it('Должна корректно обрабатывать null', () => {
        const result = getCommentsTotalString(null)
        expect(result).toBe(null)
    })

    it('Должна корректно обрабатывать undefined', () => {
        const result = getCommentsTotalString(undefined)
        expect(result).toBe(null)
    })
})