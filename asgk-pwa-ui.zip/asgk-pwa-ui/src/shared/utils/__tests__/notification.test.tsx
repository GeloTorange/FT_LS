import { describe, beforeEach, it, expect, vi } from 'vitest'
import { render } from '@testing-library/react'
import React from 'react'


// Моки для message и notification
const mockMessage = {
    success: vi.fn(),
    error: vi.fn(),
    info: vi.fn(),
    warning: vi.fn(),
    loading: vi.fn(),
}

const mockNotification = {
    success: vi.fn(),
    error: vi.fn(),
    info: vi.fn(),
    warning: vi.fn(),
    open: vi.fn(),
}

vi.mock('antd', () => ({
    App: {
        useApp: vi.fn(() => ({
            message: mockMessage,
            notification: mockNotification,
        })),
    },
}))

describe('notification utility', () => {
    beforeEach(async () => {
        vi.resetModules()
    })

    it('should initialize message and notification after render', async () => {

        const Notification = (await import('../notification')).default
        const { message, notification } = await import('../notification')

        expect(message).toBeUndefined()
        expect(notification).toBeUndefined()

        render(<Notification />)

        const { message: updatedMessage, notification: updatedNotification } = await import('../notification')

        // Проверяем, что переменные инициализированы
        expect(updatedMessage).toBeDefined()
        expect(updatedNotification).toBeDefined()
        expect(updatedMessage).toEqual(mockMessage)
        expect(updatedNotification).toEqual(mockNotification)
    })
})
