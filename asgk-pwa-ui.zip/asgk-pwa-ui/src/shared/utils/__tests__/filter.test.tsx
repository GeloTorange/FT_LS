import dayjs from 'dayjs'

import { generateFilterParams, useApplyFiltersAfterForm, getPeriodFromFilter, linkedFilterRules } from '../filter'
import { renderHook } from '@testing-library/react-hooks'
import { mockInitFilter } from './const'
import type { PropsWithChildren } from 'react'
import { UniversalFilterContext } from '../context'
import type { FilterFormData, GenerateFilterParams } from '../../types/filters'
import { TrendTypes } from '../../api/trends'
import { TopicType } from '@shared/api/topics'


// Мокаем react-device-detect
vi.mock('react-device-detect')

const mockSetFilter = vi.fn()
const mockSetSearchParams = vi.fn()
const wrapper = ({ children }: PropsWithChildren) => (
    <UniversalFilterContext.Provider value={{ setFilter: mockSetFilter, filter: mockInitFilter }}>
        {children}
    </UniversalFilterContext.Provider>
)

vi.mock('@shared/hooks/useSearchParamsHook', () => ({
    useSearchParamsHook: vi.fn(() => ({
        setSearchParams: mockSetSearchParams,
    })),
}))

const testStartDate = '2022-01-01'
const testEndDate = '2022-01-31'

describe('Тестирование хука useApplyFiltersAfterForm', () => {
    afterEach(() => {
        vi.clearAllMocks()
        vi.resetAllMocks()
    })

    it('Правильное применение фильтров при isApply = true', () => {
        const { result } = renderHook(() => useApplyFiltersAfterForm(), { wrapper })

        const values = {
            structure: '{"tribeId":"1"}',
            periodArray: [dayjs('2023-01-01'), dayjs('2023-01-31')],
            triggerType: 'type1',
            triggerId: 'id1',
        } as FilterFormData

        result.current({ values, isApply: true })
        expect(mockSetSearchParams).toHaveBeenCalledWith(
            {
                triggerType: 'type1',
                triggerId: 'id1',
                startDate: '2023-01-01',
                endDate: '2023-01-31',
                tribeId: '1'
            },
            {
                'replace': true,
            },
        )
        expect(mockSetSearchParams).toHaveBeenCalledWith(
            {
                tribeId: '1',
                startDate: '2023-01-01',
                endDate: '2023-01-31',
                triggerType: 'type1',
                triggerId: 'id1',
            },
            { replace: true }
        )
    })

    it('Фильтры не применяются в url при isApply = false, типа сброс', () => {
        const { result } = renderHook(() => useApplyFiltersAfterForm(), { wrapper })

        const values = {
            structure: '{"tribeId":"1"}',
            periodArray: [dayjs('2023-01-01'), dayjs('2023-01-31')],
            appealType: TopicType.appeal,
        } as FilterFormData

        const applyDefaultFilter = {
            summaryId: null
        }

        result.current({ values, isApply: false })
        // comment: тут не нужна типизация
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment,@typescript-eslint/no-unsafe-call
        const resultCallSetFilter = mockSetFilter.mock.calls[0][0]({})
        expect(resultCallSetFilter).toEqual({
            ...values,
            ...applyDefaultFilter,
            productId: null,
            tribeId: null,
            pageIndex: 1,
        })
        expect(mockSetSearchParams).not.toHaveBeenCalled()
    })
})

describe('generateFilterParams', () => {
    it('должен возвращать объект со всеми параметрами', () => {
        const params = {
            clientSegment: 'segment',
            tribeId: 'tribe',
            productId: 'product',
            triggerType: 'type',
            triggerId: 'id',
            periodArray: [dayjs(testStartDate), dayjs(testEndDate)],
            searchWord: 'word',
            trendType: TrendTypes.NEGATIVE,
            trendId: 'trendId',
        } as GenerateFilterParams

        expect(generateFilterParams(params)).toEqual({
            clientSegment: 'segment',
            tribeId: 'tribe',
            productId: 'product',
            triggerType: 'type',
            triggerId: 'id',
            startDate: testStartDate,
            endDate: testEndDate,
            searchWord: 'word',
            trendType: TrendTypes.NEGATIVE,
            trendId: 'trendId',
        })
    })

    it('должен возвращать объект с заполненными параметрами', () => {
        const params = {
            clientSegment: 'segment',
            tribeId: 'tribe',
            searchWord: null,
            periodArray: [dayjs(testStartDate), dayjs(testEndDate)],
        } as GenerateFilterParams

        const result = generateFilterParams(params)

        expect(result).toEqual({
            clientSegment: 'segment',
            tribeId: 'tribe',
            startDate: testStartDate,
            endDate: testEndDate,
        })
    })

    it('должен возвращать объект с заполненными параметрами, даты передали как строки', () => {
        const params = {
            clientSegment: 'segment',
            tribeId: 'tribe',
            searchWord: null,
            periodArray: [testStartDate, testEndDate],
        } as GenerateFilterParams

        const result = generateFilterParams(params)

        expect(result).toEqual({
            clientSegment: 'segment',
            tribeId: 'tribe',
            startDate: testStartDate,
            endDate: testEndDate,
        })
    })

    it('должен возвращать только те поля, что есть в списке доступных для вывода в урл', () => {
        const result = generateFilterParams({
            is300: true,
            clientSegment: 'segment',
            tribeId: 'tribe',
        } as GenerateFilterParams)

        expect(result).toEqual({
            clientSegment: 'segment',
            tribeId: 'tribe'
        })
    })

    it('должен возвращать данные из структуры если передали и трайб, и структуру', () => {
        const result = generateFilterParams({
            tribeId: 'tribe',
            structure: '{"tribeId":"1"}',
        })

        expect(result).toEqual({ tribeId: '1' })
    })

    it('должен возвращать данные из структуры если передали и продукт, и структуру', () => {
        const result = generateFilterParams({
            productId: 'product',
            structure: '{"productId":"2"}',
        })

        expect(result).toEqual({ productId: '2' })
    })

    it('должен возвращать данные из productId если передали некорректную структуру', () => {
        const result = generateFilterParams({
            productId: 'product',
            structure: '{"cmId":"2"}',
        })

        expect(result).toEqual({ productId: 'product' })
    })

    it('должен возвращать пустой объект, если не предоставлены параметры', () => {
        const result = generateFilterParams({})

        expect(result).toEqual({})
    })
})

describe('useGetPeriodFromFilter', () => {
    it('вызов useGetPeriodFromFilter с данными', () => {
        const period = getPeriodFromFilter([
            dayjs(testStartDate),
            dayjs(testEndDate)
        ])
        expect(period).toEqual({ startDate: testStartDate, endDate: testEndDate })
    })
})



describe('Тестирование функции linkedFilterRules', () => {
    it('При изменении поля "structure" должны сброситься triggerType и triggerId', () => {
        const changedValues = { structure: '{"tribeId":"1"}' }
        const result = linkedFilterRules(changedValues)

        expect(result).toEqual({
            triggerType: null,
            triggerId: null,
            trendId: null,
        })
    })

    it('При изменении поля "triggerType" должен сброситься triggerId', () => {
        const changedValues = { triggerType: 'type1' } as FilterFormData
        const result = linkedFilterRules(changedValues)

        expect(result).toEqual({
            triggerId: null,
            trendId: null,
        })
    })

    it('При изменении поля "marks" должен сброситься lowScore', () => {
        const changedValues = { marks: [1] } as FilterFormData
        const result = linkedFilterRules(changedValues)

        expect(result).toEqual({
            lowScore: false,
        })
    })

    it('При изменении поля "minLength" должен сброситься is300', () => {
        const changedValues = { minLength: '50' } as FilterFormData
        const result = linkedFilterRules(changedValues)

        expect(result).toEqual({
            is300: false,
        })
    })

    it('Для других полей не должно происходить никаких изменений', () => {
        const changedValues = { someOtherField: 'value' }
        const result = linkedFilterRules(changedValues as never)

        expect(result).toEqual({})
    })
})
