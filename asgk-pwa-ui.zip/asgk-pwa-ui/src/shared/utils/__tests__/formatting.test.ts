import { describe, it, expect } from 'vitest'
import dayjs from 'dayjs'
import {
    formattingVersion,
    dateFormatter,
    parseStrSafety,
    formatStringWithLimit,
    formatDateRange,
    dateToUIFormat
} from '../formatting'
import { AggregateTypes } from '../../types/filters'
import 'dayjs/locale/ru'

dayjs.locale('ru')

describe('Тестирование функции formattingVersion', () => {
    it('возвращает "-" если платформа отсутствует', () => {
        const input = {}
        const output = formattingVersion(input)
        expect(output).toBe('-')
    })

    it('возвращает "Web" если пришел web', () => {
        const input = { platform: 'wEb' }
        const output = formattingVersion(input)
        expect(output).toBe('Web')
    })

    it('работает независимо от регистра платформы', () => {
        const input = { platform: 'WEB' }
        const output = formattingVersion(input)
        expect(output).toBe('Web')
    })

    it('вернет "Неизвестная платформа" независимо от регистра', () => {
        const input = { platform: 'неИзвестная ПЛатформ' }
        const output = formattingVersion(input)
        expect(output).toBe('Неизвестная платформа')
    })

    it('форматирует версию и платформу правильно', () => {
        const input = { platform: 'Android', version: '1.0' }
        const output = formattingVersion(input)
        expect(output).toBe('1.0 (Android)')
    })

    it('возвращает "- (-)" если версия отсутствует', () => {
        const input = { platform: 'iOS' }
        const output = formattingVersion(input)
        expect(output).toBe('- (iOS)')
    })
})

describe('dateFormatter', () => {
    it('должен корректно форматировать дату для типа MONTH', () => {
        // Пример входной даты
        const mockDate = '2023-10-05'
        const formattedDate = dateFormatter(AggregateTypes.MONTH)(mockDate)
        // Проверяем, что результат соответствует ожидаемому формату (Oct или Окт)
        expect(formattedDate).toBe('окт')
    })

    it('должен корректно форматировать дату для других типов', () => {
        // Пример входной даты
        const mockDate = '2023-10-05'
        // Другой тип агрегации
        const aggregateType = AggregateTypes.WEEK

        const formattedDate = dateFormatter(aggregateType)(mockDate)

        // Проверяем, что результат соответствует ожидаемому формату, 05.10
        expect(formattedDate).toBe('05.10')
    })
})

describe('dateToUIFormat', () => {
    it('должен корректно форматировать дату', () => {
        // Пример входной даты
        const mockDate = '2023-10-05'
        const formattedDate = dateToUIFormat(mockDate)
        // Проверяем, что результат соответствует ожидаемому формату
        expect(formattedDate).toBe('05.10.2023')
    })

    it('должен корректно форматировать дату в сокращенно формате', () => {
        // Пример входной даты
        const mockDate = '2023-10-05'
        const formattedDate = dateToUIFormat(mockDate, true)
        // Проверяем, что результат соответствует ожидаемому формату
        expect(formattedDate).toBe('05.10.23')
    })

    it('должен корректно форматировать отсутсвие данных', () => {
        // Пример входной даты
        const mockDate = null
        const formattedDate = dateToUIFormat(mockDate)

        // Проверяем, что результат соответствует ожидаемому формату
        expect(formattedDate).toBe('—')
    })
})

describe('parseStrSafety', () => {
    it('должен безопасно парсить валидный JSON', () => {
        const validJson = '{"key": "value"}'
        const result = parseStrSafety<{ key: string }>(validJson)

        // Проверяем, что результат соответствует ожидаемому объекту
        expect(result).toEqual({ key: 'value' })
    })

    it('должен возвращать {} для пустого объекта', () => {
        const result = parseStrSafety('{}')

        // Проверяем, что результат равен null
        expect(result).toEqual({})
    })

    it('должен возвращать null для undefined, пустой строки и null', () => {
        const result = parseStrSafety(undefined)
        const result2 = parseStrSafety('')
        const result3 = parseStrSafety(null)

        // Проверяем, что результат равен null
        expect(result).toBeNull()
        expect(result2).toBeNull()
        expect(result3).toBeNull()
    })

    it('должен обрабатывать ошибки при некорректном JSON', () => {
        const invalidJson = '{invalid-json}'
        const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {})

        const result = parseStrSafety(invalidJson)

        // Проверяем, что результат равен null
        expect(result).toBeNull()

        // Проверяем, что была вызвана console.error
        expect(consoleErrorSpy).toHaveBeenCalled()

        // Восстанавливаем оригинальную реализацию console.error
        consoleErrorSpy.mockRestore()
    })
})

describe('formatStringWithLimit', () => {
    it('должен обрезать строку, если её длина превышает maxLength', () => {
        const result = formatStringWithLimit('This is a long string', 10)
        expect(result).toBe('This is a ...')
    })

    it('не должен обрезать строку, если её длина меньше или равна maxLength', () => {
        const result = formatStringWithLimit('Short', 10)
        expect(result).toBe('Short')
    })

    it('должен корректно работать с пустой строкой', () => {
        const result = formatStringWithLimit('', 5)
        expect(result).toBe('')
    })

    it('должен корректно работать с граничным значением maxLength', () => {
        const result = formatStringWithLimit('ExactLength', 10)
        expect(result).toBe('ExactLengt...')
    })
})

describe('formatDateRange', () => {
    it('должен корректно форматировать диапазон дат', () => {
        const start = dayjs('2023-10-01')
        const end = dayjs('2023-10-10')

        const result = formatDateRange(start, end)
        expect(result).toBe('01/10/2023 - 10/10/2023')
    })

    it('должен корректно работать с одинаковыми датами', () => {
        const date = dayjs('2023-10-01')

        const result = formatDateRange(date, date)
        expect(result).toBe('01/10/2023 - 01/10/2023')
    })

    it('должен корректно работать с невалидными датами', () => {
        const invalidDate = dayjs('invalid-date')

        const result = formatDateRange(invalidDate, invalidDate)
        expect(result).toBe('Invalid Date - Invalid Date')
    })
})
