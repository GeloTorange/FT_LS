import dayjs from 'dayjs'

import { TrendTypes } from '../../api/trends'
import type { FilterType } from '../../types/context'

export const mockInitFilter = {
    clientSegment: 'segment1',
    structure: '{"tribeId":"tribe1"}',
    triggerId: 'trigger1',
    triggerType: 'type1',
    trendId: 'trend1',
    trendType: TrendTypes.NEGATIVE,
    versionSBOLId: 'version1',
    marks: [],
    lowScore: false,
    minLength: null,
    cmId: 'cm1',
    is300: false,
    searchWord: 'word1',
    periodArray: [dayjs('2023-10-01'), dayjs('2023-10-05')],
    pageIndex: 1,
} as FilterType

