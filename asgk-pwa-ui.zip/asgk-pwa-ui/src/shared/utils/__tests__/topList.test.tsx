import { Space } from 'antd'

import { ArrowBottomOutlined, ArrowTopOutlined } from '../../assets/icons'

import { getProfitOrLossPercent } from '../topList'

describe('getProfitOrLossPercent', () => {
    it('должен возвращать "-" если значение равно null', () => {
        const result = getProfitOrLossPercent(null, null)

        expect(result).toEqual('-')
    })

    it('должен возвращать значение без знака', () => {
        const result = getProfitOrLossPercent(0, 0)

        expect(result).toEqual('0.00 (0.0%)')
    })

    it('должен возвращать значение с положительным знаком и стрелкой вверх', () => {
        const result = getProfitOrLossPercent(10, 10)

        expect(result).toEqual(
            <Space.Compact>
                {'+ 10.00 ('} <ArrowTopOutlined /> {'10.0%)'}
            </Space.Compact>
        )
    })

    it('должен возвращать значение с отрицательным знаком и стрелкой вниз', () => {
        const result = getProfitOrLossPercent(-10, -10)

        expect(result).toEqual(
            <Space.Compact>
                {'- 10.00 ('} <ArrowBottomOutlined /> {'10.0%)'}
            </Space.Compact>
        )
    })
})


