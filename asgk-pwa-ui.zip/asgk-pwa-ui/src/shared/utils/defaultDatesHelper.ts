import dayjs from 'dayjs'

// Чтобы правильно формировались дефолтные даты - размещаем сюда локаль
dayjs.locale('ru')

export const DATE_FORMAT = {
    BACKEND: 'YYYY-MM-DD',
    FRONTEND: 'DD.MM.YYYY',
    FRONTEND_SHORT_YEAR: 'DD.MM.YY',
}


export const today = dayjs()
export const yesterday = dayjs().subtract(1, 'day')

export const defaultStartDateShort = yesterday.subtract(7, 'day')
export const defaultStartDate = yesterday.subtract(30, 'day')

export const defaultStartWeekShort = yesterday.startOf('week').subtract(3, 'week')
export const defaultStartWeek = yesterday.startOf('week').subtract(29, 'week')

export const defaultStartMonth = yesterday.startOf('month').subtract(5, 'month')

const endDate = yesterday.format(DATE_FORMAT.BACKEND)

type DateForFilter = { startDateShort?: string, startDate: string, endDate: string }
export const filterPeriod: Record<string, DateForFilter> = {
    DAY: {
        startDateShort: defaultStartDateShort.format(DATE_FORMAT.BACKEND),
        startDate: defaultStartDate.format(DATE_FORMAT.BACKEND),
        endDate,
    },
    WEEK: {
        startDateShort: defaultStartWeekShort.format(DATE_FORMAT.BACKEND),
        startDate: defaultStartWeek.format(DATE_FORMAT.BACKEND),
        endDate,
    },
    MONTH: {
        // TODO startDateShort не хватает, чтобы лишний раз не типизировать когда используешь startDateShort
        startDate: defaultStartMonth.format(DATE_FORMAT.BACKEND),
        endDate,
    },
}
