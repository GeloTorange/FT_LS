import dayjs from 'dayjs'
import React from 'react'

// Очистка объекта от пустых значений и массивов, кроме 0
export const removeEmpty = <T extends Record<string, unknown>>( obj: T): T =>
    Object.fromEntries(
        Object.entries(obj).filter(([, value]) => {
            if (Array.isArray(value)) {
                return value?.length > 0
            }
            // Важно чтобы 0 пропускал
            if (value === 0) {
                return true
            }
            // Все остальные кейсы
            return !!value
        })
    ) as T
// Перезагрузка страницы
export const onReloadPage = () => { window.location.reload() }

// Возврат на предыдущую страницу
export const onBackPage = () => { history.back() }

// Удобный вариант форматирования даты
export const formatedDate = (dateString: string, format = 'DD.MM.YYYY'): string => {
    if (dayjs(dateString).isValid()) {
        return dayjs(dateString).format(format)
    }
    return ''
}

export const typedMemo: <T>(c: T) => T = React.memo

// Проверка, что все поля заполнены
export const checkIsAllFilled = <T extends Record<string, unknown>>(fields: T) =>
    Object.values(fields).every(v => !!v)

// Проверка полей на изменения
export const checkIsDirty = <T extends Record<string, unknown>>(
    snapshotFields:T, allValues: T
) => {
    const keys = Object.keys(snapshotFields)
    if (keys.length) {
        return keys.some(key => {
            const initialValue = snapshotFields[key]
            const actualValue = allValues[key]
            // Если массивы, то проверяем длину и каждый элемент
            if (Array.isArray(initialValue) && Array.isArray(actualValue)) {
                return (
                    initialValue.length !== actualValue.length ||
                    initialValue.some((v, i) => actualValue[i] !== v)
                )
            }
            return initialValue !== actualValue
        })
    }
    return keys !== Object.keys(allValues)
}

export const truncateText = (
    text: string,
    limit = 100,
    suffix = '...'
): string => {
    if (text.length <= limit) return text.trim()
    return (text.slice(0, limit) + suffix).trim()
}
