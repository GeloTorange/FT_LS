import { render, screen } from '@testing-library/react'
import { useSelector } from 'react-redux'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { getIsDarkTheme } from '@entities/appTheme'

import { useGetAntdTheme } from '..'
import { darkTheme } from '../darkTheme'
import { lightTheme } from '../lightTheme'

// Мокаем зависимости
vi.mock('react-redux', async (importActual) => {
    // comment: импорт оригинала нужен
    // eslint-disable-next-line @typescript-eslint/consistent-type-imports
    const actual = await importActual<typeof import('react-redux')>()
    return {
        ...actual,
        useSelector: vi.fn(),
    }
})
vi.mock('@entities/appTheme', () => ({
    getIsDarkTheme: vi.fn(),
}))

const mockedUseSelector = vi.mocked(useSelector)

// Простой компонент для тестирования вывода хука
const TestComponent = () => {
    const theme = useGetAntdTheme()
    return <div data-testid={'theme-output'}>{JSON.stringify(theme)}</div>
}

describe('useGetAntdTheme', () => {
    beforeEach(() => {
        // Очищаем историю моков перед каждым тестом
        mockedUseSelector.mockClear()
    })

    it('должен возвращать darkTheme, когда isDarkMode равен true', () => {
        mockedUseSelector.mockReturnValue(true)

        render(<TestComponent />)

        expect(mockedUseSelector).toHaveBeenCalledWith(getIsDarkTheme)
        const themeOutput = screen.getByTestId('theme-output')
        expect(JSON.parse(themeOutput.textContent || '')).toEqual(darkTheme)
    })

    it('должен возвращать lightTheme, когда isDarkMode равен false', () => {
        mockedUseSelector.mockReturnValue(false)

        render(<TestComponent />)

        expect(mockedUseSelector).toHaveBeenCalledWith(getIsDarkTheme)
        const themeOutput = screen.getByTestId('theme-output')
        expect(JSON.parse(themeOutput.textContent || '')).toEqual(lightTheme)
    })
})

