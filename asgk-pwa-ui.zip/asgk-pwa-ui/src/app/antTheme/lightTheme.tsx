import type { ThemeConfig } from 'antd'

import { colors } from '../../shared/styles'

import { defaultAntdTheme } from './baseConfig'

const {
    white,
    black,
    black55Alpha,
    gray1,
} = colors

export const lightTheme: ThemeConfig = {
    ...defaultAntdTheme,
    // в токены можно класть только цвета, css-var переменные НЕЛЬЗЯ
    token: {
        ...defaultAntdTheme.token,
        colorBgBase: white,
        colorText: black,
        // colorTextBase добавляет 0.88 прозрачности для цвета, что указывается. Поэтому добавлен colorText
        colorTextBase: black,
        colorTextDescription: black55Alpha,
        colorBorder: gray1,
    },
}
