import type { ThemeConfig } from 'antd'

import { colors } from '../../shared/styles'

import { defaultAntdTheme } from './baseConfig'

const {
    black4,
    white,
    white47Alpha,
    black2,
} = colors

export const darkTheme: ThemeConfig = {
    ...defaultAntdTheme,
    // в токены можно класть только цвета, css-var переменные НЕЛЬЗЯ
    token: {
        ...defaultAntdTheme.token,
        colorBgBase: black4,
        colorText: white,
        // colorTextBase добавляет 0.88 прозрачности для цвета, что указывается. Поэтому добавлен colorText
        colorTextBase: white,
        colorTextDescription: white47Alpha,
        colorBorder: black2,
    },
}
