import type { ThemeConfig } from 'antd'

import { colors } from '../../shared/styles'

const {
    greenLight,
    greenLight16A,

    Background1,
    Background2,
    BackgroundActive,
    BackgroundActiveHover,
    Background4,
    Chips,
    TextPrimary,
    TextSecondary,

    DividerThin,
    DividerFat,
} = colors

export const defaultAntdTheme: ThemeConfig = {
    components: {
        Menu: {
            itemActiveBg: Background2,
            itemSelectedColor: greenLight,
            itemSelectedBg: Background1,
            itemBorderRadius: 0,
            marginXXS: 0,
            controlHeightLG: 80,
            iconSize: 24,
            collapsedIconSize: 24,
            algorithm: true,
        },
        Layout: {
            headerBg: Background4,
            siderBg: Background4,
        },
        // тут возможно стоит пересмотреть, так как все карточки станут одинаково меняться
        Card: {
            colorBorder: Background1,
            colorBgContainer: Background1,
            colorBorderSecondary: Background1,
            paddingLG: 16,
        },
        Tabs: {
            lineWidthBold: 3,
        },
        Button: {
            borderRadius: 4,
            borderRadiusLG: 8,
            borderRadiusSM: 4,
            primaryShadow: 'none',
        },
        Tag: {
            borderRadiusSM: 8,
            defaultBg: Chips,
            colorBorder: undefined,
        },
        Pagination: {
            borderRadius: 8,
        },
        Dropdown: {
            // greenLight16A // сделано так, чтобы соотв-ть макетам
            controlItemBgActive: BackgroundActive,
            // greenLight16A // Это Лиза решила
            controlItemBgActiveHover: BackgroundActiveHover,
            colorBgElevated: Background4
        },
        Select: {
            borderRadius: 8,
            borderRadiusLG: 8,
            optionSelectedBg: greenLight16A,
            optionFontSize: 14,
            colorBgElevated: Background4
        },
        TreeSelect: {
            borderRadius: 8,
            borderRadiusLG: 8,
            nodeSelectedBg: greenLight16A,
            colorBgElevated: Background4,
            fontSize: 14,
        },
        Input: {
            borderRadius: 8,
            borderRadiusLG: 8,
        },
        InputNumber: {
            borderRadius: 8,
            borderRadiusLG: 8,
        },
        DatePicker: {
            borderRadius: 8,
            borderRadiusLG: 8,
            cellActiveWithRangeBg: greenLight16A,
            colorBgElevated: Background4
        },
        Checkbox: {
            borderRadiusSM: 4,
        },
        Radio: {
            borderRadius: 8,
            colorTextDisabled: TextSecondary,
        },
        Table: {
            fontSize: 14,
            fontWeightStrong: 500,
            headerBorderRadius: 0,
            borderColor: DividerFat,
            headerSplitColor: DividerFat,
        },
        Segmented: {
            borderRadius: 4,
            borderRadiusLG: 4,
            borderRadiusSM: 4,
        },
        Notification: {
            borderRadiusLG: 8,
        },
        Form: {
            itemMarginBottom: 20
        },
        Popover: {
            colorBgElevated: Background4
        },
        Tooltip: {
            colorBgSpotlight: Background4,
            colorTextLightSolid: TextPrimary,
        }
    },
    // в токены можно класть только цвета, css-var переменные НЕЛЬЗЯ
    token: {
        colorPrimary: greenLight,
        colorLink: greenLight,
        borderRadius: 20,
        fontFamily: 'SBSansText, SBSans, Arial, Helvetica, sans-serif',
        fontSize: 12,
        // Заголовки
        fontSizeHeading1: 30,
        fontSizeHeading2: 24,
        colorSplit: DividerThin,
    },
}

