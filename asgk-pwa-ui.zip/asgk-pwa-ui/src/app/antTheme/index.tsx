import { useSelector } from 'react-redux'

import { getIsDarkTheme } from '@entities/appTheme'

import { darkTheme } from './darkTheme'
import { lightTheme } from './lightTheme'

export const useGetAntdTheme = () => {
    const isDarkMode = useSelector(getIsDarkTheme)

    return isDarkMode ? darkTheme : lightTheme
}
