import { render, act } from '@testing-library/react'
import { vi, describe, it, expect, beforeEach } from 'vitest'
import { createBrowserHistory } from 'history'
import { CustomRouter } from '../customRouter'
import type { ReactNode } from 'react'

describe('Компонент CustomRouter', () => {
    let history: ReturnType<typeof createBrowserHistory>

    beforeEach(() => {
        history = createBrowserHistory()
    })

    it('должен корректно инициализироваться с начальным location и action', () => {
        const wrapper = ({ children }: { children: ReactNode }) => (
            <CustomRouter history={history}>{children}</CustomRouter>
        )

        const { container } = render(<div />, { wrapper })

        expect(container).toBeInTheDocument()
    })

    it('должен обновлять state при изменении location через history.listen', async () => {
        const newPath = '/test'
        const newAction = 'PUSH'

        const wrapper = ({ children }: { children: ReactNode }) => (
            <CustomRouter history={history}>{children}</CustomRouter>
        )

        render(<div />, { wrapper })

        // Имитируем изменение location
        await act(async () => {
            history.push(newPath)
            await vi.waitFor(() => {
                expect(history.location.pathname).toBe(newPath)
            })
        })

        // Проверяем, что состояние было обновлено
        expect(history.location.pathname).toBe(newPath)
        expect(history.action).toBe(newAction)
    })

    it('должен отписываться от history при размонтировании', () => {
        const unlistenSpy = vi.fn()

        // Мокаем метод listen у history
        const mockHistory = {
            ...createBrowserHistory(),
            listen: unlistenSpy,
        } as unknown as ReturnType<typeof createBrowserHistory>

        const wrapper = ({ children }: { children: ReactNode }) => (
            <CustomRouter history={mockHistory}>{children}</CustomRouter>
        )

        const { unmount } = render(<div />, { wrapper })

        unmount()

        expect(unlistenSpy).toHaveBeenCalled()
    })
})
