export const FOR_TEST_CONFIG_FOR_ALL = [
    '/',
    '/?tab=CSI',
    '/trends',
    '/segments',
    '/tribes',
    '/products',
    '/triggers',
    '/topics',
    '/summary',
    '/comments',
    '/profile',
    '/pains',
    '/pains/:painId',
    '/measures',
    '/measures/:measureId',
    'mailto:info_voiceofthecustomer@sberbank.ru?subject=%D0%9E%D0%B1%D1%80%D0%B0%D1%82%D0%BD%D0%B0%D1%8F%20%D1%' +
    '81%D0%B2%D1%8F%D0%B7%D1%8C%20%D0%B4%D0%BB%D1%8F%20%D0%90%D0%A1%20%D0%93%D0%BE%D0%BB%D0%BE%D1%81%20%D0%BA%' +
    'D0%BB%D0%B8%D0%B5%D0%BD%D1%82%D0%B0',
    '/segments/:clientSegment',
    '/tribes/:tribeId',
    '/products/:productId',
    '/triggers/:triggerId',
    '/trends/:trendId',
    '/error/network',
    '/error/401',
    '/error/404',
    '/error/500',
    '/error/refreshToken',
    '*'
]

export const FOR_TEST_CONFIG_FOR_ADMIN_INCIDENT = [
    ...FOR_TEST_CONFIG_FOR_ALL,
    '/administration',
    '/administration/trends',
    '/administration/triggers',
    '/administration/examples',
    '/administration/classifier',
]

export const FOR_TEST_CONFIG_MENU_WITHOUT_ADMIN = [
    '/',
    '/trends',
    'structure',
    '/pains',
    '/measures',
    '/profile',
    'mailto:info_voiceofthecustomer@sberbank.ru?subject=%D0%9E%D0%B1%D1%80%D0%B0%D1%82%D0%BD%D0%B0%' +
            'D1%8F%20%D1%81%D0%B2%D1%8F%D0%B7%D1%8C%20%D0%B4%D0%BB%D1%8F%20%D0%90%D0%A1%20%D0%93%D0%BE%D0%' +
            'BB%D0%BE%D1%81%20%D0%BA%D0%BB%D0%B8%D0%B5%D0%BD%D1%82%D0%B0'
    ,
]
