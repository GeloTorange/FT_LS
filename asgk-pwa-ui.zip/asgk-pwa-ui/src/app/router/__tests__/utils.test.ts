import { describe, it, expect, vi } from 'vitest'
import { PAGE_ROUTES, Roles } from '@shared/system/router'
import { getMenuItems, getRoutes } from '../'
import {
    FOR_TEST_CONFIG_FOR_ADMIN_INCIDENT,
    FOR_TEST_CONFIG_FOR_ALL,
    FOR_TEST_CONFIG_MENU_WITHOUT_ADMIN,
} from './const'
import type { PropsWithChildren, ReactElement } from 'react'
import { isDesktopFalse } from '../../../__testsUtils__/isDesktopFalse'

// Мокируем react-device-detect
vi.mock('react-device-detect')

const getStringChildren = (elem: ReactElement<PropsWithChildren> | null) =>
    elem && 'children' in elem.props ? String(elem.props.children) : ''

describe('Navigation Utilities', () => {
    describe('getMenuItems', () => {
        it('должен возвращать основные пункты меню для роли ALL', () => {
            const result = getMenuItems([Roles.ALL])

            // Основные пункты меню, которые должны быть видны
            const expectedMainItems = [
                'Главная',
                'Реестр трендов',
                'Источники',
                'Профиль',
                'Обратная связь'
            ]

            expect(result.map(item => getStringChildren(item.label))).toEqual(
                expect.arrayContaining(expectedMainItems)
            )
        })

        it('должен возвращать вложенные пункты меню для источников', () => {
            const result = getMenuItems([Roles.ALL])
            const sourcesItem = result.find(item => getStringChildren(item?.label) === 'Источники')

            expect(sourcesItem?.children).toHaveLength(4)
            expect(sourcesItem?.children?.map(child => getStringChildren(child.label))).toEqual([
                'Реестр опросов',
                'Тематики обращений',
                'Саммари обращений',
                'Прямая речь'
            ])
        })

        it('должен возвращать mailto ссылку для обратной связи', () => {
            const result = getMenuItems([Roles.ALL])
            const feedbackItem = result.find(item => getStringChildren(item.label) === 'Обратная связь')

            // @ts-expect-error - проверяем как раз что есть href
            expect(feedbackItem?.label?.props.href).toMatch(/^mailto:/)
        })

        it('должен показывать администрирование только для incidents_admin', () => {
            // Для обычного пользователя
            const userResult = getMenuItems([Roles.ALL])
            expect(userResult.some(item => getStringChildren(item.label) === 'Администрирование')).toBe(false)

            // Для админа
            const adminResult = getMenuItems([Roles.incidents_admin])
            expect(adminResult.some(item => getStringChildren(item.label) === 'Администрирование')).toBe(true)
        })

        it('должен применять специальные стили для нижних пунктов меню', () => {
            const result = getMenuItems([Roles.incidents_admin])
            const profileItem = result.find(item => getStringChildren(item.label) === 'Профиль')
            const feedbackItem = result.find(item => getStringChildren(item.label) === 'Обратная связь')

            expect(profileItem?.style).toHaveProperty('position', 'absolute')
            expect(feedbackItem?.style).toHaveProperty('position', 'absolute')
        })
    })

    describe('Меню для мобильных устройств', () => {
        it('не должен показывать администрирование в меню на мобильных', () => {
            isDesktopFalse()
            const result = getMenuItems([Roles.incidents_admin])

            expect(result.some(item => getStringChildren(item.label) === 'Администрирование')).toBe(false)
            result.forEach(
                (el) => {
                    if (el.key) {
                        expect(FOR_TEST_CONFIG_MENU_WITHOUT_ADMIN.includes(el.key)).toBe(true)
                    }
                }
            )
        })
    })

    describe('getRoutes', () => {
        it('проверяем какой конфиг вернется для роли ALL', () => {
            const result = getRoutes([Roles.ALL])

            result.forEach(
                (el) => {
                    if (el.key) {
                        expect(FOR_TEST_CONFIG_FOR_ALL.includes(el.key)).toBeTruthy()
                    }
                }
            )
        })

        it('должен создавать роуты для страниц администрирования только для incidents_admin', () => {
            // Для обычного пользователя
            const userResult = getRoutes([Roles.ALL])
            // comment: props?.path точно есть и строка
            // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
            expect(userResult.some(r => r.props?.path === PAGE_ROUTES.ADMINISTRATION)).toBe(false)

            // Для админа
            const adminResult = getRoutes([Roles.incidents_admin])

            adminResult.forEach(
                (el) => {
                    if (el.key) {
                        expect(FOR_TEST_CONFIG_FOR_ADMIN_INCIDENT.includes(el.key)).toBe(true)
                    }
                }
            )
        })
    })
})
