import { describe, expect, it, vi } from 'vitest'
import { Roles } from '@shared/system/router'
import { getMenuItems } from '../utils'


vi.mock('../pages', () => ({
    configPages: () => [
        {
            label: 'Test',
            path: null,
            icon: null,
            component: null,
            roles: [Roles.ALL],
            isShowMenu: true,
            isRoute: true,
        }
    ]
}))

describe('getMenuItems негативный сценарий', () => {

    it('должен вывести ошибку в консоль и вернуть null если нет path и children', () => {
        const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
        const result = getMenuItems([Roles.ALL])

        expect(result).toEqual([
            {
                key: null,
                style: undefined,
                icon: null,
                label: null,
                children: undefined
            }
        ])
        expect(warnSpy).toHaveBeenCalledWith('В меню указан элемент без ссылки и без children')
    })
})
