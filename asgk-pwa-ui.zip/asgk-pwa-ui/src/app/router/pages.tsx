import {
    AppstoreOutlined,
    ContainerOutlined,
    LineChartOutlined,
    MailOutlined,
    SettingOutlined,
    FileDoneOutlined,
} from '@ant-design/icons'
import React from 'react'
import { isDesktop } from 'react-device-detect'

import {
    AdministrationClassifier,
    ExamplesManagement,
    AdministrationPage,
    AdministrationTrends,
    AdministrationTriggers
} from '@pages/administration'
import { ErrorLayout, errorTemplates } from '@pages/Errors'
import { MeasurePage } from '@pages/infoPages/Measure'
import { PainPage } from '@pages/infoPages/Pain'
import { TrendPage } from '@pages/infoPages/Trend'
import { TriggerPage } from '@pages/infoPages/Trigger'
import { CommentsPage } from '@pages/listingPages/Comments'
import { Measures } from '@pages/listingPages/Measures'
import { Pains } from '@pages/listingPages/Pains'
import { Summary } from '@pages/listingPages/Summaries'
import { Topics } from '@pages/listingPages/Topics'
import { Trends } from '@pages/listingPages/Trends'
import { Triggers } from '@pages/listingPages/Triggers'
import { MainPage } from '@pages/Main'
import { Profile } from '@pages/Profile'
import { AiPain, UserOutlined } from '@shared/assets/icons'
import { PAGE_ROUTES, Roles } from '@shared/system/router'

import styles from './styles.module.scss'
import type { Page } from './types'

const email = 'info_voiceofthecustomer@sberbank.ru'
const subject = 'Обратная связь для АС Голос клиента'

export const configPages = (): Page[] => [
    {
        label: 'Главная',
        icon: <AppstoreOutlined/>,
        roles: [Roles.ALL],
        isShowMenu: true,
        style: {},
        children: [
            {
                label: 'Главная',
                path: PAGE_ROUTES.MAIN,
                component: <MainPage/>,
                roles: [Roles.ALL],
                isShowMenu: true,
                isRoute: true,
            },
            {
                label: 'CSI',
                key: 'CSI',
                path: PAGE_ROUTES.CSI,
                component: <MainPage/>,
                roles: [Roles.ALL],
                isShowMenu: true,
                isRoute: true,
            },
        ],
    },
    {
        label: <><span style={{ color: 'var(--IconAccent)' }}>Ai</span>болит</>,
        path: PAGE_ROUTES.PAINS,
        icon: <AiPain/>,
        component: <Pains/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: true,
    },
    {
        label: 'Меры',
        path: PAGE_ROUTES.MEASURES,
        icon: <FileDoneOutlined/>,
        component: <Measures/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: true,
    },

    {
        label: 'Реестр трендов',
        path: PAGE_ROUTES.TRENDS,
        icon: <LineChartOutlined/>,
        component: <Trends/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: true,
    },

    {
        label: 'Источники',
        icon: <ContainerOutlined/>,
        roles: [Roles.ALL],
        isShowMenu: true,
        children: [
            {
                label: 'Реестр опросов',
                path: PAGE_ROUTES.TRIGGERS,
                component: <Triggers/>,
                roles: [Roles.ALL],
                isRoute: true,
                isShowMenu: true,
            },
            {
                label: 'Тематики обращений',
                path: PAGE_ROUTES.TOPICS,
                component: <Topics />,
                roles: [Roles.ALL],
                isRoute: true,
                isShowMenu: true,
            },
            {
                label: 'Саммари обращений',
                path: PAGE_ROUTES.TOPICS_SUMMARY,
                component: <Summary />,
                roles: [Roles.ALL],
                isRoute: true,
                isShowMenu: true,
            },
            {
                label: 'Прямая речь',
                path: PAGE_ROUTES.COMMENTS,
                component: <CommentsPage/>,
                roles: [Roles.ALL],
                isRoute: true,
                isShowMenu: true,
            },
        ],
    },

    // Закрепленные снизу дополнительные элементы меню
    {
        label: 'Администрирование',
        path: PAGE_ROUTES.ADMINISTRATION,
        icon: <SettingOutlined/>,
        component: <AdministrationPage/>,
        roles: [Roles.incidents_admin],
        isRoute: isDesktop,
        isShowMenu: isDesktop,
        style: {
            position: 'absolute',
            bottom: '160px',
            display: 'flex',
            alignItems: 'center',
            paddingLeft: '24px',
            zIndex: 2,
        },
    },
    {
        path: PAGE_ROUTES.ADMINISTRATION_TRENDS_PARAMS,
        component: <AdministrationTrends />,
        roles: [Roles.incidents_admin],
        isShowMenu: false,
        isRoute: isDesktop,
        key: 'Параметры трендов',
    },
    {
        path: PAGE_ROUTES.ADMINISTRATION_TRIGGERS_PARAMS,
        component: <AdministrationTriggers />,
        roles: [Roles.incidents_admin],
        isShowMenu: false,
        isRoute: isDesktop,
        key: 'Параметры опросов',
    },
    {
        path: PAGE_ROUTES.ADMINISTRATION_EXAMPLES_MANAGEMENT,
        component: <ExamplesManagement />,
        roles: [Roles.incidents_admin],
        isShowMenu: false,
        isRoute: isDesktop,
        key: 'Управление примерами',
    },
    {
        path: PAGE_ROUTES.ADMINISTRATION_CLASSIFIER,
        component: <AdministrationClassifier />,
        roles: [Roles.incidents_admin],
        isShowMenu: false,
        isRoute: isDesktop,
        key: 'Классификатор',
    },
    {
        label: 'Профиль',
        path: PAGE_ROUTES.PROFILE,
        icon: <UserOutlined/>,
        component: <Profile/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: true,
        style: {
            position: 'absolute',
            bottom: '80px',
            display: 'flex',
            alignItems: 'center',
            paddingLeft: '24px',
            zIndex: 2,
            transition: 'none',
        },
    },
    {
        label: 'Обратная связь',
        path: `mailto:${email}?subject=${encodeURIComponent(subject)}`,
        icon: <MailOutlined className={styles.mailIcon}/>,
        roles: [Roles.ALL],
        isLink: true,
        isRoute: true,
        isShowMenu: true,
        style: {
            position: 'absolute',
            bottom: 0,
            display: 'flex',
            alignItems: 'center',
            paddingLeft: '24px',
            zIndex: 2,
            color: 'var(--TextSecondary)',
            borderTop: '1px solid var(--DividerThin)',
        },
    },

    // Страницы опроса, тренда
    {
        path: PAGE_ROUTES.TRIGGER,
        component: <TriggerPage/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: false,
    },
    {
        path: PAGE_ROUTES.TREND,
        component: <TrendPage/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: false,
    },
    {
        path: PAGE_ROUTES.PAIN,
        component: <PainPage/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: false,
    },
    {
        path: PAGE_ROUTES.MEASURE,
        component: <MeasurePage/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: false,
    },

    // Технические страницы
    {
        path: PAGE_ROUTES.ERROR_NETWORK,
        component: <ErrorLayout {...errorTemplates.network}/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: false,
    },
    {
        path: PAGE_ROUTES.ERROR_401,
        component: <ErrorLayout {...errorTemplates[401]}/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: false,
    },
    {
        path: PAGE_ROUTES.ERROR_404,
        component: <ErrorLayout {...errorTemplates[404]}/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: false,
    },
    {
        path: PAGE_ROUTES.ERROR_500,
        component: <ErrorLayout {...errorTemplates[500]}/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: false,
    },
    {
        path: PAGE_ROUTES.ERROR_REFRESH_TOKEN,
        component: <ErrorLayout {...errorTemplates.refreshToken}/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: false,
    },
    {
        path: PAGE_ROUTES.INDEFINITE_PATH,
        component: <ErrorLayout {...errorTemplates['404']}/>,
        roles: [Roles.ALL],
        isRoute: true,
        isShowMenu: false,
    },
]
