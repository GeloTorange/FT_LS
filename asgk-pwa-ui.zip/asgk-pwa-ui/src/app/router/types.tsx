import type { ReactNode, CSSProperties } from 'react'

import type { Roles } from '@shared/system/router'


export interface Page {
    label?: ReactNode,
    path?: string,
    icon?: ReactNode,
    component?: ReactNode,
    isShowMenu: boolean,
    isRoute?: boolean,
    roles: Roles[],
    style?: CSSProperties,
    children?: PageChildren[]
    isLink?: boolean,
    key?: string,
}

interface PageChildren {
    label: string,
    path: string,
    component: ReactNode,
    isShowMenu: boolean,
    isRoute: boolean,
    roles: Roles[],
    style?: CSSProperties,
    children?: Page[]
    key?: string,
}
