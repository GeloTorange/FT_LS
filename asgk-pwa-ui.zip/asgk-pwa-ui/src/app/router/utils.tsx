import clsx from 'clsx'
import type { PropsWithChildren, ReactElement } from 'react'
import { Route, Link } from 'react-router-dom'

import { Roles } from '@shared/system/router'
import type { LocationState } from '@shared/types/location'

import { bodyTypographyStyle, TypographyBody } from '../../shared/components/typography'
import { helperStyles } from '../../shared/styles'

import { configPages } from './pages'
import type { Page } from './types'

// Проверяет, имеет ли пользователь доступ к странице на основе его ролей
const hasAccess = (pageRoles: Roles[], userRoles: Roles[] = []) =>
    pageRoles.some(role => userRoles.includes(role) || role === Roles.ALL)

// Фильтрует страницы, доступные для меню
const filterMenuPages = (pages: Page[], userRoles: Roles[]) =>
    pages.filter(({ isShowMenu, isRoute, roles, children }) => (
        isShowMenu &&
        (isRoute || children) &&
        hasAccess(roles, userRoles)
    ))

// Фильтрует дочерние страницы, доступные для меню
const filterChildMenuPages = (children: Page['children'], userRoles: Roles[]) =>
    children?.filter(({ isShowMenu, isRoute, roles }) => (
        isShowMenu &&
        isRoute &&
        hasAccess(roles, userRoles)
    ))

// Получаем label для элемента меню
const getLabelForMenu = ({
    children,
    label,
    isLink,
    path,
}: Pick<Page, 'children' | 'label' | 'isLink' | 'path'>): ReactElement<PropsWithChildren> | null => {
    if (children) {
        return (
            <TypographyBody fontWeight={'500'}>{label}</TypographyBody>
        )
    }
    if (isLink) {
        return (
            <a href={path} className={clsx(bodyTypographyStyle, helperStyles.fontWeight500)}>
                {label}
            </a>
        )
    }
    if (!path) {
        // comment: нужно явно подсветить
        // eslint-disable-next-line no-console
        console.warn('В меню указан элемент без ссылки и без children')
        return null
    }

    return (
        <Link to={path} className={clsx(bodyTypographyStyle, helperStyles.fontWeight500)}>
            {label}
        </Link>
    )
}

const mainMenuState: LocationState = {
    fromMainMenu: true, 
}

// Преобразует страницу в элемент меню
const pageToMenuItem = ({ path, style, icon, children, label, isLink, key }: Page) => ({
    key: key || path,
    style,
    icon,
    label: getLabelForMenu({ path, children, label, isLink }),
    children: children?.map(({ key: keyChild, path: childrenPath, label: labelChild }) => ({
        key: keyChild || childrenPath,
        label:
            <Link to={childrenPath} className={bodyTypographyStyle} state={mainMenuState}>
                {labelChild}
            </Link> as ReactElement<PropsWithChildren>,
    })),
})

// Генерирует элементы меню на основе ролей пользователя
export const getMenuItems = (userRoles: Roles[] = []) =>
    filterMenuPages(configPages(), userRoles)
        .map(page => (
            pageToMenuItem({
                ...page,
                children: filterChildMenuPages(page.children, userRoles),
            })
        ))

// Создает маршруты для страниц, доступных пользователю
const createRoutes = (pagesList: Page[], userRoles: Roles[] = []) =>
    pagesList
        // отсеиваем по ролям и по isRoute
        .filter(page => hasAccess(page.roles, userRoles) && (page.isRoute || page.children) )
        // формируем плоский список роутов
        .flatMap(page => {
            if (page.children) {
                return page.children
                    .filter(({ isRoute, roles }) => isRoute && hasAccess(roles, userRoles))
                    .map(({ path: childrenPath, component: componentChild }) =>
                        <Route key={childrenPath} path={childrenPath} element={componentChild} />
                    )
            }
            return page.path && page.component
                ? [<Route key={page.path} path={page.path} element={page.component} />]
                : []
        })

export const getRoutes = (userRoles?: Roles[]) => createRoutes(configPages(), userRoles)
