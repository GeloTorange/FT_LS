import { renderHook, act } from '@testing-library/react'
import { vi, describe, it, expect, beforeEach, afterEach } from 'vitest'
import dayjs from 'dayjs'
import { useDispatch } from 'react-redux'
import { setIsSessionModalVisible } from '@entities/isShowSessionModal'
import { useState } from 'react'
import { useSessionModal } from '../useSessionModal'

// Мокируем только необходимые зависимости
vi.mock('react-redux', () => ({
    useDispatch: vi.fn(),
}))

// Мокируем useState
const mockSetExpTokenTime = vi.fn()
vi.mock('react', async () => ({
    ...(await vi.importActual('react')),
    useState: vi.fn(() => [null, mockSetExpTokenTime]),
}))

describe('Хук useSessionModal', () => {
    const mockDispatch = vi.fn()
    let setTimeoutSpy: ReturnType<typeof vi.spyOn>
    let clearTimeoutSpy: ReturnType<typeof vi.spyOn>

    beforeEach(() => {
        vi.clearAllMocks()
        vi.mocked(useDispatch).mockReturnValue(mockDispatch)

        // Правильное мокирование таймеров
        vi.useFakeTimers()
        // @ts-expect-error - не важно
        setTimeoutSpy = vi.spyOn(global, 'setTimeout')
        clearTimeoutSpy = vi.spyOn(global, 'clearTimeout')
    })

    afterEach(() => {
        vi.useRealTimers()
    })

    it('должен устанавливать таймер при получении времени истечения', () => {
        const testTime = dayjs().add(1, 'hour').toISOString()
        vi.mocked(useState).mockImplementationOnce(() => [testTime, mockSetExpTokenTime])

        const { unmount } = renderHook(() => useSessionModal())

        expect(setTimeoutSpy).toHaveBeenCalledTimes(1)
        // comment: берем id таймера
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment,@typescript-eslint/no-unsafe-member-access
        const timerId = vi.mocked(setTimeoutSpy).mock?.results?.[0]?.value

        unmount()

        expect(clearTimeoutSpy).toHaveBeenCalledTimes(1)
        expect(clearTimeoutSpy).toHaveBeenCalledWith(timerId)
    })

    it('должен диспатчить действие при срабатывании таймера', () => {
        const testTime = dayjs().add(100, 'milliseconds').toISOString()
        vi.mocked(useState).mockImplementationOnce(() => [testTime, mockSetExpTokenTime])

        const { unmount } = renderHook(() => useSessionModal())

        act(() => {
            vi.advanceTimersByTime(100)
        })

        expect(mockDispatch).toHaveBeenCalledWith(setIsSessionModalVisible(true))
        unmount()
    })
})
