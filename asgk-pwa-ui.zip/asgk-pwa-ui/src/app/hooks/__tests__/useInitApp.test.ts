import { renderHook, act } from '@testing-library/react'
import { vi, describe, it, expect, beforeEach } from 'vitest'
import { useDispatch, useSelector } from 'react-redux'
import { getAppState, changeStatus } from '@entities/appState'
import { setInfo } from '@entities/userInfo'
import { getSudirLogin } from '@shared/api/sudir'
import { getStand } from '@shared/api/system'
import { initAnalytics } from '@shared/system/analytics'
import { APP_STATUSES } from '@shared/system/appStatuses'
import { injectStore } from '@shared/system/requestWrapper'
import { stateApp, useInitApp } from '../useInitApp'
import { useSessionModal } from '../useSessionModal'
import type { SudirUser, UserData } from '@shared/types/user'
import type { AxiosResponse } from 'axios'
import type { Response } from '@shared/types/response'

// Мокируем все зависимости
vi.mock('react-redux', () => ({
    useDispatch: vi.fn(),
    useSelector: vi.fn(),
}))

vi.mock('@entities/appState', () => ({
    getAppState: vi.fn(),
    changeStatus: vi.fn((str: string) => str),
}))

vi.mock('@entities/userInfo', () => ({
    setInfo: vi.fn(),
}))

vi.mock('@shared/api/sudir', () => ({
    getSudirLogin: vi.fn(),
}))

vi.mock('@shared/api/system', () => ({
    getStand: vi.fn(),
}))

vi.mock('@shared/system/analytics', () => ({
    initAnalytics: vi.fn(),
}))

vi.mock('@shared/system/requestWrapper', () => ({
    injectStore: vi.fn(),
}))

vi.mock('../../store', () => ({
    store: {},
}))

vi.mock('../useSessionModal', () => ({
    useSessionModal: vi.fn(),
}))

describe('Хук useInitApp', () => {
    const mockDispatch = vi.fn()
    const mockSetExpTokenTime = vi.fn()

    beforeEach(() => {
        // Сбрасываем состояние перед каждым тестом
        vi.mocked(useDispatch).mockReturnValue(mockDispatch)
        vi.mocked(useSessionModal).mockReturnValue({
            setExpTokenTime: mockSetExpTokenTime,
        })
        vi.mocked(injectStore).mockClear()
    })

    afterEach(() => {
        vi.clearAllMocks()
        stateApp.firstLoad = false
    })

    it('должен вызывать getAndSetUserInfo при статусе LOADING', async () => {
        // Мокаем начальное состояние
        vi.mocked(useSelector).mockImplementation((selector) => {
            if (selector === getAppState) return APP_STATUSES.LOADING
            return null
        })

        // Мокаем успешный ответ от API
        const mockUser = { emploeeid: '123', name: 'Test User' } as SudirUser
        const mockExp = '2023-12-31T23:59:59'
        vi.mocked(getSudirLogin).mockResolvedValue({
            data: {
                user: mockUser,
                exp: mockExp,
            },
        } as AxiosResponse<UserData>)

        const mockStandResponse = { data: 'test-stand' }
        vi.mocked(getStand).mockResolvedValue(mockStandResponse as Response<string>)

        renderHook(() => { useInitApp() })

        // Ждем выполнения асинхронных операций
        await act(async () => {
            await Promise.resolve()
        })

        expect(getSudirLogin).toHaveBeenCalled()
        expect(mockDispatch).toHaveBeenCalledWith(setInfo(mockUser))
        expect(mockDispatch).toHaveBeenCalledWith(changeStatus(APP_STATUSES.WORK))
        expect(mockSetExpTokenTime).toHaveBeenCalledWith(mockExp)
        expect(getStand).toHaveBeenCalled()
        expect(initAnalytics).toHaveBeenCalledWith({
            currentStand: mockStandResponse.data,
            userId: mockUser.emploeeid,
        })
    })

    it('должен устанавливать статус ошибки при неудачном запросе getSudirLogin', async () => {
        vi.mocked(useSelector).mockImplementation((selector) => {
            if (selector === getAppState) return APP_STATUSES.LOADING
            return null
        })

        vi.mocked(getSudirLogin).mockRejectedValue(new Error('API Error'))

        renderHook(() => { useInitApp() })

        await act(async () => {
            await Promise.resolve()
        })

        expect(mockDispatch).toHaveBeenCalledWith(changeStatus(APP_STATUSES.GET_USER_INFO_ERROR))
    })

    it('не должен вызывать getAndSetUserInfo при первом рендере, если статус не LOADING', () => {
        vi.mocked(useSelector).mockImplementation((selector) => {
            if (selector === getAppState) return APP_STATUSES.WORK
            return null
        })

        renderHook(() => { useInitApp() })

        expect(getSudirLogin).not.toHaveBeenCalled()
    })

    it('не должен вызывать getAndSetUserInfo повторно при StrictMode', () => {
        vi.mocked(useSelector).mockImplementation((selector) => {
            if (selector === getAppState) return APP_STATUSES.LOADING
            return null
        })

        // Имитируем первый вызов
        renderHook(() => { useInitApp() })
        // Имитируем второй вызов (как в StrictMode)
        renderHook(() => { useInitApp() })
        expect(getSudirLogin).toHaveBeenCalledTimes(1)
    })

    it('должен корректно обрабатывать отсутствие exp в ответе', async () => {
        vi.mocked(useSelector).mockImplementation((selector) => {
            if (selector === getAppState) return APP_STATUSES.LOADING
            return null
        })

        const mockUser = { emploeeid: '123', name: 'Test User' }
        vi.mocked(getSudirLogin).mockResolvedValue({
            data: { user: mockUser, exp: undefined },
        } as AxiosResponse<UserData>)

        renderHook(() => { useInitApp() })

        await act(async () => {
            await Promise.resolve()
        })

        expect(mockSetExpTokenTime).toHaveBeenCalledWith('')
    })
})
