
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import { getAppState, changeStatus } from '@entities/appState'
import { setInfo } from '@entities/userInfo'
import { getSudirLogin } from '@shared/api/sudir'
import { getStand } from '@shared/api/system'
import { initAnalytics } from '@shared/system/analytics'
import { APP_STATUSES } from '@shared/system/appStatuses'
import { injectStore } from '@shared/system/requestWrapper'

import { store } from '../store'

import { useSessionModal } from './useSessionModal'

// Чтобы наверняка не было двойного вызова из-за StrictMode и не только.
// Сделал объектом и через export для тестов
export const stateApp = { firstLoad: false }

// Хук в котором происходят различные инициирующие процессы для приложения
export const useInitApp = () => {
    const appState = useSelector(getAppState)
    const dispatch = useDispatch()
    const { setExpTokenTime } = useSessionModal()

    // Делаем инъекцию стора в requestWrapper, чтобы избежать циклических импортов
    injectStore(store)

    // Настройка сбора аналитики
    const setupAnalytics = (userId: string) => {
        if (userId) {
            getStand().then((standResponse) => {
                initAnalytics({ currentStand: standResponse.data, userId })
            })
        }
    }

    const getAndSetUserInfo = () => {
        stateApp.firstLoad = true
        getSudirLogin()
            .then((userResponse) => {
                const { user, exp } = userResponse.data
                // Установка данных о пользователе
                dispatch(setInfo(user))
                // Установка статуса приложения "Готов к работе"
                dispatch(changeStatus(APP_STATUSES.WORK))
                // Установка таймера на протухание сессии
                setExpTokenTime(exp || '')
                // Настройка сбора аналитики
                setupAnalytics(user.emploeeid)
            }).catch(() => {
                dispatch(changeStatus(APP_STATUSES.GET_USER_INFO_ERROR))
            })
    }

    useEffect(() => {
        if (appState === APP_STATUSES.LOADING && !stateApp.firstLoad) {
            getAndSetUserInfo()
        }
    }, [])
}
