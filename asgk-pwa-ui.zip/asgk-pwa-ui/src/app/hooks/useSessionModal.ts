import dayjs from 'dayjs'
import advancedFormat from 'dayjs/plugin/advancedFormat'
import timezone from 'dayjs/plugin/timezone'
import utc from 'dayjs/plugin/utc'
import weekOfYear from 'dayjs/plugin/weekOfYear'
import { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import type { Dispatch } from 'redux'

import { setIsSessionModalVisible } from '@entities/isShowSessionModal'

// Необходимо для определения времени протухания токена
dayjs.extend(utc)
dayjs.extend(timezone)
dayjs.extend(weekOfYear)
dayjs.extend(advancedFormat)

let timeoutID: ReturnType<typeof setTimeout>

// Реализовано, чтобы не пугать пользователя и не редиректить на СУДИР форму, когда он ПК оставил на длительное время
const showSessionModal = (
    dispatch: Dispatch,
    expTokenTime: string,
) => {
    timeoutID = setTimeout(
        () => dispatch(setIsSessionModalVisible(true)),
        dayjs.tz(expTokenTime, 'Etc/GMT+0').valueOf() - dayjs().valueOf(),
    )
}
// Хук для контроля сессии пользователя
export const useSessionModal = () => {
    const [expTokenTime, setExpTokenTime] = useState<string | null>(null)
    const dispatch = useDispatch()

    useEffect(() => {
        if (expTokenTime && process.env.NODE_ENV !== 'development') {
            showSessionModal(dispatch, expTokenTime)
        }
    }, [expTokenTime])

    useEffect(() => () => {
        clearTimeout(timeoutID)
    }, [])

    return { setExpTokenTime }
}
