import { store } from '../store'
import { COPY_STORE_FOR_TEST } from './const'

describe('store', () => {
    it('should be defined', () => {
        expect(store.getState()).toEqual(COPY_STORE_FOR_TEST)
    })
})
