import React from 'react'
import type { ReactNode } from 'react'

import { ErrorLayout, errorTemplates } from '@pages/Errors'

interface Props {
    children: ReactNode
}

interface State {
    hasError: boolean
}

export class ErrorBoundary extends React.Component <Props, State> {
    state = { hasError: false }

    static getDerivedStateFromError (): State {
        return { hasError: true }
    }

    render (): React.ReactNode {
        if (this.state.hasError) {
            return <ErrorLayout isOffToolbar {...errorTemplates.errorBoundary}/>
        }

        return this.props.children
    }
}
