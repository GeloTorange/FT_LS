import {
    Button, Row, Col,
} from 'antd'
import clsx from 'clsx'
import type { FC } from 'react'
import React from 'react'
import { isDesktop } from 'react-device-detect'
import { useSelector } from 'react-redux'


import { getIsShowSessionModal } from '@entities/isShowSessionModal'
import { SystemDialog } from '@shared/components/SystemDialog'
import { bodyTypographyStyle, TypographyBody, TypographyTitle2 } from '@shared/components/typography'
import { helperStyles } from '@shared/styles'
import { onReloadPage } from '@shared/utils/useful'


export const SessionModal: FC = () => {
    const isSessionModalVisible = useSelector(getIsShowSessionModal)

    return <SystemDialog
        drawerHeight={216}
        open={isSessionModalVisible}
        title={<TypographyTitle2>Истекло время сессии</TypographyTitle2>}
        closable={false}
        footer={<Row>
            <Col span={24}>
                <Button
                    className={clsx(helperStyles.fullWidth, bodyTypographyStyle)}
                    type={'primary'}
                    onClick={onReloadPage}
                >
                    {'Войти'}
                </Button>
            </Col>
        </Row>}
    >
        <TypographyBody
            strong={!isDesktop}
            type={isDesktop ? undefined : 'secondary'}
        >
            {'Необходимо повторно авторизоваться'}
        </TypographyBody>
    </SystemDialog>
}
