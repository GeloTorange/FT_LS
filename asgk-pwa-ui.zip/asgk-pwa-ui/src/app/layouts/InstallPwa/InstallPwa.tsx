import { Button, Row, Col } from 'antd'
import clsx from 'clsx'
import React, { memo, useCallback, useEffect, useState } from 'react'
import { isDesktop } from 'react-device-detect'

import { SystemDialog } from '@shared/components/SystemDialog'

import { bodyTypographyStyle, TypographyBody, TypographyTitle2 } from '../../../shared/components/typography'
import { helperStyles } from '../../../shared/styles'

import { useAddToHomescreenPrompt } from './hooks'


export const InstallPwa = memo(() => {
    const [promptable, promptToInstall, isInstalled] = useAddToHomescreenPrompt()
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [cancelToInstallPwa, setCancelToInstallPwa] = useState(localStorage.getItem('cancelToInstallPwa'))

    const showModal = () => {
        setIsModalOpen(true)
    }

    const handleOk = () => {
        if (promptable !== null) {
            promptToInstall()
        }
        setIsModalOpen(false)
    }

    const handleCancel = () => {
        setIsModalOpen(false)
        localStorage.setItem('cancelToInstallPwa', 'false')
        setCancelToInstallPwa('false')
    }

    const showHideWindow = useCallback(() => {
        if (!isModalOpen && promptable && !isInstalled && cancelToInstallPwa !== 'false') {
            showModal()
        }
    }, [cancelToInstallPwa, isInstalled, isModalOpen, promptable])

    useEffect(() => {
        setCancelToInstallPwa(localStorage.getItem('cancelToInstallPwa'))
    }, [])

    useEffect(() => {
        showHideWindow()
    }, [cancelToInstallPwa, isModalOpen, promptable, isInstalled, showHideWindow])

    return (
        <SystemDialog
            drawerHeight={200}
            open={isModalOpen}
            title={<TypographyTitle2>Установить приложение?</TypographyTitle2>}
            onClose={handleCancel}
            footer={
                <Row
                    gutter={[16, 16]}
                >
                    <Col span={12}>
                        <Button
                            className={clsx(helperStyles.fullWidth, bodyTypographyStyle)}
                            size={'large'}
                            type={'text'}
                            onClick={handleCancel}
                        >
                            {'Отмена'}
                        </Button>
                    </Col>
                    <Col span={12}>
                        <Button
                            className={clsx(helperStyles.fullWidth, bodyTypographyStyle)}
                            size={'large'}
                            type={'primary'}
                            onClick={handleOk}
                        >
                            {'Установить'}
                        </Button>
                    </Col>
                </Row>
            }
        >
            <TypographyBody
                strong={!isDesktop}
                type={isDesktop ? undefined : 'secondary'}
            >
                {'Приложение «Голос клиента» будет установлено на ваше устройство'}
            </TypographyBody>
        </SystemDialog>)
})
