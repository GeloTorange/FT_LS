import { configureStore } from '@reduxjs/toolkit'

import { appState } from '@entities/appState'
import { appTheme } from '@entities/appTheme'
import { isShowSessionModal } from '@entities/isShowSessionModal'
import { workspaceMeasure } from '@entities/measure'
import { productListByTrends } from '@entities/productListByTrends'
import { saveModal } from '@entities/saveModal'
import { userInfo } from '@entities/userInfo'
import { workspaceAdministration } from '@entities/workspaceAdministration'
import { workspacePain } from '@entities/workspacePain'
import { administrationApi } from '@shared/api/administration'
import { aiHubApi } from '@shared/api/aiHub'
import { commentsApi } from '@shared/api/comments'
import { insightHubApi } from '@shared/api/insightHub'
import { measuresApi } from '@shared/api/measures'
import { painsApi } from '@shared/api/pains'
import { productsApi } from '@shared/api/products'
import { reasonsApi } from '@shared/api/reasons'
import { segmentsApi } from '@shared/api/segments'
import { summariesApi } from '@shared/api/summaries'
import { topicsApi } from '@shared/api/topics'
import { trendsApi } from '@shared/api/trends'
import { tribesApi } from '@shared/api/tribes'
import { triggersApi } from '@shared/api/triggers'
import { universalApi } from '@shared/api/universal'
import { versionsSBOLApi } from '@shared/api/versionsSBOL'



export const store = configureStore({
    reducer: {
        [painsApi.reducerPath]: painsApi.reducer,
        [reasonsApi.reducerPath]: reasonsApi.reducer,
        [triggersApi.reducerPath]: triggersApi.reducer,
        [segmentsApi.reducerPath]: segmentsApi.reducer,
        [tribesApi.reducerPath]: tribesApi.reducer,
        [productsApi.reducerPath]: productsApi.reducer,
        [trendsApi.reducerPath]: trendsApi.reducer,
        [commentsApi.reducerPath]: commentsApi.reducer,
        [versionsSBOLApi.reducerPath]: versionsSBOLApi.reducer,
        [universalApi.reducerPath]: universalApi.reducer,
        [topicsApi.reducerPath]: topicsApi.reducer,
        [summariesApi.reducerPath]: summariesApi.reducer,
        [administrationApi.reducerPath]: administrationApi.reducer,
        [insightHubApi.reducerPath]: insightHubApi.reducer,
        [aiHubApi.reducerPath]: aiHubApi.reducer,
        [measuresApi.reducerPath]: measuresApi.reducer,
        appState: appState.reducer,
        userInfo: userInfo.reducer,
        appTheme: appTheme.reducer,
        isShowSessionModal: isShowSessionModal.reducer,
        productListByTrends: productListByTrends.reducer,
        workspaceAdministration: workspaceAdministration.reducer,
        saveModal: saveModal.reducer,
        workspacePain: workspacePain.reducer,
        workspaceMeasure: workspaceMeasure.reducer
    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware()
            .concat(measuresApi.middleware)
            .concat(reasonsApi.middleware)
            .concat(painsApi.middleware)
            .concat(triggersApi.middleware)
            .concat(segmentsApi.middleware)
            .concat(productsApi.middleware)
            .concat(trendsApi.middleware)
            .concat(tribesApi.middleware)
            .concat(commentsApi.middleware)
            .concat(versionsSBOLApi.middleware)
            .concat(universalApi.middleware)
            .concat(topicsApi.middleware)
            .concat(summariesApi.middleware)
            .concat(administrationApi.middleware)
            .concat(insightHubApi.middleware)
            .concat(aiHubApi.middleware),
})
