import type { Dayjs } from 'dayjs'

import type { TopicType } from '@shared/api/topics'
import type { OrderType } from '@shared/types/filters'
import type { ParsedStructureValue } from '@shared/utils/forTreeStructure'

import type { topicFilterRawFields, topicSorterFields , topicFilterFields } from './const'

export type TopicFilterRawFields = typeof topicFilterRawFields[number]
export type TopicFilterFields = typeof topicFilterFields[number]

export type Period = [start: Dayjs | undefined, end: Dayjs | undefined]
export type Structure = ParsedStructureValue

export interface TopicRawFilter {
    type?: string;
    startDate?: string;
    endDate?: string;
    searchWord?: string;
    unitId?: string | null;
    tribeId?: string | null;
    productId?: string | null;
}

export interface TopicFilter {
    type: TopicType,
    structure?: Structure,
    period?: Period,
    searchWord?: string;
}

export type TopicSorterFields = typeof topicSorterFields[number]
export type TopicSortOrderType = OrderType<TopicSorterFields>
