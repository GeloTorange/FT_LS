import dayjs from 'dayjs'
import type { NavigateOptions } from 'react-router-dom'

import { TopicType } from '@shared/api/topics'
import { OrderDirections } from '@shared/types/context'

import type { TopicSortOrderType , TopicFilter } from './types'

export const uiDateFormat = 'DD/MM/YYYY'

export const topicFilterRawFields = [
    'type',
    'startDate',
    'endDate',
    'searchWord',
    'tribeId',
    'productId',
    'unitId',
] as const

export const topicFilterFields = [
    'type',
    'structure',
    'period',
    'searchWord',
] as const

export const topicSorterFields = ['qty'] as const

export const topicSortOptions: TopicSortOrderType[] = [
    {
        orderType: 'qty',
        orderDirection: OrderDirections.ASC,
        name: 'по возрастанию количества',
    },
    {
        orderType: 'qty',
        orderDirection: OrderDirections.DESC,
        name: 'по убыванию количества',
    },
]

export const defaultTopicSortOption = topicSortOptions[1]

export const defaultNavigateOptions: NavigateOptions = { replace: true }

export const defaultFilter: TopicFilter = {
    type: TopicType.appeal,
    period: [dayjs().startOf('month'), dayjs().endOf('day')],
}
