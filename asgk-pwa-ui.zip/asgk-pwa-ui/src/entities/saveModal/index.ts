export {
    setNextLocation,
    changeSaveModalVisibility,
    saveModal
} from './models/slice'

export {
    getIsSaveModalVisible,
    getNextLocation,
} from './models/selector'
