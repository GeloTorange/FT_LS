
// comment: для простаты ориентации
// eslint-disable-next-line @typescript-eslint/naming-convention
export enum INFLUENCE_NAME {
    consultation = 'consultation',
    appeal = 'appeal',
    detractor = 'detractor',
    AKB = 'AKB',
}

export type InfluenceReasonOptionsItemType = {
    value: INFLUENCE_NAME,
    label: string
}

export type InfluenceReasonOptionsType = InfluenceReasonOptionsItemType[]

export type ReasonModalData = {
    painId: number
    reasonId?: number
    description?: string
    consultationTotal?: number | null
    consultationRatio?: number | null
    appealTotal?: number | null
    appealRatio?: number | null
    detractorTotal?: number | null
    detractorRatio?: number | null
    AKBTotal?: number | null
    AKBRatio?: number | null
}
