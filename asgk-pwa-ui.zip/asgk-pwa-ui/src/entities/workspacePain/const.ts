import type { InfluenceReasonOptionsItemType } from './types'
import { INFLUENCE_NAME } from './types'


export const INFLUENCE_REASON_OPTIONS: InfluenceReasonOptionsItemType[] = [
    {
        value: INFLUENCE_NAME.consultation,
        label: 'Консультации'
    },
    {
        value: INFLUENCE_NAME.appeal,
        label: 'Жалобы'
    },
    {
        value: INFLUENCE_NAME.detractor,
        label: 'Детракторы'
    },
    {
        value: INFLUENCE_NAME.AKB,
        label: 'АКБ'
    },
]
