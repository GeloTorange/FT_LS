import dayjs, { type Dayjs } from 'dayjs'

import { TrendTypes } from '@shared/api/trends'
import { TRIGGER_TYPES_OPTIONS } from '@shared/api/triggers'
import { useSearchParamsHook } from '@shared/hooks/useSearchParamsHook'
import { type FilterType, OrderDirections } from '@shared/types/context'
import { filterPeriod } from '@shared/utils/defaultDatesHelper'
import { toStrTreeStructureValue } from '@shared/utils/forTreeStructure'


// Получение начального значения типа опроса,
// реализовал так, чтобы менять дефолтное значение в одном месте
export const useGetInitialTriggerType = () => {
    const { getSearchParam } = useSearchParamsHook()
    return getSearchParam('triggerType') || TRIGGER_TYPES_OPTIONS[0].value
}

// Получение начальных значений фильтров для любой страницы.
// Брать не все, а только используемые
export const useGetInitialFilters = () => {
    const { getSearchParam } = useSearchParamsHook()

    return {
        clientSegment: getSearchParam('clientSegment'),
        structure: toStrTreeStructureValue( {
            unitId: getSearchParam('unitId'),
            tribeId: getSearchParam('tribeId'),
            productId: getSearchParam('productId'),
        }),
        triggerId: getSearchParam('triggerId'),
        triggerType: useGetInitialTriggerType(),
        trendId: getSearchParam('trendId'),
        trendType: (getSearchParam('trendType') as TrendTypes | null) || TrendTypes.NEGATIVE,
        versionSBOLId: getSearchParam('versionSBOLId'),
        marks: [],
        is300: false,
        lowScore: false,
        minLength: null,
        cmId: getSearchParam('cmId'),
        searchWord: getSearchParam('searchWord'),
        periodArray: [
            dayjs(getSearchParam('startDate') || filterPeriod.WEEK.startDateShort),
            dayjs(getSearchParam('endDate') || filterPeriod.WEEK.endDate),
        ],
        // сортировка и пагинация не хранится в URL params
        orderType: '',
        orderDirection: OrderDirections.DESC,
        pageIndex: 1,
    } as Omit<FilterType, 'orderDirection' | 'orderType' | 'periodArray' | 'pageIndex'> &
        {
            orderDirection: OrderDirections,
            orderType: string | null,
            periodArray: [Dayjs, Dayjs],
            pageIndex: number,
        }
}
