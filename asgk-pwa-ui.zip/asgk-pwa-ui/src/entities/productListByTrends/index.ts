export { isProductListDataByTrendsLoading, getProductListDataByTrends } from './models/selectors'

export { loadProductListDataByTrends } from './models/actions'

export { productListByTrends, resetState } from './models/slice'
