import { useMemo } from 'react'
import { useParams } from 'react-router-dom'

import { useGetReasonListQuery } from '@shared/api/reasons'
import { numShort } from '@shared/utils/formatting'

export const useAKBInfo = () => {
    const { painId } = useParams()
    const { data: reasoningData, isFetching } = useGetReasonListQuery({ painId: Number(painId) })

    // значение АКБ для тэга
    const akb = useMemo(() => {
        if (reasoningData) {
            return `АКБ продукта: ${numShort(reasoningData.AKB)} пользователей`
        }
        return ''
    }, [reasoningData])

    return {
        akb,
        isFetching,
    }
}
