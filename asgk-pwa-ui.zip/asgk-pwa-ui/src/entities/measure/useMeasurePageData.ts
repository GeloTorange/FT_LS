import { useCallback, useMemo } from 'react'
import { useParams } from 'react-router-dom'

import { type MeasureRequest, useGetMeasureQuery } from '@shared/api/measures'
import { removeEmpty } from '@shared/utils/useful'

export const useMeasurePageData = () => {
    const { measureId } = useParams() as { measureId: string }

    const { data, isFetching } = useGetMeasureQuery(removeEmpty<MeasureRequest>({
        measureId,
    }))

    const openLink = useCallback(() => {
        if (data && !isFetching) {
            window.open(data.audience.link, '_blank')

        }
    }, [data])

    const result = useMemo(() => {
        if (data && !isFetching) {
            return {
                productId: String(data.params.productId),
                hasJiraLink: Boolean(data.audience.link && data.audience.link !== ''),
                notCompleted: !data.params.completeDate,
                params: data.params,
                audience: data.audience,
                measureName: data.measureName,
                measureResult: data.audience.result,
                measureDescription: data.measureDescription
            }
        }
        return null
    }, [data])

    return {
        measureId,
        openLink,
        isFetching,
        ...result
    }
}
