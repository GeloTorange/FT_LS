import type { Dayjs } from 'dayjs'

import type { FilterType, PageFilter } from '@shared/types/context'

/** Дает четкое понимание какие поля действительно в фильтре установлены сразу */
export type MeasuresListFilterType = PageFilter<
    Pick<
        FilterType,
        'structure'
    >> & {
        pageIndex: number
    }

export type MeasurePutForm = {
    structure: string
    measureName: string
    measureDescription: string
    painIds?: number[]
    reasonIds?: number[]
    measureAudience: string
    measureRatio: number | null
    pshe: number | null
    deadlineDate: Dayjs | null
    effectMonths: number | null
    link: string
}

export type MeasurePutFormInStore = Omit<MeasurePutForm, 'deadlineDate'> & {
    // в сторе нельзя хранить dayjs
    deadlineDate: string | null
}
