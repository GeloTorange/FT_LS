import { useGetInfinityMeasuresListQuery } from '@shared/api/measures'
import { useUniversalFilter } from '@shared/utils/context'
import { toObjTreeStructureValue } from '@shared/utils/forTreeStructure'
import { removeEmpty } from '@shared/utils/useful'

import type { MeasuresListFilterType } from './types'


// Кол-во записей на одной странице
const PAGE_SIZE = 100
export const useGetMeasures = () => {
    const { filter } = useUniversalFilter<MeasuresListFilterType>()
    const { structure, pageIndex } = filter

    const { data, isFetching } = useGetInfinityMeasuresListQuery({
        filter: removeEmpty({
            ...toObjTreeStructureValue(structure),
        }),
        page: {
            // добавить скролл пагинацию
            pageIndex,
            pageSize: PAGE_SIZE,
        },
    })

    return {
        filter,
        data,
        isFetching
    }
}
