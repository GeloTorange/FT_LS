import dayjs from 'dayjs'

import { useGetCSSVar } from '@shared/styles'
import { today } from '@shared/utils/defaultDatesHelper'


type ReturnColorFromDeadline = 'green' | 'red' | 'yellow'

/**
 * Возвращает цвет в зависимости от срока выполнения (deadlineDate).
 *
 * @param deadlineDate - Дата дедлайна в формате строки.
 * @return 'green' - если дедлайн больше чем через 30 дней,
 *          'yellow' - если дедлайн в течение 30 дней или сегодня,
 *          'red' - если дедлайн уже прошел.
 */
export const getColorNameFromDeadline = (deadlineDate?: string): ReturnColorFromDeadline => {
    const diffDays = dayjs(deadlineDate).diff(today, 'day')

    if (diffDays > 30) {
        return 'green'
    } else if (diffDays <= 30 && diffDays >= 0) {
        return 'yellow'
    }
    return 'red'
}

export const useDateColors = (deadlineDate: string, completeDate: string) => {
    const colorConfig = {
        red: useGetCSSVar('--LineRed'),
        yellow: useGetCSSVar('--LineYellow'),
        green: useGetCSSVar('--LineGreen'),
        gray: useGetCSSVar('--TextSecondary'),
    }

    if (completeDate) {
        return colorConfig.gray
    }

    const colorName = getColorNameFromDeadline(deadlineDate)

    return colorConfig[colorName]
}
