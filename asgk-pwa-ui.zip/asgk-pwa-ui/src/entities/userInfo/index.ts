export { userInfo, setInfo } from './models/slice'

export { getUserInfo } from './models/selectors'
