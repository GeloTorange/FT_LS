import { OrderDirections, CSIOrderTypes } from '@shared/types/context'
import type { OrderType } from '@shared/types/filters'

export const csiSortOptions: OrderType<CSIOrderTypes>[] = [
    {
        orderType: CSIOrderTypes.CSI_INCR,
        orderDirection: OrderDirections.DESC,
        name: 'по убыванию прироста %',
    },
    {
        orderType: CSIOrderTypes.CSI_INCR,
        orderDirection: OrderDirections.ASC,
        name: 'по возрастанию прироста %',
    },
    {
        orderType: CSIOrderTypes.CSI,
        orderDirection: OrderDirections.DESC,
        name: 'по убыванию CSI',
    },
    {
        orderType: CSIOrderTypes.CSI,
        orderDirection: OrderDirections.ASC,
        name: 'по возрастанию CSI',
    },
]
