import dayjs from 'dayjs'

import { today } from '@shared/utils/defaultDatesHelper'

export const isNewTrend = (createDate?: string): boolean => {
    if (!createDate) return false

    const createDay = dayjs(createDate)

    return today.diff(createDay, 'days') <= 7
}
