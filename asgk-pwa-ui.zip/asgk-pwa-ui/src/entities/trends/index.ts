export { trendTypeOptions, getTrendTypeData, trendSortOptions } from './const'
export { isNewTrend } from './utils'
