import type { DefaultOptionType } from 'rc-select/lib/Select'

import { TrendTypes } from '@shared/api/trends'
import { PopoverTrendType } from '@shared/components/Popovers'
import { OrderDirections, TrendsOrderTypes } from '@shared/types/context'
import type { OrderType } from '@shared/types/filters'

export const trendTypeOptions: DefaultOptionType[] = [
    {
        label: (<PopoverTrendType>
            Позитивные
        </PopoverTrendType>),
        value: TrendTypes.POSITIVE,
        disabled: true,
    },
    {
        label: (<>Негативные</>),
        value: TrendTypes.NEGATIVE,
        disabled: false,
    },
]

export const getTrendTypeData = () => ({ data: trendTypeOptions, isFetching: false })

export const trendSortOptions: OrderType<TrendsOrderTypes>[] = [
    {
        orderType: TrendsOrderTypes.TREND_RATIO_PCT,
        orderDirection: OrderDirections.DESC,
        name: 'по убыванию доли',
    },
    {
        orderType: TrendsOrderTypes.TREND_RATIO_PCT,
        orderDirection: OrderDirections.ASC,
        name: 'по возрастанию доли',
    },
    {
        orderType: TrendsOrderTypes.TREND_RATIO_PCT_INCR,
        orderDirection: OrderDirections.DESC,
        name: 'по убыванию прироста',
    },
    {
        orderType: TrendsOrderTypes.TREND_RATIO_PCT_INCR,
        orderDirection: OrderDirections.ASC,
        name: 'по возрастанию прироста',
    },
]
