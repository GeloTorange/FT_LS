import type { Dayjs } from 'dayjs'


import type { summarySortOptions, summaryFilterFields } from './const'

export type SummarySorterFields = typeof summarySortOptions[number]

export type SummaryFilterFields = typeof summaryFilterFields[number]

export interface SummaryFilter {
    factorica?: string;
    tribeId?: number;
    startDate?: Dayjs;
    endDate?: Dayjs;
    summaryId?: string;
}
