import { OrderDirections } from '@shared/types/context'
import type { OrderType } from '@shared/types/filters'

export const summarySortOptions: OrderType<string>[] = [
    {
        orderType: 'appCreated',
        orderDirection: OrderDirections.DESC,
        name: 'Сначала новые',
    },
    {
        orderType: 'appCreated',
        orderDirection: OrderDirections.ASC,
        name: 'Сначала старые',
    }
]

export const summaryFilterFields = [
    'factorica', 'tribeId', 'startDate', 'endDate', 'summaryId'
] as const

export const topicParam = 'type'
