import { TopicType } from '@shared/api/topics'
import { useQueryStringParam } from '@shared/hooks/queryString'

import { topicParam } from './const'

export const useSummaryType = () => useQueryStringParam<TopicType>(topicParam, TopicType.appeal, { replace: true })
