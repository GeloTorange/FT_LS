import dayjs from 'dayjs'

import { TopicType } from '@shared/api/topics'
import { useQueryStringFilterAsIs, useQueryStringParam } from '@shared/hooks/queryString'

import { summaryFilterFields, topicParam } from './const'
import type { SummaryFilter, SummaryFilterFields } from './types'


export const useSummaryType = () => useQueryStringParam<TopicType>(topicParam, TopicType.appeal, { replace: true })

export const useSummaryQueryStringFilter = () =>
    useQueryStringFilterAsIs<SummaryFilterFields, SummaryFilter>(
        summaryFilterFields,
        {
            startDate: dayjs().subtract(6, 'day').startOf('day'),
            endDate: dayjs().endOf('day'),
        },
        (values) => {
            const { startDate, endDate, ...other } = values || {}
            return {
                ...(other as Record<string, string>),
                // TODO: В перспективе надо будет расширить справочник дат и вынести это всё туда
                startDate: startDate ? dayjs(startDate as string) : undefined,
                endDate: endDate ? dayjs(endDate as string) : undefined,
            }
        },
        (filter) => {
            const { startDate, endDate, ...other } = filter || {}
            return {
                ...other,
                startDate: startDate?.format('YYYY-MM-DD'),
                endDate: endDate?.format('YYYY-MM-DD'),
            }
        },
        { replace: true }
    )
