import { CommentOrderTypes, OrderDirections } from '@shared/types/context'
import type { OrderType } from '@shared/types/filters'


export const commentSortOptions: OrderType<CommentOrderTypes>[] = [
    {
        name: 'Сначала старые',
        orderType: CommentOrderTypes.ANSWER_DATE,
        orderDirection: OrderDirections.ASC,
    },
    {
        name: 'Сначала новые',
        orderType: CommentOrderTypes.ANSWER_DATE,
        orderDirection: OrderDirections.DESC,
    },
    {
        name: 'Сначала короткие',
        orderType: CommentOrderTypes.COMMENT_LENGTH,
        orderDirection: OrderDirections.ASC,
    },
    {
        name: 'Сначала длинные',
        orderType: CommentOrderTypes.COMMENT_LENGTH,
        orderDirection: OrderDirections.DESC,
    },
    {
        name: 'Сначала негативные',
        orderType: CommentOrderTypes.MARK,
        orderDirection: OrderDirections.ASC,
    },
    {
        name: 'Сначала позитивные',
        orderType: CommentOrderTypes.MARK,
        orderDirection: OrderDirections.DESC
    },
]
