import type { FilterType, PageFilter } from '@shared/types/context'

/** Дает четкое понимание какие поля действительно в фильтре установлены сразу */
export type PainsListFilterType = PageFilter<
    Pick<
        FilterType,
        'structure'
    >> & {
        pageIndex: number
    }
