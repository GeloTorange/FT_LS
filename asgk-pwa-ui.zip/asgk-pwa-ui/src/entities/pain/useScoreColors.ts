import { useGetCSSVar } from '@shared/styles'


type ReturnColorFromScore = 'green' | 'red' | 'yellow'
export const getColorNameFromScore = (score?: number | null): ReturnColorFromScore => {
    let color = 'green' as ReturnColorFromScore
    if (score || score === 0) {
        if (score >= 45) {
            color = 'red'
        } else if (score >= 25 && score < 45) {
            color = 'yellow'
        } else if (score < 25) {
            color = 'green'
        }
    }

    return color
}

export const useScoreColors = (score?: number | null) => {
    const colorConfig = {
        red: {
            body: useGetCSSVar('--BodyRed'),
            line: useGetCSSVar('--LineRed')
        },
        yellow: {
            body: useGetCSSVar('--BodyYellow'),
            line: useGetCSSVar('--LineYellow')
        },
        green: {
            body: useGetCSSVar('--BodyGreen'),
            line: useGetCSSVar('--LineGreen')
        }
    }

    if (!score && score !== 0) {
        return {
            body: '',
            line: '',
        }
    }

    const colorName = getColorNameFromScore(score)

    return colorConfig[colorName]
}
