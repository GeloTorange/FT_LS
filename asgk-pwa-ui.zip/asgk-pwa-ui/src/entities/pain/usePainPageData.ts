import { useMemo } from 'react'
import { useSelector } from 'react-redux'
import { useParams } from 'react-router-dom'

import { useGetPainListMainStatisticQuery } from '@shared/api/pains'

// comment: для удобства импорта
// eslint-disable-next-line boundaries/element-types
import { getPainScoringChartOptionValue } from '../workspacePain'


export const usePainPageData = () => {
    const { painId, measureId } = useParams() as { painId?: string, measureId?: string }
    const selectedInfluence = useSelector(getPainScoringChartOptionValue)
    const { data, isFetching } = useGetPainListMainStatisticQuery(
        { painId: Number(painId), scoreFilter: selectedInfluence }, { skip: !!measureId }
    )

    // значение для тэга, вычисляется из последнего элемента графика
    const painScore = useMemo(() => {
        if (data && !isFetching) {
            const lastElem = data.chart.at(-1)
            return lastElem?.score
        }
        return null
    }, [data])

    return {
        painScore,
        chartData: data?.chart || [],
        isLoading: isFetching,
        painId,
        data,
        productId: data?.productId,
        // Когда нет связанного тренда, детракторы скрываются
        isShowDetractor: Boolean(data?.trendId)
    }
}
