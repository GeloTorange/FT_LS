import { ConfigProvider, App as AntdApp } from 'antd'
import localeRu from 'antd/es/locale/ru_RU'
import React from 'react'
import { useSelector } from 'react-redux'
import { Route, Routes } from 'react-router-dom'

import { useGetAntdTheme } from '@app/antTheme'
import { useInitApp } from '@app/hooks/useInitApp'
import { AppLayout } from '@app/layouts/AppLayout'
import { ErrorBoundary } from '@app/layouts/ErrorBoundary'
import { InstallPwa } from '@app/layouts/InstallPwa'
import { SessionModal } from '@app/layouts/SessionModal'
import { CustomRouter , getRoutes } from '@app/router'
import { MeasurePutModal } from '@widgets/MeasurePutModal'
import { ReasonModal } from '@widgets/ReasonModal'
import { getUserInfo } from '@entities/userInfo'
import { ScrollToTop } from '@shared/components/ScrollToTop'
import { customHistory } from '@shared/system/router'
import './shared/assets/common.scss'
import { ThemeProvider } from '@shared/system/theme'
import NotificationWrap from '@shared/utils/notification'
import './shared/system/theme/theme-colors.scss'


const App = () => {
    const themeAntd = useGetAntdTheme()
    const user = useSelector(getUserInfo)
    useInitApp()

    return (
        <ThemeProvider>
            {/*
            TODO: надо переехать на новый роутинг, чтобы использовать ScrollRestoration
             и отказаться от ScrollToTop и подобных ф-ий.
             https://reactrouter.com/6.30.0/routers/picking-a-router#data-apis
              */}
            <CustomRouter history={customHistory}>
                <ScrollToTop/>
                <ConfigProvider
                    locale={localeRu}
                    theme={themeAntd}
                >
                    <AntdApp>
                        <NotificationWrap />
                        <SessionModal/>
                        <MeasurePutModal />
                        <ReasonModal />
                        <InstallPwa/>
                        <ErrorBoundary>
                            <Routes>
                                <Route path={'/'} element={<AppLayout/>}>
                                    {getRoutes(user?.roles)}
                                </Route>
                            </Routes>
                        </ErrorBoundary>
                    </AntdApp>
                </ConfigProvider>
            </CustomRouter>
        </ThemeProvider>
    )
}

export default App
