import type { ReasonModalData } from '@entities/workspacePain'

export type ChangeableReasonFields = Pick<
    ReasonModalData,
    'AKBRatio' | 'AKBTotal' | 'description' | 'consultationRatio' | 'detractorRatio' | 'appealRatio'
>

// Нужен для упрощения проверки
export type ChangeableReasonFieldsFilled = {
    description: string
    consultationRatio: number
    appealRatio: number
    detractorRatio: number
    AKBTotal: number
    AKBRatio: number
}

export type ReasonModalPureProps = {
    isEditable: boolean
    reasonData: ReasonModalData
    isShowDetractor: boolean
}
