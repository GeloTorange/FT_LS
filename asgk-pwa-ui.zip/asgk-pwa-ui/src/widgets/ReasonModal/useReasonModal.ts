import { Form } from 'antd'
import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import { getIsShowModalReason, setIsHideModalReason, setIsShowModalReason } from '@entities/workspacePain'
import { usePutReasonMutation } from '@shared/api/reasons'
import { checkIsAllFilled } from '@shared/utils/useful'

import { normalizedValues } from './helpers'
import type { ChangeableReasonFields, ReasonModalPureProps } from './types'


// Вся логика по ReasonModal (Вынес в хук для удобства тестирования и разделения логики и отображения)
export const useReasonModal = ({ isEditable, reasonData, isShowDetractor }: ReasonModalPureProps) => {
    const dispatch = useDispatch()
    const isShow = useSelector(getIsShowModalReason)
    const [setNewReason] = usePutReasonMutation()

    const [form] = Form.useForm<ChangeableReasonFields>()
    const [initialFields, setInitialFields] = useState<ChangeableReasonFields | null>(null)

    const [isShowSavingModal, setIsShowSavingModal] = useState(false)
    const [isDirty, setIsDirty] = useState(false)
    const [isAllFilled, setIsAllFilled] = useState(false)

    const isDisableSave = !(isDirty && isAllFilled)

    useEffect(() => {
        const snapshot: ChangeableReasonFields = {
            description: reasonData.description || '',
            consultationRatio: reasonData.consultationRatio || null,
            appealRatio: reasonData.appealRatio || null,
            detractorRatio: reasonData.detractorRatio || null,
            AKBRatio: reasonData.AKBRatio || null,
            AKBTotal: reasonData.AKBTotal || null,
        }
        setInitialFields(snapshot)
        form.setFieldsValue(snapshot)
        setIsDirty(false)
        setIsAllFilled(checkIsAllFilled(snapshot))
    }, [reasonData, form])

    const onSaveReason = () => {
        const values = normalizedValues(form.getFieldsValue())

        if (values) {
            setNewReason({
                painId: reasonData.painId,
                reason: {
                    reasonId: reasonData.reasonId,
                    reasonName: values.description,
                    consultation: { ratio: values.consultationRatio },
                    appeal: { ratio: values.appealRatio },
                    ...(isShowDetractor ? { detractor: { ratio: values.detractorRatio }} : {}),
                    AKB: { ratio: values.AKBRatio, total: values.AKBTotal },
                }
            })
            dispatch(setIsHideModalReason())
        }
    }

    const onCancelWithoutSave = () => {
        dispatch(setIsHideModalReason())
        setIsShowSavingModal(false)
    }

    const onCancel = () => {
        if (isDirty) {
            dispatch(setIsHideModalReason())
            setIsShowSavingModal(true)
        } else {
            onCancelWithoutSave()
        }
    }

    const onRollbackEdit = () => {
        dispatch(setIsShowModalReason())
        setIsShowSavingModal(false)
    }

    return {
        title: `${ isEditable ? 'Редактирование' : 'Создание'} причины`,
        tooltipSaveBtn: !isDirty && isAllFilled ? 'Внесите изменения' : 'Заполните все поля',

        isShow: isShow,
        isDisableSave: isDisableSave,
        isShowSavingModal: isShowSavingModal,

        onCancel: onCancel,
        onSaveReason: onSaveReason,
        onRollbackEdit: onRollbackEdit,
        onCancelWithoutSave: onCancelWithoutSave,
        setIsDirty: setIsDirty,
        setIsAllFilled: setIsAllFilled,

        form: form,
        initialFields,
    }
}
