import { Form, InputNumber } from 'antd'
import type { ColumnsType } from 'antd/es/table'
import React, { type MemoExoticComponent, type ReactNode } from 'react'
import { useSelector } from 'react-redux'

import { getInfoForModalReason, INFLUENCE_NAME, type ReasonModalData } from '@entities/workspacePain'
import { PopoverInfo } from '@shared/components/Popovers'
import { TypographyBody } from '@shared/components/typography'
import { helperStyles } from '@shared/styles'
import { checkIsAllFilled } from '@shared/utils/useful'

import type { ChangeableReasonFields, ChangeableReasonFieldsFilled, ReasonModalPureProps } from './types'
import styles from './ui/styles.module.scss'


const ContentPopover = () => (
    <div className={styles.popoverContent}>
        За последний полный месяц
    </div>
)

type RowT = { key: INFLUENCE_NAME; name: string; total: number; ratio: number }

export const getColumns = (): ColumnsType<RowT> => [
    {
        title: 'Показатель',
        dataIndex: 'name',
        key: 'name',
        align: 'left',
        width: '34%',
    },
    {
        title: <span className={styles.totalHeader}>
            Всего&nbsp;<PopoverInfo content={ContentPopover} arrow={{ pointAtCenter: true }} />
        </span>,
        dataIndex: 'total',
        key: 'total',
        align: 'center',
        render: (v: number, row: RowT) =>
            row.key === INFLUENCE_NAME.AKB ? (
                <Form.Item
                    name={'AKBTotal'}
                    noStyle
                    rules={[{ required: true, message: 'Укажите АКБ всего' }]}
                >
                    <InputNumber
                        size={'large'}
                        className={helperStyles.fullWidth}
                    />
                </Form.Item>
            ) : (
                <InputNumber
                    disabled
                    size={'large'}
                    value={row.key === INFLUENCE_NAME.detractor ? `${v}%` : v}
                    className={helperStyles.fullWidth}
                />
            ),
        width: '33%',
    },
    {
        title: 'Причина охватит',
        key: 'ratio',
        dataIndex: 'ratio',
        align: 'center',
        width: '33%',
        render: (v: number, row: RowT) => (
            <Form.Item
                name={`${row.key}Ratio`}
                noStyle
                validateTrigger={['onSubmit']}
                rules={[
                    { required: true, message: 'Заполните поле' },
                ]}
            >
                <InputNumber
                    size={'large'}
                    min={0}
                    max={100}
                    step={1}
                    precision={0}
                    addonAfter={
                        <TypographyBody style={{ color: 'var(--IconSecondary)' }}>
                            %
                        </TypographyBody>
                    }
                />
            </Form.Item>
        ),
    },
]

export const getReasonDataSource = ({
    consultationTotal,
    appealTotal,
    detractorTotal,
    isShowDetractor,
}: Pick<ReasonModalData, 'consultationTotal' | 'appealTotal' | 'detractorTotal'> & { isShowDetractor: boolean }
): RowT[] => [
    {
        key: INFLUENCE_NAME.consultation, name: 'Консультации',
        total: consultationTotal || 0,
        ratio: 0
    },
    { key: INFLUENCE_NAME.appeal, name: 'Жалобы', total: appealTotal || 0, ratio: 0 },
    ...(isShowDetractor ?
        [{ key: INFLUENCE_NAME.detractor, name: 'Детракторы', total: detractorTotal || 0, ratio: 0 }] :
        []),
    { key: INFLUENCE_NAME.AKB, name: 'АКБ продукта', total: 0, ratio: 0 },
]

// Хок для избегания лишних рендеров когда нет данных
export const withReasonDataHOC = (
    Component: MemoExoticComponent<({ isEditable, reasonData }: ReasonModalPureProps) => ReactNode>
) => () => {
    const { isEditable, reasonData, isShowDetractor } = useSelector(getInfoForModalReason)

    return reasonData ?
        <Component
            isEditable={isEditable}
            reasonData={reasonData}
            isShowDetractor={isShowDetractor}
        />
        : null
}

// преобразование типа значений и доп проверка
export const normalizedValues = (values: ChangeableReasonFields): ChangeableReasonFieldsFilled | null => {
    if (checkIsAllFilled(values)) {
        return values as ChangeableReasonFieldsFilled
    }
    return null
}
