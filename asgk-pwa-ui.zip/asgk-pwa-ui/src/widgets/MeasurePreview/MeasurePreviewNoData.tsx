import { Flex } from 'antd'
import React, { type FC } from 'react'
import { isDesktop } from 'react-device-detect'

import { LegendForMeasureList } from '@entities/measure'
import type { PainsListFilterType } from '@entities/pain'
import { WatchAllButton } from '@shared/components/WatchAllButton'
import { PAGE_ROUTES } from '@shared/system/router'
import { generateFilterParams } from '@shared/utils/filter'

import type { MeasurePreviewProps } from './MeasurePreview'
import styles from './styles.module.scss'

export const MeasurePreviewNoData: FC<
    Pick<MeasurePreviewProps, 'isMainPageWidget'> & {
        filter: PainsListFilterType
    }> = ({
    isMainPageWidget,
    filter
}) =>
    <Flex
        align={isDesktop ? 'center' : 'end'}
        justify={'space-between'}
        vertical={!isDesktop}
        gap={isDesktop ? 0 : 17}
    >
        <div className={styles.legendMob}>
            <LegendForMeasureList />
        </div>
        {isMainPageWidget && (
            <WatchAllButton
                width={'160px'}
                pathname={PAGE_ROUTES.MEASURES}
                text={'Все меры'}
                navigatePageSearchParams={generateFilterParams({
                    unitId: filter.unitId,
                    tribeId: filter.tribeId,
                    productId: filter.productId,
                })}
            />
        )}
    </Flex>
