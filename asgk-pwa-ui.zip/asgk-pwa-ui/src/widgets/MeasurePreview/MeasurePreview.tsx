import React, { type FC, type MouseEvent, useMemo } from 'react'
import { isDesktop } from 'react-device-detect'
import { useDispatch } from 'react-redux'
import { useNavigate } from 'react-router-dom'

import {
    getColumnsMeasuresSmallWidget,
    MeasuresTitleContentPopover,
    setPutMeasureModalForStart,
    getColumnsMeasuresBigWidget
} from '@entities/measure'
import {
    type PainsListFilterType,
} from '@entities/pain'
import { type MeasuresListDataItem, useGetInfinityMeasuresListQuery } from '@shared/api/measures'
import type { NoDataProps } from '@shared/components/NoData'
import { SimpleTable } from '@shared/components/SimpleTable'
import { TypographyCaption } from '@shared/components/typography'
import { Wrappers } from '@shared/components/wrappers'
import { PAGE_ROUTES } from '@shared/system/router'
import { useUniversalFilter } from '@shared/utils/context'
import { removeEmpty } from '@shared/utils/useful'

import { MeasurePreviewNoData } from './MeasurePreviewNoData'
import styles from './styles.module.scss'


export type MeasurePreviewProps = {
    isMainPageWidget?: boolean,
    isBig: boolean,
    painId?: string,
    noDataProps?: NoDataProps
}
export const MeasurePreview: FC<MeasurePreviewProps> = ({
    isBig,
    isMainPageWidget,
    painId,
    noDataProps
}) => {
    const dispatch = useDispatch()
    const { filter } = useUniversalFilter<PainsListFilterType>()
    const navigate = useNavigate()
    const { unitId, tribeId, productId } = filter

    const { data, isFetching, isLoading } = useGetInfinityMeasuresListQuery({
        filter: removeEmpty({
            unitId,
            tribeId,
            productId,
            painId,
        }),
        page: {
            pageIndex: 1,
            pageSize: 5,
        },
    })

    const onEdit = (rowData: MeasuresListDataItem) => (e: MouseEvent<HTMLSpanElement>) => {
        e.stopPropagation()
        if (productId) {
            dispatch(setPutMeasureModalForStart({
                isShow: true,
                measureId: rowData.measureId,
                productId,
            }))
        } else {
            // comment: нужно для отработки корректности передачи productId
            // eslint-disable-next-line no-console
            console.warn('productId is null')
        }
    }

    const columns = isBig ? getColumnsMeasuresBigWidget({ onEdit }) : getColumnsMeasuresSmallWidget()


    const dataSource = useMemo(
        () => {
            if (!data) return []
            return data.list.map((item) => ({ id: String(item.measureId), ...item }))
        }, [data]
    )

    const showData = Boolean(dataSource.length) && !isFetching

    const onNavigate = ({ measureId }: MeasuresListDataItem) => {
        navigate({
            pathname: `${PAGE_ROUTES.MEASURES}/${measureId}`,
        })
    }

    // TODO: чтобы упростить излишнюю сложность, надо наладить отображение через isLoading и dataSource.length
    return (
        <Wrappers.Preview
            title={'Меры'}
            infoInTitle={String(data?.totalCount || '')}
            infoContent={<MeasuresTitleContentPopover />}
        >
            <div
                className={styles.content}
                style={{
                    marginTop: isLoading ? 0 : '-40px',
                }}
            >
                <SimpleTable<MeasuresListDataItem>
                    onClickRow={onNavigate}
                    heightContent={dataSource.length ? '348px' : 'auto'}
                    columns={columns}
                    isHideTitle={!dataSource.length}
                    dataSource={dataSource}
                    indentBottomHeader={0}
                    loaderProps={{
                        isLoadingMain: isLoading,
                        isLoadingInfinity: isFetching,
                    }}
                    noDataProps={noDataProps}
                />
                {showData &&
                    <MeasurePreviewNoData
                        isMainPageWidget={isMainPageWidget}
                        filter={filter}
                    />
                }
                {!isDesktop && !isMainPageWidget &&
                    <TypographyCaption className={styles.infoMessageMob}>
                        Добавление и редактирование мер доступно только
                        в&nbsp;десктоп&nbsp;версии&nbsp;Голоса&nbsp;Клиента
                    </TypographyCaption>
                }
            </div>
        </Wrappers.Preview>
    )
}
