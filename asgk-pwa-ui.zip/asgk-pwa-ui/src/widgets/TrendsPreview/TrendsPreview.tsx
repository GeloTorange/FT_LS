import type { URLSearchParamsInit } from 'react-router-dom'

import { Cards } from '@features/cards'
import { useGetTrendsListQuery } from '@shared/api/trends'
import type { TrendsListMainStatisticsParams } from '@shared/api/trends'
import { Wrappers } from '@shared/components/wrappers'
import { PAGE_ROUTES } from '@shared/system/router'

type Props = {
    navigatePageSearchParams?: URLSearchParamsInit,
    argForReq: TrendsListMainStatisticsParams
    description?: string,
    title?: string,
}

// Компонент списка трендов
export const TrendsPreview = ({
    navigatePageSearchParams,
    description,
    title = 'Реестр трендов',
    argForReq,
}: Props) => {
    const { data, isFetching, refetch } = useGetTrendsListQuery(argForReq)

    return (
        <Wrappers.Preview
            title={title}
            description={description}
            pathname={PAGE_ROUTES.TRENDS}
            navigatePageSearchParams={navigatePageSearchParams}
            watchAllButtonText={'Все тренды'}
        >
            <Wrappers.ScrolledContentPreview isLoading={isFetching}>
                {data?.trends?.map(({
                    id, name, parent, favorite,
                    chartData, type, trendRatioPct,
                    trendRatioPctIncr, createdAt
                }) => (
                    <Cards.Trend
                        key={id}
                        id={id}
                        description={parent?.name}
                        title={name}
                        isFavorite={favorite}
                        loadData={refetch}
                        chartData={chartData}
                        trendType={type}
                        trendRatioPct={trendRatioPct}
                        trendRatioPctIncr={trendRatioPctIncr}
                        createdAt={createdAt}
                        navigatePageSearchParams={navigatePageSearchParams}
                    />
                ))}
            </Wrappers.ScrolledContentPreview>
        </Wrappers.Preview>
    )
}
