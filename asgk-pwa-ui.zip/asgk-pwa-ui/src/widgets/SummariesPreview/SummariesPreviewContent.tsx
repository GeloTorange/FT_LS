import { Col, Row } from 'antd'
import React, { useEffect } from 'react'
import { isDesktop } from 'react-device-detect'

import { Cards } from '@features/cards'
import { useGetSampleSummariesQuery } from '@shared/api/summaries'
import { Loaders } from '@shared/components/loaders'
import type { FilterType } from '@shared/types/context'
import { AggregateTypes } from '@shared/types/filters'
import { filterPeriod } from '@shared/utils/defaultDatesHelper'



type Props =
    {
        filter: Pick<FilterType, 'appealType' | 'factorica' | 'productId'>
        startDate?: string,
        endDate?: string,
        setTotal: (total?: number) => void,
        setIsFetching: (isFetching: boolean) => void,
    }

export const SummaryPreviewContent: React.FC<Props> = ({
    filter,
    startDate = filterPeriod[AggregateTypes.WEEK].startDateShort as string,
    endDate = filterPeriod[AggregateTypes.WEEK].endDate,
    setTotal,
    setIsFetching,
}) => {
    const { data: allSummaries, isFetching } = useGetSampleSummariesQuery({
        filters: {
            toxicFlag: filter.appealType,
            productId: filter.productId,
            theme: filter.factorica,
            startDate,
            endDate
        },
        pageOptions: {
            index: 1,
            size: isDesktop ? 4 : 2,
        },
        sortingOptions: {
            sortField: 'appCreated',
            isSortingAsc: false
        }
    })

    const total = allSummaries?.total
    const dataSource = allSummaries?.data

    useEffect(() => {
        setIsFetching(isFetching)
    }, [isFetching, setIsFetching])

    useEffect(() => {
        setTotal(total)
    }, [total, setTotal])

    return (isFetching
        ? <Loaders.Comments cardsCount={isDesktop ? 4 : 2} />
        : <Row gutter={[16, 16]}>
            {
                dataSource ?
                    dataSource.map((item, idx) => (
                        <Col key={idx} span={isDesktop ? 12 : 24}>
                            <Cards.Summary
                                key={idx} summary={item} appealType={filter.appealType} isShowProductName
                            />
                        </Col>
                    ))
                    : null
            }
        </Row>
    )
}