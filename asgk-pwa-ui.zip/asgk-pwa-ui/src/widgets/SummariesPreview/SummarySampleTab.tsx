import { Space } from 'antd'
import React from 'react'

import styles from '@widgets/CommentsPreview/styles.module.scss'
import { SummaryPreviewContent } from '@widgets/SummariesPreview/SummariesPreviewContent'
import { WatchAllButton } from '@shared/components/WatchAllButton'
import { PAGE_ROUTES } from '@shared/system/router'
import { generateFilterParams } from '@shared/utils/filter'

type Props = {
    appealType: string,
    productId: string,
    factorica: string,
    setTotal: (total: number | null | undefined) => void,
    setIsFetching: (isFetching: boolean) => void,
}

export const SummarySampleTab: React.FC<Props> = ({
    appealType,
    productId ,
    factorica,
    setTotal,
    setIsFetching,
}) => (
    <Space size={16} direction={'vertical'} className={styles.commentsContentUniversal}>
        <SummaryPreviewContent
            filter={{
                appealType,
                productId,
                factorica,
            }}
            setTotal={setTotal}
            setIsFetching={setIsFetching}
        />
        <WatchAllButton
            pathname={PAGE_ROUTES.TOPICS_SUMMARY}
            navigatePageSearchParams={
                generateFilterParams({
                    productId,
                    appealType,
                    factorica,
                })
            }
        />
    </Space>
)
