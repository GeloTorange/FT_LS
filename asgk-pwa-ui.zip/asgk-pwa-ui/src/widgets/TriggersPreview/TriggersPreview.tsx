import type { URLSearchParamsInit } from 'react-router-dom'

import { Cards } from '@features/cards'
import type { TriggerMainStatisticsParams } from '@shared/api/triggers'
import { useGetTriggerListQuery } from '@shared/api/triggers'
import { Wrappers } from '@shared/components/wrappers'
import { PAGE_ROUTES } from '@shared/system/router'

type Props = {
    navigatePageSearchParams?: URLSearchParamsInit,
    argForReq: TriggerMainStatisticsParams
    description?: string,
    title?: string,
}

// Компонент списка опросов
export const TriggersPreview = ({
    navigatePageSearchParams,
    description,
    title = 'Реестр опросов',
    argForReq,
}: Props) => {
    const { data, isFetching, refetch } = useGetTriggerListQuery(argForReq)

    return (
        <Wrappers.Preview
            title={title}
            description={description}
            pathname={PAGE_ROUTES.TRIGGERS}
            navigatePageSearchParams={navigatePageSearchParams}
            watchAllButtonText={'Все опросы'}
        >
            <Wrappers.ScrolledContentPreview isLoading={isFetching}>
                {data?.triggers?.map(({
                    id, name, parent, favorite,
                    statistics, csi, csiIncrPct,
                }) => (
                    <Cards.Trigger
                        key={id}
                        description={parent?.name || ''}
                        id={id}
                        title={name}
                        isFavorite={favorite}
                        statistics={statistics}
                        loadData={refetch}
                        navigatePageSearchParams={navigatePageSearchParams}
                        csi={csi}
                        csiIncrPct={csiIncrPct}
                    />
                ))}
            </Wrappers.ScrolledContentPreview>
        </Wrappers.Preview>
    )
}
