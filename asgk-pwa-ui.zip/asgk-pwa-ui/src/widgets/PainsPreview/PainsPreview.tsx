import { Flex } from 'antd'
import React, { type FC, type ReactNode, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'

import {
    getColumnsPainsForPreview,
    LegendForPainList,
    type PainsListFilterType,
} from '@entities/pain'
import { PainsTitleContentPopover } from '@entities/pain'
import { type PainsListDataItem, useGetInfinityPainsListQuery } from '@shared/api/pains'
import { SimpleTable } from '@shared/components/SimpleTable'
import { TypographyTitle2 } from '@shared/components/typography'
import { WatchAllButton } from '@shared/components/WatchAllButton'
import { Wrappers } from '@shared/components/wrappers'
import { PAGE_ROUTES } from '@shared/system/router'
import { useUniversalFilter } from '@shared/utils/context'
import { generateFilterParams } from '@shared/utils/filter'
import { removeEmpty } from '@shared/utils/useful'

import styles from './styles.module.scss'

type Props = {
    measureWidget?: boolean,
    height: string,
    contentHeight: string,
    title: ReactNode,
    measureId?: string,
    painsCount?: number,
}

export const PainsPreview: FC<Props> = ({
    measureWidget = false,
    height,
    contentHeight,
    title,
    measureId,
    painsCount = 5,
}) => {
    const { filter } = useUniversalFilter<PainsListFilterType>()
    const navigate = useNavigate()
    const { unitId, tribeId, productId } = filter

    const { data, isFetching } = useGetInfinityPainsListQuery({
        filter: removeEmpty({
            unitId,
            tribeId,
            productId,
            measureId,
        }),
        page: {
            // добавить скролл пагинацию
            pageIndex: 1,
            pageSize: painsCount,
        },
    })

    const columns = getColumnsPainsForPreview()
    const dataSource = useMemo(
        () => {
            if (!data) return []
            return data.list.
                map((item) => ({ id: String(item.painId), ...item }))
        },
        [data])

    const isShowData = dataSource.length !== 0

    const onNavigate = ({ painId }: PainsListDataItem) => {
        navigate({
            pathname: `${PAGE_ROUTES.PAINS}/${painId}`,
        })
    }

    return (
        <Wrappers.Preview
            height={height}
            title={title}
            infoInTitle={String(data?.totalCount || '')}
            infoContent={<PainsTitleContentPopover />}
            rightHeaderText={
                <TypographyTitle2 style={{ marginRight: '2%', whiteSpace: 'pre' }}>
                    {'Скоринг\nпо трайбу'}
                </TypographyTitle2>}
        >
            <div className={styles.content}>
                <SimpleTable
                    isHideTitle
                    onClickRow={onNavigate}
                    heightContent={contentHeight}
                    columns={columns}
                    dataSource={dataSource}
                    indentBottomHeader={0}
                    loaderProps={{
                        isLoadingMain: isFetching,
                        count: 5
                    }}
                    noDataProps={{
                        text: 'Болей пока нет',
                    }}
                />
                {isShowData && !measureWidget &&
                    <Flex align={'center'} justify={'space-between'}>
                        <div className={styles.legendMob}>
                            <LegendForPainList/>
                        </div>
                        <WatchAllButton
                            // Есть прикол с тем что кнопка от Агента заезжает на эту кнопку,
                            // пока ничего лучше не придумали, чем сделать ширину кликабельной области больше
                            width={'160px'}
                            pathname={PAGE_ROUTES.PAINS}
                            text={'Все боли'}
                            navigatePageSearchParams={
                                generateFilterParams({
                                    unitId: filter.unitId,
                                    tribeId: filter.tribeId,
                                    productId: filter.productId,
                                })
                            }
                        />
                    </Flex>
                }
            </div>
        </Wrappers.Preview>
    )
}
