import { useMemo } from 'react'

import type { KpiData } from '@features/charts/TopicsKpiGraph'
import type { GetMainStatisticParams, MainStatisticItem } from '@shared/api/topics'
import { useGetMainStatisticQuery } from '@shared/api/topics'


const mapper = (item: MainStatisticItem) => [item.firstDayOfMonth, item.plan, item.fact] as KpiData

export const useKpiData = (filter?: GetMainStatisticParams) => {
    const { data, isFetching } = useGetMainStatisticQuery(filter || {})

    return useMemo(() => ({
        isFetching,
        data: {
            consultations: (data?.statisticDashboardConsultationsList || []).map(mapper),
            appeals: (data?.statisticDashboardComplaintsList || []).map(mapper),
        }
    }), [data])
}