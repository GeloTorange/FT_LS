import { Space } from 'antd'
import dayjs from 'dayjs'
import type { FC } from 'react'
import { useMemo } from 'react'

import type { Structure } from '@entities/topics'
import { useTopicQueryStringFilter } from '@entities/topics'
import type { GetMainStatisticParams } from '@shared/api/topics'
import { TopicType } from '@shared/api/topics'

import { GraphCad } from './components/GraphCad'
import { useKpiData } from './useKpiData'

interface TopicsKpiProps {
    filter?: GetMainStatisticParams,
    graphHeight?: string | number
}

const style = { width: '100%' }

export const TopicsKpi: FC<TopicsKpiProps> = ({ filter = {}, graphHeight }) => {
    const [,,generateFilterQueryString] = useTopicQueryStringFilter()
    const { data, isFetching } = useKpiData(filter)

    const filterString = useMemo(() => {
        const minDate = data?.appeals.length
            ? dayjs(data.appeals[0][0]).startOf('month')
            : undefined
        const maxDate = data?.appeals.length
            ? dayjs(data.appeals[data.appeals.length - 1][0]).endOf('month')
            : undefined
        return {
            [TopicType.consultation]: generateFilterQueryString({
                type: TopicType.consultation,
                structure: filter as Structure,
                period: [minDate, maxDate]
            }),
            [TopicType.appeal]: generateFilterQueryString({
                type: TopicType.appeal,
                structure: filter as Structure,
                period: [minDate, maxDate]
            }),
        }
    }, [generateFilterQueryString, filter, data])

    return (
        <Space direction={'vertical'} style={style} size={'middle'}>
            <GraphCad
                type={TopicType.consultation}
                data={data.consultations}
                graphHeight={graphHeight}
                filterString={filterString[TopicType.consultation]}
                isLoading={isFetching}
            />
            <GraphCad
                type={TopicType.appeal}
                data={data.appeals}
                graphHeight={graphHeight}
                filterString={filterString[TopicType.appeal]}
                isLoading={isFetching}
            />
        </Space>
    )
}
