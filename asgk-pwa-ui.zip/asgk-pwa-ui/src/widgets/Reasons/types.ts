import type { ReasonItem } from '@shared/api/reasons'

export type ReasonRowType = {
    id: string
    action: ReasonItem['reasonId']
    reasonName: ReasonItem['reasonName']
    consultationRatio: ReasonItem['consultation']['ratio']
    consultationPieces: ReasonItem['consultation']['ratioPieces']
    appealRatio: ReasonItem['appeal']['ratio']
    appealPieces: ReasonItem['appeal']['ratioPieces']
    detractorRatio: ReasonItem['detractor']['ratio']
    AKBRatio: ReasonItem['AKB']['ratio']
    AKBPieces: ReasonItem['AKB']['ratioPieces']
}
