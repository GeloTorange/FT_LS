import React, { useMemo } from 'react'
import { isDesktop } from 'react-device-detect'
import { useDispatch, useSelector } from 'react-redux'

import {
    getInfluenceForReason,
    INFLUENCE_NAME,
    setEditReasonForModal,
    setIsShowModalReason,
} from '@entities/workspacePain'
import { useGetReasonListQuery } from '@shared/api/reasons'
import { EditPencil } from '@shared/assets/icons'
import type { SimpleTableProps } from '@shared/components/SimpleTable'
import { TypographyBody } from '@shared/components/typography'
import { helperStyles } from '@shared/styles'
import { numShort } from '@shared/utils/formatting'
import { removeEmpty } from '@shared/utils/useful'

import styles from './styles.module.scss'
import type { ReasonRowType } from './types'


type OnEdit = (reasonId: ReasonRowType) => (() => void)

const getSpan = (influence: INFLUENCE_NAME) => isDesktop
    ? { spanName: influence !== INFLUENCE_NAME.detractor ? 15 : 19, spanValue: 4 }
    : { spanName: 18, spanValue: 6 }

type DataIndexType = SimpleTableProps<ReasonRowType>['columns'][0]['dataIndex']

type GetColumns = {
    influence: INFLUENCE_NAME
    onEdit: OnEdit
    isMeasure: boolean
}
const getColumns = ({
    influence,
    onEdit,
    // Для мер редактирование скрываем
    isMeasure,
}: GetColumns): SimpleTableProps<ReasonRowType>['columns'] => [
    {
        title: '',
        dataIndex: 'reasonName',
        id: 'reasonName',
        span: isMeasure ? 20 : getSpan(influence).spanName,
        className: styles.reasonName,
        render: ({ reasonName }) =>
            <TypographyBody
                className={helperStyles.ellipsisOneLine}
                title={reasonName}
            >
                {reasonName}
            </TypographyBody>
    },
    {
        title: 'Доля, %',
        dataIndex: `${influence}Ratio`,
        id: `${influence}Ratio`,
        span: isMeasure ? 2 : getSpan(influence).spanValue,
        render: (rowData) => <TypographyBody>{rowData[`${influence}Ratio`]}%</TypographyBody>,
    },
    ...(influence !== INFLUENCE_NAME.detractor) ? [{
        title: 'Доля, шт',
        dataIndex: `${influence}Pieces` as DataIndexType,
        id: `${influence}Pieces`,
        span: isMeasure ? 2 : 4,
        hideInMob: true,
        className: styles.reasonPieces,
        classNameHeader: styles.reasonPieces,
        render: (rowData: ReasonRowType) =>
            <TypographyBody>
                {numShort(rowData[`${influence}Pieces`])}
            </TypographyBody>
    }] : [],
    ...(isMeasure) ? [] : [{
        title: '',
        dataIndex: 'action' as DataIndexType,
        id: 'action',
        span: 1,
        hideInMob: true,
        render: (rowData: ReasonRowType) =>
            <EditPencil className={styles.editIcon} onClick={onEdit(rowData)} />
    }]
]
type UseReasons = {
    painId?: string
    measureId?: string
    isShowDetractor: boolean
}
export const useReasons = ({ painId, measureId, isShowDetractor = true }: UseReasons) => {
    const dispatch = useDispatch()
    const { data, isFetching } = useGetReasonListQuery(removeEmpty({
        ...painId && { painId: Number(painId) },
        measureId,
    }))
    const totalCount = data?.totalCount ? String(data.totalCount) : ''

    const influence = useSelector(getInfluenceForReason)

    const onEdit: OnEdit = (rowData) => () => {
        const reason = data?.list.find(el => el.reasonId === rowData.action)

        if (reason && data) {
            dispatch(setIsShowModalReason())
            dispatch(
                setEditReasonForModal({
                    reasonData: {
                        painId: Number(painId),
                        reasonId: reason.reasonId,
                        description: reason.reasonName,
                        AKBTotal: data.AKB,
                        consultationRatio: reason.consultation.ratio,
                        consultationTotal: reason.consultation.total,
                        appealRatio: reason.appeal.ratio,
                        appealTotal: reason.appeal.total,
                        detractorRatio: reason.detractor?.ratio,
                        detractorTotal: reason.detractor?.total,
                        AKBRatio: reason.AKB.ratio,
                    },
                    isShowDetractor
                })
            )
        }
    }

    const dataSource: ReasonRowType[] = useMemo(() => {
        if (!data) return []
        return data.list.map((item) => ({
            id: String(item.reasonId),
            action: item.reasonId,
            reasonName: item.reasonName,
            consultationRatio: item.consultation.ratio,
            consultationPieces: item.consultation.ratioPieces,
            appealRatio: item.appeal.ratio,
            appealPieces: item.appeal.ratioPieces,
            detractorRatio: item.detractor?.ratio,
            AKBRatio: item.AKB.ratio,
            AKBPieces: item.AKB.ratioPieces,
        }))
    }, [data])

    return {
        columns: getColumns({ influence, onEdit, isMeasure : !!measureId }),
        totalCount,
        dataSource,
        isFetching,
        AKBTotal: data?.AKB
    }
}
