import React, { type FC, useMemo } from 'react'
import { isDesktop } from 'react-device-detect'

import { ButtonAddReason } from '@features/ButtonAddReason'
import { usePainPageData } from '@entities/pain'
import { SimpleTable } from '@shared/components/SimpleTable'
import { TypographyCaption } from '@shared/components/typography'
import { Wrappers } from '@shared/components/wrappers'

import { SelectInfluenceReason } from './domain/SelectInfluenceReason'
import { useReasons } from './hooks'
import styles from './styles.module.scss'
import type { ReasonRowType } from './types'


type Props = {
    measureId?: string,
    painId?: string,
    height: string,
    contentHeight: string,
    noDataText?: string,
}

const PopoverContentInfo = () =>
    <div style={{ width: 260 }}>
        То, что послужило возникновению боли&nbsp;клиента.&nbsp;Заполняется&nbsp;продуктом.
    </div>

export const Reasons: FC<Props> = ({
    painId,
    height,
    contentHeight,
    measureId,
    noDataText
}) => {
    const { data, isLoading, isShowDetractor } = usePainPageData()
    const { isFetching, columns, dataSource, totalCount, AKBTotal } = useReasons({
        painId,
        measureId,
        isShowDetractor,
    })

    const isShowNoData = !isFetching && Boolean(!dataSource.length)
    const isLoadingAll = isFetching || isLoading

    const stylesConfig = useMemo(
        () =>
            isDesktop
                ? {
                    height: height || '364px',
                    wrapper: styles.contentContainer,
                }
                : {
                    height: height || 'auto',
                    wrapper: styles.contentContainerMob,
                },
        [height],
    )

    return (
        <Wrappers.Preview
            // Чтобы карточки Скоринг и Причины были ровные
            height={stylesConfig.height}
            title={'Причины'}
            infoInTitle={totalCount}
            rightHeaderComponent={
                !isShowNoData && (
                    <SelectInfluenceReason isShowDetractor={isShowDetractor} />
                )
            }
            infoContent={PopoverContentInfo}
        >
            <div className={stylesConfig.wrapper}>
                <SimpleTable<ReasonRowType>
                    isHideTitle={dataSource.length === 0}
                    heightContent={contentHeight}
                    columns={columns}
                    dataSource={dataSource}
                    className={styles.tableReasons}
                    loaderProps={{
                        isLoadingMain: isFetching,
                        heightRow: '42px',
                    }}
                    noDataProps={{
                        text: noDataText,
                        footer: isDesktop && data && painId && !measureId && (
                            <ButtonAddReason
                                AKBTotal={AKBTotal}
                                isLoading={isLoadingAll}
                                chartData={data.chart}
                                painId={painId}
                                isShowDetractor={isShowDetractor}
                            />
                        ),
                    }}
                />
                {!isDesktop && (
                    <TypographyCaption className={styles.infoMessageMob}>
                        Добавление и редактирование причин доступно только
                        в&nbsp;десктоп&nbsp;версии&nbsp;Голоса&nbsp;Клиента
                    </TypographyCaption>
                )}
            </div>
        </Wrappers.Preview>
    )
}
