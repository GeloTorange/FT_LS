import type { PeriodRangeDatePickerProps } from '@shared/components/formInputs'
import type { FilterType } from '@shared/types/context'
import type { ExtraFilterFormData, FilterFormData } from '@shared/types/filters'


export type NameFields = keyof (
    Pick<FilterFormData,
    | 'structure'
    | 'clientSegment'
    | 'versionSBOLId'
    | 'triggerType'
    | 'triggerId'
    | 'trendId'
    | 'trendType'
    | 'searchWord'
    | 'cmId'
    | 'minLength'
    | 'marks'
    | 'periodArray'
    > & Pick<ExtraFilterFormData, 'appealType' | 'factorica'> )


export type GetIsFilled = ({ filter, isShortView }: { filter: FilterType, isShortView: boolean }) => boolean
export type FilterConstructorProps<T extends readonly NameFields[]> = {
    disableFilterButton?: boolean
    fields: T
    propsFields?: PropsFields
    getIsFilled: GetIsFilled,
    fieldsNotToReset?: NameFields[]
}

export type PropsFields = {
    structure?: {
        selectionMode?: PeriodRangeDatePickerProps['selectionMode']
        disabled?: boolean
    },
    triggerType?: {
        disabled?: boolean
    },
    triggerId?: {
        isInTrends?: boolean
    }
}
