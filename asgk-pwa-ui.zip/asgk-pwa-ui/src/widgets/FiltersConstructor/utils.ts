import { Form, type FormInstance } from 'antd'
import { useEffect, useMemo, useState } from 'react'
import { isDesktop } from 'react-device-detect'
import { useParams } from 'react-router-dom'

import { TopicType } from '@shared/api/topics'
import { type FilterType } from '@shared/types/context'
import type { FilterFormData } from '@shared/types/filters'
import { useIsShortWindowForFilter } from '@shared/utils/filter'
import { toObjTreeStructureValue } from '@shared/utils/forTreeStructure'
import { removeEmpty } from '@shared/utils/useful'

import type { GetIsFilled } from './types'
import { createFilterComponents } from './ui/settingsFilter'


type GetIsFilledFilterForm = {
    filter: FilterType,
    getIsFilled: GetIsFilled
}
// Получить флаг заполненности фильтра формы если выбраны фильтры, которых нет в шапке (бывшие тэги)
export const useGetIsFilledFilterForm = ({
    filter, getIsFilled
}: GetIsFilledFilterForm) => {
    const isShortWindow = useIsShortWindowForFilter()

    return useMemo(() =>
        getIsFilled({
            filter,
            // Если МП или маленький экран десктопа
            isShortView: Boolean(!isDesktop || isShortWindow)
        }), [filter, isDesktop, isShortWindow]
    )
}


export const useGetInitFilterForm = (form: FormInstance<FilterFormData>) => {
    const { trendId: trendIdParam } = useParams()
    const { useWatch } = Form
    const structureFromForm = useWatch('structure', form)
    const triggerType = useWatch('triggerType', form)
    const triggerId = useWatch('triggerId', form)
    const trendId = useWatch('trendId', form)

    const parsedStructure = useMemo(
        () =>
            removeEmpty({
                ...toObjTreeStructureValue(structureFromForm),
            }),
        [structureFromForm],
    )

    const FILTER_COMPONENTS = useMemo(
        () => createFilterComponents(),
        [],
    )

    return {
        FILTER_COMPONENTS,
        valueForm: {
            trendId: trendIdParam || trendId,
            parsedStructure,
            triggerType: triggerType || null,
            triggerId,
            appealType: TopicType.appeal,
        }
    }
}

export const useSubmittable = (form: FormInstance<FilterFormData>) => {
    const [submittable, setSubmittable] = useState<boolean>(true)
    const cmIdFromForm = Form.useWatch(['cmId'], form)

    useEffect(() => {
        // TODO: надо подумать и переделать на решение без useEffect
        if (cmIdFromForm) {
            form
                .validateFields({ validateOnly: false })
                .then(() => { setSubmittable(true) })
                .catch(() => { setSubmittable(false) })
        }
    }, [form, cmIdFromForm])

    return { submittable, setSubmittable }
}
