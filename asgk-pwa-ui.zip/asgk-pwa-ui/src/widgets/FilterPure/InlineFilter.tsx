import { Form, Row } from 'antd'
import { useCallback, useEffect } from 'react'

import { InlineFieldWrapper } from './components/InlineFieldWrapper'
import { useLinkedFieldsHandler } from './hooks/useLinkedFieldsHandler'
import type { Filter, BaseFilterProps } from './types'

export type InlineFilterProps<T extends Filter<keyof T>> = BaseFilterProps<T>

const style = { width: '100%' }

export const InlineFilter = <T extends Filter<keyof T>>({
    onApply, 
    disabled, 
    filter, 
    fieldDefs,
    onValuesChange,
}: InlineFilterProps<T>) => {
    const [form] = Form.useForm()

    useEffect(() => {
        // устанавливаем актуальные значения
        form.resetFields()
        form.setFieldsValue(filter)
    }, [form, filter])

    const linkedFieldsHandler = useLinkedFieldsHandler(form, fieldDefs, onValuesChange)

    const handleValueChange = useCallback((changedValues: Partial<T>, allValues: T) => {
        linkedFieldsHandler(changedValues, allValues)
        if (onApply) {
            onApply(form.getFieldsValue(true))
        }
    }, [linkedFieldsHandler, onApply, form])

    return (
        <Form<T>
            style={style}
            disabled={disabled}
            form={form}
            colon={false}
            layout={'inline'}
            onValuesChange={handleValueChange}
            size={'large'}
        >
            <Row style={style} gutter={[8, 0]}>
                {fieldDefs?.map((def) => (
                    <InlineFieldWrapper key={(def.name || def.widget) as string} field={def} />
                ))}
            </Row>
        </Form>
    )
}
