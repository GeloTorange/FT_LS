import { Form } from 'antd'
import { useCallback, useEffect, useMemo } from 'react'
import { isDesktop } from 'react-device-detect'

import { useIsShortWindowForFilter } from '@shared/utils/filter'

import { FieldWrapper } from './components/FieldWrapper'
import { ModalFilterWrapper } from './components/ModalFilterWrapper'
import { useHasAppliedFields } from './hooks/useHasAppliedFields'
import { useLinkedFieldsHandler } from './hooks/useLinkedFieldsHandler'
import { useSubmittable } from './hooks/useSubmittable'
import type { BaseFilterProps, DialogFilterProps, Filter } from './types'


export type ModalFilterProps<T extends Filter<keyof T>> = BaseFilterProps<T> & DialogFilterProps

export const ModalFilter = <T extends Filter<keyof T>>({
    width = 680,
    disabled,
    isApplied,
    buttonText = 'Ещё фильтры',
    onApply,
    onReset,
    filter,
    fieldDefs,
    labelColSpan = 8,
    onValuesChange,
    displayOnLargeWindow,
    appliedFields,
}: ModalFilterProps<T>) => {
    const [form] = Form.useForm()
    const submittable = useSubmittable(form)
    const isSmallWindow = useIsShortWindowForFilter()

    const setActualValues = useCallback(() => {
        form.resetFields()
        form.setFieldsValue(filter)
    }, [form, filter])

    useEffect(() => {
        setActualValues()
    }, [setActualValues])

    const apply = useCallback(() => form.validateFields()
        .then((values) => {
            if (onApply) {
                onApply(values)
            }
            return Promise.resolve()
        }), [form, onApply])

    const reset = useCallback(() => {
        setActualValues()
        if (onReset) {
            onReset()
        }
    }, [setActualValues, onReset])

    const linkedFieldsHandler = useLinkedFieldsHandler(form, fieldDefs, onValuesChange)

    const hasAppliedFields = useHasAppliedFields(fieldDefs, appliedFields)

    const labelCol = useMemo(() => ({ span: labelColSpan }), [labelColSpan])

    return (!isDesktop || isSmallWindow || displayOnLargeWindow)
        ? (
            <ModalFilterWrapper
                width={width}
                disabled={disabled}
                submittable={submittable}
                isApplied={isApplied || hasAppliedFields}
                buttonText={isDesktop ? buttonText : undefined}
                onApply={apply}
                onReset={reset}
                onCancel={setActualValues}
            >
                <Form<T>
                    form={form}
                    labelCol={labelCol}
                    labelAlign={'left'}
                    colon={false}
                    layout={isDesktop ? 'horizontal' : 'vertical'}
                    onValuesChange={linkedFieldsHandler}
                    size={'large'}
                >
                    {fieldDefs?.map((def) => (
                        <FieldWrapper key={(def.name || def.widget) as string} field={def} />)
                    )}
                </Form>
            </ModalFilterWrapper>
        )
        : null
}
