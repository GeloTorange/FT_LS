import { Flex } from 'antd'

import { InlineFilter } from './InlineFilter'
import { ModalFilter } from './ModalFilter'
import type { Filter, BaseFilterProps, DialogFilterProps } from './types'

export interface FilterProps<T extends Filter<keyof T>> extends BaseFilterProps<T> {
    dialog?: Omit<DialogFilterProps, 'onReset'>;
}

export const CompoundFilter = <T extends Filter<keyof T>>(props: FilterProps<T>) => {
    const { dialog, ...baseProps } = props
    return (
        <Flex justify={'space-between'} align={'center'}>
            <InlineFilter {...baseProps} />
            <ModalFilter {...baseProps} {...dialog} onReset={baseProps?.onApply} />
        </Flex>
    )
}
