import type { FormItemProps } from 'antd'
import type { RangePickerProps } from 'antd/es/date-picker'

import type { SelectionMode } from '@shared/components/formInputs/PeriodRangeDatePicker'

/* comment: для удобства */
/* eslint-disable line-comment-position */

/**
 * Тип ключей фильтра (в объекте ключ-значение)
 */
type Key = string | number | symbol

/**
 * Тип фильтра
 */
export type Filter<T extends Key> = Partial<Record<T, unknown>>

/**
 * Типы виджетов для полей формы
 */
export type FieldWidget = 'structure' | 'searchWord' | 'periodArray' | 'appealType' | 'clientSegment' |
    'versionSBOLId' | 'triggerType' | 'triggerId' | 'trendType' | 'trendId' | 'factorica' | 'commentId' |
    'minLength' | 'marks'

/**
 * Свойства, определяющие видимсоть поля формы на широком/узком окне или в мобильном приложении
 */
export interface WindowSizeProps {
    isHiddenOnSmallWindow?: boolean;
    isHiddenOnLargeWindow?: boolean;
    isHiddenOnMobile?: boolean;
}

/**
 * "Заполнитель" пустого поля для DatePicker ([string, string] для DatePicker)
 */
export type Placeholder = string | [string, string]

/**
 * Свойства полей формы для инлайн-фильтра
 * @var colSpan "ширина" поля
 * @var placeholder "заполнитель" пустого поля для инлайн-фильтра,
 *      если не указан, то берется label из BaseFieldDefinition
 */
export interface InlineFieldDefinition<P extends Placeholder = Placeholder> extends WindowSizeProps {
    colSpan?: number;
    placeholder?: P;
}

/**
 * Обработчик связанных значений при изменении поля
 * @param allValues объект ключ-значение с текущими значениями всех полей
 *      (измененное поле извествно по описанию поля, в котормо указывается обработчик)
 * @return объект ключ-значение для тех полей, которые теребуются поменять. Объект будет слит со всеми значениями
 */
export type OnFieldUpdateHandler<T> = (allValues: T) => Partial<T>

/**
 * Описание поля для показа в форме фильтра
 * @var widget используемый тип виджета (@see FieldWidget)
 * @var name ключь в фильтре (объекте ключь-занчение), соотвествующее описываемому полю.
 *      Это же занчение будет использовано как имя поля в форме.
 *      Если не указано, то берется значение widget
 * @var label метка поля в форме модального фильтра. Используется так же как placeholder в инлайн-фильтре
 * @var placeholder "заполнитель" пустого поля для модального фильтра
 * @var onUpdate обработчик связанных значений при изменении поля. Если для формы задано onValuesChange,
 *      то сперва выполянется onValuesChange, затем onUpdate
 * @var rules правила валидации значения поля (@see FormItemProps['rules'])
 * @var inline свойства полей формы для инлайн-фильтра (@see InlineFieldDefinition)
 */
export interface BaseFieldDefinition<T extends Filter<keyof T>, P extends Placeholder> {
    widget: FieldWidget;
    name?: keyof T;
    label?: string;
    placeholder?: P;
    onUpdate?: OnFieldUpdateHandler<T>;
    rules?: FormItemProps['rules'];
    inline?: InlineFieldDefinition<P>;
}

export interface StructureFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'structure';
    preserveValues?: boolean;
}
export interface SearchWordFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'searchWord';
}
export interface PeriodArrayFieldDefinition<T extends Filter<keyof T>> 
    extends BaseFieldDefinition<T, [string, string]> {
    widget: 'periodArray';
    disabledDate?: RangePickerProps['disabledDate'];
    selectionMode?: SelectionMode;
}
export interface AppealTypeFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'appealType';
    allowClear?: boolean;
}
export interface ClientSegmentFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'clientSegment';
}
export interface VersionSbolIdFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'versionSBOLId';
}
export interface TriggerTypeFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'triggerType';
    structureField?: keyof T; // default - 'structure'
}
export interface TriggerIdFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'triggerId';
    isInTrends?: boolean;
    structureField?: keyof T; // default - 'structure'
    triggerTypeField?: keyof T; // default - 'triggerType'
    trendIdField?: keyof T; // default - 'trendId'
}
export interface TrendTypeFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'trendType';
}
export interface TrendIdFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'trendId';
    structureField?: keyof T; // default - 'structure'
    triggerTypeField?: keyof T; // default - 'triggerType'
    triggerIdField?: keyof T; // default - 'triggerId'
}
export interface FactoricaFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'factorica';
}
export interface CommentIdFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'commentId';
}
export interface MinLengthFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'minLength';
    checkboxValue?: number; // default - 300
}
export interface MarksFieldDefinition<T extends Filter<keyof T>> extends BaseFieldDefinition<T, string> {
    widget: 'marks';
}

export type FieldDefinition<T extends Filter<keyof T>> =
  StructureFieldDefinition<T> |
  SearchWordFieldDefinition<T> |
  PeriodArrayFieldDefinition<T> |
  AppealTypeFieldDefinition<T> |
  ClientSegmentFieldDefinition<T> |
  VersionSbolIdFieldDefinition<T> |
  TriggerTypeFieldDefinition<T> |
  TriggerIdFieldDefinition<T> |
  TrendTypeFieldDefinition<T> |
  TrendIdFieldDefinition<T> |
  FactoricaFieldDefinition<T> |
  CommentIdFieldDefinition<T> |
  MinLengthFieldDefinition<T> |
  MarksFieldDefinition<T>

/**
 * Обрабтчик изменения значений связанных полей формы
 * @param changedValues объект ключ-значение с измененными полями
 * @param allValues объект ключ-значение со значениями всех полей
 * @return объект ключ-значение для тех полей, которые теребуются поменять. Объект будет слит со всеми значениями
*/
export type OnFormUpdateHandler<T> = (changedValues: Partial<T>, allValues: T) => Partial<T>

/**
 * Базовые свойства фильтра
 * @var filter текущее значение фильтра
 * @var fieldDefs - массив описания полей формы фильтра (@see FieldDefinition)
 * @var onApply - обработчик применения новых значений фильтра
 *      (пустой аргуемент - сброс фильтра к значениям по умолчанию)
 * @var onValuesChange - обрабтчик изменения значений связанных полей формы.
 *      Если какое-либо поле имеет обработчик onUpdate, то сперва выполяентся onValuesChange (уровень формы),
 *      а затем onUpdate (уровень поля) (@see OnFormUpdateHandler)
 * @var disabled - флаг блокировки полей формы
 */
export interface BaseFilterProps<T extends Filter<keyof T>> {
    filter?: T;
    fieldDefs?: FieldDefinition<T>[];
    onApply?: (values?: T) => void;
    onValuesChange?: OnFormUpdateHandler<T>;
    disabled?: boolean;
}

/**
 * Список полей, которые имеют значения, не совпадающие со значениями по умолчанию
 */
export type AppliedFields = Key[]

/**
 * Свойства модального окна с формой фильтра
 * @var isApplied есть ли поля, которые не показаны в инлайн-фильтре, но имеют значения,
 *      не совпадающие со значениями по умолчанию. (Если таковые имеются, то подкрашивается кнопка модального фиьтра).
 *      Имеет приоритет над appliedFields
 * @var appliedFields список полей, которые имеют значения, не совпадающие со значениями по умолчанию.
 *      Если в этом списке есть поля, которые не попали в инлайн фильтр, то подкрашивается кнопка модального фильтра.
 *      Не имеет приоритета над isApplied (@see AppliedFields)
 * @var buttonText текст надписи на модальной кнопке фильтра. Если не указано, то берется значение по умолчанию
 * @var width ширина модального окна в прикселах
 * @var labelColSpan ширина колонки с метками полей в модальном окне
 * @var displayOnLargeWindow показывать ли кнопку модльного фильтра в широком окне
 * @var onReset обработчик сброса филтра в модальном окне к значениями по уомлчанию
 */
export interface DialogFilterProps {
    isApplied?: boolean;
    appliedFields?: AppliedFields;
    buttonText?: string;
    width?: number;
    labelColSpan?: number;
    displayOnLargeWindow?: boolean;
    onReset?: () => void;
}