import React, { useState } from 'react'

import { Wrappers } from '@shared/components/wrappers'
import { PAGE_ROUTES } from '@shared/system/router'
import type { FilterType } from '@shared/types/context'
import { AggregateTypes } from '@shared/types/filters'
import { getCommentsTotalString } from '@shared/utils/comments'
import { filterPeriod } from '@shared/utils/defaultDatesHelper'
import { generateFilterParams } from '@shared/utils/filter'

import { CommentsPreviewContent } from './domain/PreviewContent'
import styles from './styles.module.scss'

type Props =
    Pick<
        FilterType,
    'clientSegment' | 'unitId' | 'tribeId' | 'productId' | 'triggerId' |
    'triggerType' | 'trendId' | 'versionSBOLId'
    > & {
        description?: string
        startDate?: string
        endDate?: string
    }
export const CommentsPreview: React.FC<Props> = ({
    clientSegment = null,
    versionSBOLId,
    unitId = null,
    tribeId = null,
    productId = null,
    triggerId = null,
    triggerType = null,
    trendId = null,
    description,
    startDate = filterPeriod[AggregateTypes.WEEK].startDateShort as string,
    endDate = filterPeriod[AggregateTypes.WEEK].endDate,
}) => {
    const [total, setTotal] = useState<number | null | undefined>(null)
    const [isFetching, setIsFetching] = useState<boolean | null>(false)

    return (
        <Wrappers.Preview
            title={'Прямая речь'}
            infoInTitle={getCommentsTotalString(isFetching ? null : total)}
            description={description}
            pathname={PAGE_ROUTES.COMMENTS}
            navigatePageSearchParams={
                generateFilterParams({
                    clientSegment,
                    versionSBOLId,
                    unitId,
                    tribeId,
                    productId,
                    triggerId,
                    triggerType,
                    trendId,
                    periodArray: [
                        startDate,
                        endDate,
                    ]
                })
            }
            watchAllButtonText={'Вся прямая речь'}
        >
            <div className={styles.commentsContent}>
                <CommentsPreviewContent
                    filter={{
                        clientSegment,
                        versionSBOLId,
                        unitId,
                        tribeId,
                        productId,
                        triggerId,
                        triggerType,
                        trendId,
                    }}
                    startDate={startDate}
                    endDate={endDate}
                    setIsFetching={setIsFetching}
                    setTotal={setTotal}
                />
            </div>
        </Wrappers.Preview>
    )
}
