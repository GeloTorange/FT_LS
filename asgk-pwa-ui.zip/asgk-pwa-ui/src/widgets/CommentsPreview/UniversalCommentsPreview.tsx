import React, { useState } from 'react'

import { SummarySampleTab } from '@widgets/SummariesPreview/SummarySampleTab'
import { TopicType } from '@shared/api/topics'
import { Wrappers } from '@shared/components/wrappers'
import { getCommentsTotalString } from '@shared/utils/comments'

import { TabsValues } from './const'
import { CSITab } from './domain/tabs/CSITab'
import { TabsController } from './domain/tabs/TabsController'

type Props = {
    productId?: number | string,
    trendId?: string,
    description?: string,
    painName?: string,
    noDataText?: string

}

export const UniversalCommentsPreview: React.FC<Props> = ({
    productId = null,
    trendId = null,
    description,
    painName,
    noDataText,
}) => {
    const [total, setTotal] = useState<number | null | undefined>(null)
    const [isFetching, setIsFetching] = useState<boolean | null>(false)
    const [activeTab, setActiveTab] = useState<TabsValues>(TabsValues.CONSULTATIONS)

    const changeTotal = (value: number | null | undefined) => {
        setTotal(value)
    }

    const changeIsFetching = (value: boolean | null) => {
        setIsFetching(value)
    }

    const getActiveTab = () => {
        const configTab = {
            [TabsValues.CSI]: <CSITab
                productId={productId as string}
                trendId={trendId as string}
                setTotal={changeTotal}
                setIsFetching={changeIsFetching}
                noDataText={noDataText}
            />,
            [TabsValues.CONSULTATIONS]: <SummarySampleTab
                appealType={TopicType.consultation}
                productId={productId as string}
                factorica={painName || ''}
                setTotal={changeTotal}
                setIsFetching={changeIsFetching}
            />,
            [TabsValues.APPEAL]: <SummarySampleTab
                appealType={TopicType.appeal}
                productId={productId as string}
                factorica={painName || ''}
                setTotal={changeTotal}
                setIsFetching={changeIsFetching}
            />
        }

        return (configTab[activeTab])
    }

    return (
        <Wrappers.Preview
            title={'Прямая речь'}
            infoInTitle={getCommentsTotalString(isFetching ? null : total)}
            description={description}
            rightHeaderComponent={<TabsController
                painName={painName}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
            />}
        >
            {getActiveTab()}
        </Wrappers.Preview>
    )
}
