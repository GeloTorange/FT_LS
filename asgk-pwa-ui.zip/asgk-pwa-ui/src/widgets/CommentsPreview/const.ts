export enum TabsValues {
    CSI = 'CSI',
    CONSULTATIONS = 'CONSULTATIONS',
    APPEAL = 'APPEAL'
}

export const tabsOptions = {
    [TabsValues.CSI]: 'CSI',
    [TabsValues.CONSULTATIONS]: 'Консультации',
    [TabsValues.APPEAL]: 'Жалобы',
}
