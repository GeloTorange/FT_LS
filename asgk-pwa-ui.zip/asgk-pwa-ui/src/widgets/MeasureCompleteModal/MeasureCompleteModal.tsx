import { Form } from 'antd'
import type { FC } from 'react'
import React from 'react'
import { useDispatch, useSelector } from 'react-redux'

import { getIsShowCompleteModal, changeVisibilityCompleteModal } from '@entities/measure'
import { useCompleteMeasureMutation } from '@shared/api/measures'
import { TextAreaForm } from '@shared/components/formInputs'
import { ModalFooterDefault, SystemDialog } from '@shared/components/SystemDialog'
import { TypographyTitle1 } from '@shared/components/typography'
import { useCheckHasErrors } from '@shared/hooks/useCheckHasErrors'

import styles from './styles.module.scss'


type FormValues = {
    resultDescription?: string
}
type Props = {
    measureId: string,
}
export const MeasureCompleteModal: FC<Props> = ({
    measureId,
}) => {
    const [form] = Form.useForm<FormValues>()
    const isOpen = useSelector(getIsShowCompleteModal)
    const dispatch = useDispatch()
    const allValues = Form.useWatch([], form)

    const hasErrors = useCheckHasErrors<FormValues>({ form, allValues })

    const [completeMeasure] = useCompleteMeasureMutation()

    const close = () => {
        form.resetFields()
        form.setFieldsValue({})
        dispatch(changeVisibilityCompleteModal())
    }

    const apply = () => {
        const { resultDescription } = allValues

        if (resultDescription) {
            completeMeasure({
                measureId,
                result: resultDescription.trim(),
            })
            close()
        }
    }

    return (
        <SystemDialog
            modalWidth={700}
            onClose={close}
            title={<TypographyTitle1
                strong
            >
                Завершение меры
            </TypographyTitle1>}
            open={isOpen}
            centered
            footer={
                <ModalFooterDefault
                    onCancel={close}
                    onApply={apply}
                    firstButtonLabel={'Отмена'}
                    secondButtonLabel={'Завершить меру'}
                    disableButton={hasErrors}
                    tooltipTitle={'Опишите результат'}
                    showTooltip={hasErrors}
                />
            }
        >
            <Form
                form={form}
                layout={'vertical'}
                requiredMark={false}
                className={styles.formWrapper}
            >
                <TextAreaForm
                    label={'Результат'}
                    name={'resultDescription'}
                    textAreaProps={{
                        size: 'large',
                        autoSize: { minRows: 4, maxRows: 4 },
                        placeholder: 'Опишите результат внедрения меры',
                        variant: 'filled',
                        maxLength: 500
                    }}
                />
            </Form>
        </SystemDialog>
    )
}
