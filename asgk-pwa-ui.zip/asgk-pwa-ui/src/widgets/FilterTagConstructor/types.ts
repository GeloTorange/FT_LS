import type { ReactNode } from 'react'

import type { PeriodRangeDatePickerProps } from '@shared/components/formInputs'
import type { FilterType } from '@shared/types/context'
import type { FilterFormData } from '@shared/types/filters'
import type { ParsedStructureValue } from '@shared/utils/forTreeStructure'


type ExtraFilterTagNameFields = 'appealType' | 'factorica'

export type FilterTagNameFields = keyof Pick<FilterFormData,
    | 'structure'
    | 'clientSegment'
    | 'versionSBOLId'
    | 'marks'
    | 'periodArray'
    | 'searchWord'
    | 'trendType'
    | 'trendId'
    | 'triggerType'
    | 'triggerId'
> | ExtraFilterTagNameFields

type DefaultPropsFields = {
    span?: number
    alwaysDisabled?: boolean
    isHideOnShort?: boolean
}

type ExtraPropsFields = {
    appealType?: DefaultPropsFields
    factorica?: DefaultPropsFields
}

// передаваемые пропсы в сеттингах для компонентов
export type PropsFields = {
    structure?: DefaultPropsFields,
    clientSegment?: DefaultPropsFields,
    versionSBOLId?: DefaultPropsFields,
    marks?: DefaultPropsFields,
    searchWord?: DefaultPropsFields,
    trendType?: DefaultPropsFields,
    trendId?: DefaultPropsFields,
    triggerType?: DefaultPropsFields,
    periodArray?: {
        selectionMode: PeriodRangeDatePickerProps['selectionMode']
    } & DefaultPropsFields,
    triggerId?: {
        isInTrends?: boolean
    } & DefaultPropsFields,
} & ExtraPropsFields

// передаваемые значения формы нужные для других полей
export type ValueFormTags = {
    parsedStructure: ParsedStructureValue
    trendId?: string | null
    triggerType?: string | null
    triggerId?: string | null
}

export type TagsFormValues = Partial<Pick<FilterFormData,
    FilterTagNameFields
>>

type FieldConfig = {
    render: (props: {
        disabled?: boolean,
        initialValues: FilterType,
        valueForm: ValueFormTags,
    }) => ReactNode
    span?: string | number
    isHideOnShort?: boolean
}

export type FieldListConfig = Record<FilterTagNameFields, FieldConfig>
