import dayjs from 'dayjs'
import { useContext, useMemo } from 'react'
import { isDesktop } from 'react-device-detect'
import { useParams } from 'react-router-dom'

import { useGetInitialTriggerType } from '@entities/filter'
import { TopicType } from '@shared/api/topics'
import { TrendTypes } from '@shared/api/trends'
import { useSearchParamsHook } from '@shared/hooks/useSearchParamsHook'
import { type FilterType } from '@shared/types/context'
import { UniversalFilterContext } from '@shared/utils/context'
import { filterPeriod } from '@shared/utils/defaultDatesHelper'
import { useIsShortWindowForFilter } from '@shared/utils/filter'
import { toObjTreeStructureValue, toStrTreeStructureValue } from '@shared/utils/forTreeStructure'
import { removeEmpty } from '@shared/utils/useful'


export const useFilterTagData = () => {
    const { getSearchParam } = useSearchParamsHook()
    const isShortWindow = useIsShortWindowForFilter()
    const { trendId: trendIdParam } = useParams()
    const isHideFilter = isShortWindow || !isDesktop

    const {
        filter: {
            structure,
            trendId,
            triggerType,
            triggerId,
        }
    } = useContext(UniversalFilterContext)

    const parsedStructure = useMemo(
        () =>
            removeEmpty({
                ...toObjTreeStructureValue(structure),
            }),
        [structure],
    )

    return {
        initialValues: {
            structure: toStrTreeStructureValue({
                unitId: getSearchParam('unitId'),
                tribeId: getSearchParam('tribeId'),
                productId: getSearchParam('productId'),
            }),
            clientSegment: getSearchParam('clientSegment'),
            versionSBOLId: getSearchParam('versionSBOLId'),
            marks: [],
            periodArray: [
                dayjs(getSearchParam('startDate') || filterPeriod.WEEK.startDateShort),
                dayjs(getSearchParam('endDate') || filterPeriod.WEEK.endDate),
            ],
            searchWord: getSearchParam('searchWord'),
            trendType: (getSearchParam('trendType') as TrendTypes | null) || TrendTypes.NEGATIVE,
            trendId: getSearchParam('trendId'),
            triggerType: useGetInitialTriggerType(),
            appealType: (getSearchParam('appealType') as TopicType | null) || TopicType.appeal
        } as FilterType,
        isHideFilter,
        isShortWindow,
        valueForm: {
            trendId: trendIdParam || trendId,
            parsedStructure,
            triggerType,
            triggerId,
        }
    }
}
