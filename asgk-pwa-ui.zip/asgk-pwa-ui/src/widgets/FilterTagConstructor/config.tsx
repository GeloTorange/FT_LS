import { Filters } from '@features/commonFilters'
import { useGetStructureByTreeSelectQuery, type TreeSelectType } from '@shared/api/products'
import { useGetAllSegmentsByFilterQuery } from '@shared/api/segments'
import { useGetAllTrendsByFilterQuery, useGetTrendTypeSelectOptionsQuery } from '@shared/api/trends'
import { useGetTriggersTypesForFilterQuery } from '@shared/api/triggers'
import { useGetAllFactoricaByFilterQuery, useGetAppealTypeQuery } from '@shared/api/universal'
import { useGetAllVersionsSBOLByFilterQuery } from '@shared/api/versionsSBOL'
import {
    SelectFilterInput,
    SelectMarks,
    SimpleInputForForm,
    TreeSelectForForm,
    PeriodRangeDatePicker,
} from '@shared/components/formInputs'
import { removeEmpty } from '@shared/utils/useful'

import type { FilterTagNameFields, PropsFields, FieldListConfig } from './types'

type GetSpanProps = {
    nameField: FilterTagNameFields,
    defaultSpan: number,
    propsFields?: PropsFields
}
export const getSpan = ({ nameField, defaultSpan, propsFields }: GetSpanProps): number =>
    propsFields?.[nameField]?.span || defaultSpan

interface FieldConfigProps {
    isHideFilter: boolean,
    propsFields?: PropsFields,
}

const hideOnShortHelper = (
    fieldKey: keyof PropsFields,
    propsFields?: PropsFields,
    defaultHideValue = true
) =>
    // Важно именно на undefined, так как может быть false
    propsFields?.[fieldKey]?.isHideOnShort !== undefined ?
        propsFields?.[fieldKey]?.isHideOnShort : defaultHideValue


export const getFieldConfigs = ({ isHideFilter, propsFields }: FieldConfigProps): FieldListConfig => ({
    structure: {
        span: isHideFilter ? 24 : getSpan({ propsFields, nameField: 'structure', defaultSpan: 3 }),
        isHideOnShort: hideOnShortHelper('structure', propsFields, false),
        render: ({ disabled, initialValues }) => (
            <TreeSelectForForm<TreeSelectType[]>
                disabled={disabled || propsFields?.structure?.alwaysDisabled}
                placeholder={'Структура'}
                name={'structure'}
                initialValue={initialValues.structure}
                isTagView
                useGetData={useGetStructureByTreeSelectQuery}
            />
        ),
    },
    clientSegment: {
        span: getSpan({ propsFields, nameField: 'clientSegment', defaultSpan: 3 }),
        isHideOnShort: hideOnShortHelper('clientSegment', propsFields),
        render: ({ disabled, initialValues }) => (
            <SelectFilterInput
                disabled={disabled || propsFields?.clientSegment?.alwaysDisabled}
                name={'clientSegment'}
                initialValue={initialValues.clientSegment}
                argForReq={{}}
                useGetData={useGetAllSegmentsByFilterQuery}
                placeholder={'Сегмент'}
                minWidthPopup={'200px'}
            />
        ),
    },
    trendType: {
        span: getSpan({ propsFields, nameField: 'trendType', defaultSpan: 3 }),
        isHideOnShort: hideOnShortHelper('trendType', propsFields),
        render: ({ disabled, initialValues }) => (
            <SelectFilterInput
                disabled={disabled || propsFields?.trendType?.alwaysDisabled}
                name={'trendType'}
                argForReq={{}}
                useGetData={useGetTrendTypeSelectOptionsQuery}
                initialValue={initialValues.trendType}
                placeholder={'Тип тренда'}
                minWidthPopup={'200px'}
            />
        ),
    },
    triggerType: {
        span: getSpan({ propsFields, nameField: 'triggerType', defaultSpan: 3 }),
        isHideOnShort: hideOnShortHelper('triggerType', propsFields),
        render: ({ disabled, valueForm, initialValues }) => (
            <SelectFilterInput
                disabled={disabled || propsFields?.triggerType?.alwaysDisabled}
                name={'triggerType'}
                argForReq={{ ...valueForm.parsedStructure, isRemoveFirstOptions: true }}
                useGetData={useGetTriggersTypesForFilterQuery}
                initialValue={initialValues.triggerType}
                placeholder={'Тип опроса'}
                minWidthPopup={'200px'}
            />
        ),
    },
    triggerId: {
        span: getSpan({ propsFields, nameField: 'triggerId', defaultSpan: 3 }),
        isHideOnShort: hideOnShortHelper('triggerId', propsFields),
        render: ({ valueForm, initialValues }) => (
            <Filters.TriggersSelect
                disabled={propsFields?.triggerId?.alwaysDisabled}
                isShowLabel={false}
                initialValue={initialValues.triggerId}
                argForReq={removeEmpty({
                    ...valueForm.parsedStructure,
                    triggerType: valueForm.triggerType,
                    // если isInTrends, то надо добавить параметры для запроса
                    ...(propsFields?.triggerId?.isInTrends && {
                        trendId: valueForm.trendId,
                        forTrends: true,
                    })
                })}
            />
        ),
    },
    versionSBOLId: {
        span: getSpan({ propsFields, nameField: 'versionSBOLId', defaultSpan: 3 }),
        isHideOnShort: hideOnShortHelper('versionSBOLId', propsFields),
        render: ({ disabled, initialValues }) => (
            <SelectFilterInput
                disabled={disabled || propsFields?.versionSBOLId?.alwaysDisabled}
                name={'versionSBOLId'}
                initialValue={initialValues.versionSBOLId}
                argForReq={{}}
                useGetData={useGetAllVersionsSBOLByFilterQuery}
                placeholder={'Версия СБОЛ'}
                minWidthPopup={'200px'}
                isOffSort
            />
        ),
    },
    marks: {
        span: getSpan({ propsFields, nameField: 'marks', defaultSpan: 4 }),
        isHideOnShort: hideOnShortHelper('marks', propsFields),
        render: ({ initialValues }) => (
            <SelectMarks
                name={'marks'}
                initialValue={initialValues.marks}
                placeholder={'Оценка'}
            />
        ),
    },
    trendId: {
        span: getSpan({ propsFields, nameField: 'trendId', defaultSpan: 3 }),
        isHideOnShort: hideOnShortHelper('trendId', propsFields),
        render: ({ disabled, initialValues, valueForm }) => (
            <SelectFilterInput
                name={'trendId'}
                initialValue={initialValues.trendId}
                argForReq={removeEmpty({
                    ...valueForm.parsedStructure
                })}
                disabled={disabled || propsFields?.trendId?.alwaysDisabled}
                useGetData={useGetAllTrendsByFilterQuery}
                placeholder={'Тренд'}
                minWidthPopup={'360px'}
            />
        ),
    },
    periodArray: {
        span: getSpan({ propsFields, nameField: 'periodArray', defaultSpan: 6 }),
        isHideOnShort: hideOnShortHelper('periodArray', propsFields),
        render: ({ initialValues }) => (
            <PeriodRangeDatePicker
                isOffLabel
                initialValue={initialValues.periodArray}
                {...(propsFields?.periodArray || {})}
            />
        ),
    },
    searchWord: {
        span: getSpan({ propsFields, nameField: 'searchWord', defaultSpan: 5 }),
        isHideOnShort: hideOnShortHelper('searchWord', propsFields),
        render: ({ initialValues }) => (
            <SimpleInputForForm
                isSearch
                name={'searchWord'}
                initialValue={initialValues.searchWord}
                placeholder={'Поиск по слову, фразе'}
            />
        ),
    },
    factorica: {
        span: getSpan({ propsFields, nameField: 'factorica', defaultSpan: 3 }),
        isHideOnShort: true,
        render: ({ disabled, initialValues }) => (
            <SelectFilterInput
                disabled={disabled}
                name={'factorica'}
                initialValue={initialValues.factorica}
                argForReq={{}}
                useGetData={useGetAllFactoricaByFilterQuery}
                placeholder={'Тематика'}
                minWidthPopup={'200px'}
            />
        ),
    },
    appealType: {
        span: isHideFilter ? 24 : getSpan({ propsFields, nameField: 'appealType', defaultSpan: 3 }),
        isHideOnShort: false,
        render: ({ disabled, initialValues }) => (
            <SelectFilterInput
                disabled={disabled}
                name={'appealType'}
                initialValue={initialValues.appealType}
                argForReq={{}}
                useGetData={ useGetAppealTypeQuery }
                placeholder={'Тип обращения'}
                minWidthPopup={'200px'}
                propsSelect={{
                    allowClear: false,
                }}
            />
        ),
    },
})
