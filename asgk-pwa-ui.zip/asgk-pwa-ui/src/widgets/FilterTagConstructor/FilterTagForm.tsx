import { Col } from 'antd'
import { type FC, memo } from 'react'

import type { FieldListConfig, FilterTagNameFields } from './types'
import { useFilterTagData } from './useFilterTagData'

type Props = {
    name: FilterTagNameFields,
    fieldsConfig: FieldListConfig
    disableFilterButton?: boolean
}

export const FilterTagForm: FC<Props> = memo(({ name, fieldsConfig, disableFilterButton }) => {
    const { initialValues, valueForm, isHideFilter } = useFilterTagData()

    // сделано так специально, чтобы управлять порядком отображения через fields
    const field = fieldsConfig[name]
    // Страхуемся если вдруг не нашли поле или скрываем на маленьком экране
    if (!field || field.isHideOnShort && isHideFilter) {
        return null
    }

    return (
        <Col span={field.span}>
            {
                field.render({
                    disabled: disableFilterButton,
                    initialValues,
                    valueForm
                })
            }
        </Col>
    )
})
