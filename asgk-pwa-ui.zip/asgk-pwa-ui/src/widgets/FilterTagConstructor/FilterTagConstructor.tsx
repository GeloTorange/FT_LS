import { Form, Row } from 'antd'
import clsx from 'clsx'
import { useEffect, useContext, useMemo } from 'react'
import { isDesktop } from 'react-device-detect'

import { UniversalFilterContext } from '@shared/utils/context'
import { linkedFilterRules, useApplyFiltersAfterForm } from '@shared/utils/filter'

import { getFieldConfigs } from './config'
import { FilterTagForm } from './FilterTagForm'
import styles from './styles.module.scss'
import type { PropsFields, FilterTagNameFields, TagsFormValues } from './types'
import { useFilterTagData } from './useFilterTagData'

type Props = {
    disableFilterButton?: boolean
    fields: FilterTagNameFields[]
    propsFields?: PropsFields
    // Если в МП нет кнопки фильтра и только один фильтр
    isOnlyOneFilter?: boolean
}

export const FilterTagConstructor = ({
    disableFilterButton = false,
    fields,
    propsFields,
    isOnlyOneFilter = false,
}: Props) => {
    const { filter } = useContext(UniversalFilterContext)
    const {
        // comment: нужно вырезать все что не относится к значениям формы
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        pageIndex,
        ...filterForm
    } = filter

    const [form] = Form.useForm<TagsFormValues>()
    const applyFiltersAfterForm = useApplyFiltersAfterForm()
    const { isHideFilter, isShortWindow } = useFilterTagData()

    useEffect(() => {
        // Синхронизация с фильтрами в модалке
        form.setFieldsValue({
            ...filterForm
        })
    }, [ form, filterForm ])

    const onChangeForm = (valuesRoot: TagsFormValues) => {
        const linkedFields = linkedFilterRules(valuesRoot)
        // В форме значение устанавливаем
        form.setFieldsValue(linkedFields)
        // В контексте и URL params значение устанавливаем
        applyFiltersAfterForm({
            values: {
                ...filter,
                ...linkedFields,
                ...valuesRoot,
            },
            isApply: true,
        })
    }

    const fieldsConfig = useMemo(
        () => getFieldConfigs({ isHideFilter, propsFields }),
        [isHideFilter, propsFields]
    )

    return (
        <Form
            disabled={disableFilterButton}
            className={clsx(
                styles.container,
                !isDesktop && styles.containerMb,
                // Когда маленький экран, но не МП
                // (иначе в структурном фильтре, на большом значении инпут вылетал за границы)
                isShortWindow && isDesktop && styles.containerShort,
                // Только в МП и если флаг isOnlyOneFilter=false
                !isOnlyOneFilter && !isDesktop && styles.indentForBtn
            )}
            form={form}
            onValuesChange={onChangeForm}
            colon={false}
            layout={'horizontal'}
            data-testid={'filter-tags-constructor'}
        >
            <Row gutter={[isOnlyOneFilter ? 0 : 8, 0]}>
                {fields.map((name) => (
                    <FilterTagForm
                        key={name}
                        name={name}
                        fieldsConfig={fieldsConfig}
                        disableFilterButton={disableFilterButton}
                    />
                ))}
            </Row>
        </Form>
    )
}
