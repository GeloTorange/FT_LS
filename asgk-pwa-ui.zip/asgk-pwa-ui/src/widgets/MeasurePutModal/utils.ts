import type { MeasurePutForm } from '@entities/measure'
import { checkIsAllFilled } from '@shared/utils/useful'

import type { MeasurePutFormNonNullable } from './types'

export const normalizedValues = (values: MeasurePutForm): MeasurePutFormNonNullable | null => {
    // comment: проверяем без link так как он не обязателен для ввода
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { link, ...requiredValues } = values

    if (checkIsAllFilled(requiredValues)) {
        return values as MeasurePutFormNonNullable
    }
    return null
}
