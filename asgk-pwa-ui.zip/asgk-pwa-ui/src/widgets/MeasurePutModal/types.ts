import type { Dayjs } from 'dayjs'


// Non-nullable почему-то не работает
export type MeasurePutFormNonNullable = {
    structure: string
    measureName: string
    measureDescription: string
    painIds: number[]
    reasonIds: number[]
    measureAudience: string
    measureRatio: number
    pshe: number
    deadlineDate: Dayjs
    effectMonths: number
    link: string
}
