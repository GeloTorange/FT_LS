import React, { type CSSProperties } from 'react'

import { Charts } from '@features/charts'
import { usePainPageData, useScoreColors } from '@entities/pain'
import { AKBInfo, useAKBInfo } from '@entities/reason'
import { Tags } from '@shared/components/tags'
import { Wrappers } from '@shared/components/wrappers'


import { ScoringPainSelect } from './domain/ScoringPainSelect'
import styles from './styles.module.scss'


const ContentPopover = () => (
    <div style={{ width: 276 }}>
        {'Показатель, который помогает определить, ' +
          'насколько важна выявленная боль. Чем выше скоринговый балл, тем важнее боль. ' +
          'Вычисляется как среднее между долей консультаций, жалоб и детракторов по боли.'}
    </div>
)

export const ScoringPain: React.FC = () => {
    const { painScore, chartData, isLoading, isShowDetractor } = usePainPageData()
    const { akb, isFetching } = useAKBInfo()

    const colorConfig = useScoreColors(painScore)

    return (
        <Wrappers.Preview
            height={'364px'}
            title={'Скоринг боли'}
            infoContent={ContentPopover}
            rightHeaderText={
                <ScoringPainSelect isLoading={isLoading} />
            }
        >
            <div
                style={{
                    // устанавливаем переменные для графика #apexchartspain-graph
                    '--LastColumnColorBody': colorConfig.body,
                    '--LastColumnColorLine': colorConfig.line
                } as unknown as CSSProperties}
                className={styles.container}
            >
                <Tags.Score value={painScore} isLoading={isLoading} />
                <AKBInfo akb={akb} isFetching={isFetching} />
                <Charts.Pain
                    isShowDetractor={isShowDetractor}
                    chartData={chartData}
                    isLoading={isLoading}
                    isBigView={!akb && !isFetching}
                />
            </div>
        </Wrappers.Preview>
    )
}

