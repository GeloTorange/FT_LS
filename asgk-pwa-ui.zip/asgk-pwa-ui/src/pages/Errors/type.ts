import type { ResultStatusType } from 'antd/lib/result'

export type ErrorInstance = {
    status?: ResultStatusType
    title: string
    subTitle?: string
    isOffToolbar?: boolean
    primaryButton: {
        href?: string
        text?: string
        action?: () => void
    }
    defaultButton?: {
        href?: string
        text?: string
        action?: () => void
    }
    textButton: {
        href?: string
        text?: string
        action?: () => void
    }
}

export type TErrors = Record<string | number, ErrorInstance>
