
import { onBackPage, onReloadPage } from '@shared/utils/useful'

import type { TErrors } from './type'

const checkCertificateHandler = () => window.open('https://pking.sberbank.ru/', '_blank')
const technicalSupportHandler = () => { window.location.assign('mailto:info_voiceofthecustomer@sberbank.ru') }

export const errorTemplates: TErrors = {
    // 401, 403, userInfo
    401: {
        title: 'Нет доступа',
        subTitle: 'Проверьте, установлены ли нужные \n сертификаты на вашем устройстве',
        primaryButton: {
            text:'Проверить сертификаты',
            action: checkCertificateHandler,
        },
        defaultButton: {
            text: 'Обновить страницу',
            action: onBackPage,
        },
        textButton: {
            action: technicalSupportHandler,
        }
    },
    // 404
    404: {
        title: 'Страница не найдена',
        subTitle: 'Похоже, мы не можем найти нужную страницу',
        primaryButton: {
            href: '/',
            text: 'На главную',
        },
        textButton: {
            action: technicalSupportHandler,
        }
    },
    // 500, 502
    500: {
        title: 'Технические неполадки',
        subTitle: 'Это временно, скоро всё поправим',
        primaryButton: {
            text: 'Обновить страницу',
            action: onReloadPage,
        },
        textButton: {
            action: technicalSupportHandler,
        }
    },
    // refreshToken
    refreshToken: {
        title: 'Истекло время сессии',
        subTitle: 'Вы отсутствовали некоторое время, \nнеобходимо обновить страницу',
        primaryButton: {
            text: 'Обновить страницу',
            action: onReloadPage,
        },
        textButton: {
            action: technicalSupportHandler,
        }
    },
    // network, system, остальные серверные ошибки
    network: {
        title: 'Что-то пошло не так',
        subTitle: 'Пожалуйста, обновите страницу\nили попробуйте позже',
        primaryButton: {
            text: 'Обновить страницу',
            action: onReloadPage,
        },
        textButton: {
            action:  technicalSupportHandler,
        }
    },
    // errorBoundary
    errorBoundary: {
        title: 'Что-то пошло не так',
        subTitle: 'Это временно, скоро всё поправим',
        primaryButton: {
            href: '/',
            text: 'На главную',
        },
        textButton: {
            action: technicalSupportHandler,
        }
    },
}
