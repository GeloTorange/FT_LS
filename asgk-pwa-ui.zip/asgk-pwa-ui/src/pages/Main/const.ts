import { MainTabsValues } from '@shared/types/main'


export const tabsOptions = {
    [MainTabsValues.MAIN]: 'Главная',
    [MainTabsValues.CSI]: 'CSI',
    [MainTabsValues.APPEALS]: 'Жалобы',
    [MainTabsValues.CONSULTATIONS]: 'Консультации',
}
