import { Col, Row } from 'antd'
import dayjs from 'dayjs'
import React, { useEffect, useState } from 'react'
import { isDesktop } from 'react-device-detect'
import { useSearchParams } from 'react-router-dom'

import { InsightHubButton } from '@features/InsightHub'
import { analytics } from '@shared/system/analytics'
import type { FilterType } from '@shared/types/context'
import { AggregateTypes } from '@shared/types/filters'
import { MainTabsValues } from '@shared/types/main'
import { UniversalFilterContext } from '@shared/utils/context'
import { filterPeriod } from '@shared/utils/defaultDatesHelper'

import { CSITab } from './domain/tabs/CSITab'
import { MainTab } from './domain/tabs/MainTab'
import { TabController } from './domain/tabs/TabController'
import { Title } from './domain/Title'


// TODO: сделать для карточек на главной единую обертку и у Card есть баг с border

// Компонент главной страницы
export const MainPage = () => {
    const [searchParams] = useSearchParams()
    const getSearchParam = (key: string) => searchParams.get(key)

    const currentTab = searchParams.get('tab') as MainTabsValues
    const [activeTab, setActiveTab] = useState<MainTabsValues>(
        MainTabsValues[currentTab] || MainTabsValues.MAIN,
    )

    const [filter, setFilter] = useState<FilterType>({
        unitId: getSearchParam('unitId') || null,
        tribeId: getSearchParam('tribeId') || null,
        productId: getSearchParam('productId') || null,
        // Эти даты используются в виджетах (например карточке коммента для ссылки поделиться).
        // Поэтому важно, чтобы везде за 4 недели были. Кроме исключений, там точечно передавать.
        periodArray: [
            dayjs(filterPeriod[AggregateTypes.DAY].startDate),
            dayjs(filterPeriod[AggregateTypes.DAY].endDate),
        ]
    })

    useEffect(() => {
        setActiveTab(MainTabsValues[currentTab] || MainTabsValues.MAIN)
    }, [currentTab])

    useEffect(() => {
        void analytics.event({
            eventAction: 'Главная/Открытие экрана',
        })
    }, [])


    return (
        <UniversalFilterContext.Provider value={{ filter, setFilter }}>
            <Row
                gutter={isDesktop ? [16, 16] : [0, 16]}
            >
                <Col span={24}>
                    <Title />
                </Col>
                <Col span={24}>
                    <TabController activeTab={activeTab} setActiveTab={setActiveTab} />
                </Col>
                {
                    activeTab === MainTabsValues.MAIN
                        ? <MainTab />
                        : <CSITab />
                }
            </Row>
            <InsightHubButton />
        </UniversalFilterContext.Provider>
    )
}
