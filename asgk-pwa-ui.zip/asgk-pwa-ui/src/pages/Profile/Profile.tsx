import { Row, Col, Card, Space, Tag, Switch } from 'antd'
import React from 'react'
import { isDesktop } from 'react-device-detect'
import { useDispatch, useSelector } from 'react-redux'

import { getIsDarkTheme, manualChangeTheme } from '@entities/appTheme'
import { getUserInfo } from '@entities/userInfo'
import {
    TypographyBody,
    TypographyCaption,
    TypographyH1,
} from '@shared/components/typography'
import { Roles } from '@shared/system/router'
import { themeUtils } from '@shared/system/theme'
import type { SudirUser } from '@shared/types/user'


// Компонент профиля
export const Profile = () => {
    const dispatch = useDispatch()
    const user = useSelector(getUserInfo)
    const isDark = useSelector(getIsDarkTheme)

    const onChangeTheme = () => {
        dispatch(manualChangeTheme(!isDark))
        themeUtils.toggle()
    }

    const getShortName = (userLocal: SudirUser) =>
        `${
            userLocal.name.split(' ')[0] || ''
        } ${userLocal.name.split(' ')[1]?.[0] || ''}. ${userLocal.name.split(' ')[2]?.[0] || ''}.`

    return (
        user && (
            <Row gutter={[0, 16]}>
                <Col span={24}>
                    <TypographyH1
                        style={{
                            margin: `48px ${isDesktop ? '20px' : '16px'} 20px`,
                        }}
                    >
                        {getShortName(user)}
                    </TypographyH1>
                </Col>
                <Col span={24}>
                    <Card>
                        <Space wrap>
                            <TypographyBody>{'Роли: '}</TypographyBody>
                            {
                                user.roles
                                    .filter((role) => Object.values(Roles).includes(role))
                                    .map((role) => (
                                        <Tag key={role}>
                                            <TypographyCaption>{role}</TypographyCaption>
                                        </Tag>
                                    ))
                            }
                        </Space>
                    </Card>
                </Col>
                <Col span={24}>
                    <Card>
                        <TypographyBody style={{ marginRight: '10px' }}>
                            Тёмная тема
                        </TypographyBody>
                        <Switch defaultChecked={isDark} onChange={onChangeTheme} />
                    </Card>
                </Col>
            </Row>
        )
    )
}
