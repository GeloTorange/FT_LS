/// <reference types="vite/client" />
// Нужно для корректной работы TypeScript
