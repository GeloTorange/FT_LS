import { Flex } from 'antd'
import React, { memo } from 'react'
import Chart from 'react-apexcharts'

import type { AnswerDetailsData } from '@shared/api/triggers'
import { BadgeGraph } from '@shared/components/BadgeGraph'
import { useGetCSSVar } from '@shared/styles'
import { AggregateTypes } from '@shared/types/filters'

import styles from './styles.module.scss'
import { getOptions } from './utils/getOptions'
import { getSeriesPnd } from './utils/getSeries'
import { enrichmentPndData } from './utils/helpers'


type PndGraphProps = {
    graphData: AnswerDetailsData[],
    aggregateType?: AggregateTypes,
}
export const PndGraph: React.FC<PndGraphProps> = memo(({ graphData, aggregateType = AggregateTypes.MONTH }) => {
    const graphDataEnrichment = enrichmentPndData(graphData)
    // поиск максимального totalCount в данных графика
    const maxValue = Math.max(...graphData.map((item) => item.totalCount))
    // строка разделитель равная 1%
    const stripeHeight = maxValue * 0.01

    const cssVars = {
        redBody: useGetCSSVar('--BodyRed'),
        redLine: useGetCSSVar('--LineRed'),
        yellowBody: useGetCSSVar('--BodyYellow'),
        yellowLine: useGetCSSVar('--LineYellow'),
        greenBody: useGetCSSVar('--BodyGreen'),
        greenLine: useGetCSSVar('--LineGreen'),
        gray: useGetCSSVar('--TextSecondary'),
    }

    const chartLength = aggregateType === AggregateTypes.QUARTER ? 4 : 6

    return (
        <>
            <div
                className={styles.graphWrapper}
            >
                <div style={{
                    width: graphData.length > chartLength ? `${(graphData.length / chartLength) * 100}%` : '100%',
                }}>
                    <Chart
                        options={getOptions({
                            aggregateType,
                            maxValue,
                            graphDataEnrichment,
                            stripeHeight,
                            cssVars
                        })}
                        series={getSeriesPnd({
                            graphData,
                            stripeHeight,
                            cssVars,
                        })}
                        type={'bar'}
                        height={300}
                        width={'100%'}
                    />
                </div>
            </div>
            <Flex>
                <BadgeGraph
                    isFirst
                    color={cssVars.greenLine}
                    text={'Промоутеры'}
                />
                <BadgeGraph
                    color={cssVars.yellowLine}
                    text={'Нейтралы'}
                />
                <BadgeGraph
                    color={cssVars.redLine}
                    text={'Детракторы'}
                />
            </Flex>
        </>
    )
})
