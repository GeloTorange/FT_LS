import type { AnswerDetailsData } from '@shared/api/triggers'

export type PndEnrichment = AnswerDetailsData & {
    promoutersIncr: number | null,
    detractorsIncr: number | null,
    neutralsIncr: number | null,

    detractorsPercent: number,
    neutralsPercent: number,
    promoutersPercent: number,
}

export type PndCssVars = {
    redBody: string,
    redLine: string,
    yellowBody: string,
    yellowLine: string,
    greenBody: string,
    greenLine: string,
    gray: string,
}
