import { AnswersGraph } from './AnswersGraph'
import { MainCSIGraphic } from './MainCSIGraphic'
import { PainGraph } from './PainGraph'
import { PndGraph } from './PndGraph'
import { Sparkline } from './Sparkline'
import { TopicsKpiGraph } from './TopicsKpiGraph'
import { TrendGraph } from './TrendGraph'

export const Charts = {
    Answers: AnswersGraph,
    TrendsInfo: TrendGraph,
    Pnd: PndGraph,
    Sparkline,
    MainCSI: MainCSIGraphic,
    Pain: PainGraph,
    TopicsKpiGraph
}
