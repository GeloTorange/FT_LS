import { useMemo } from 'react'

import { numShort } from '@shared/utils/formatting'
import { formatedDate } from '@shared/utils/useful'

import type { PainGraphProps } from './PainGraph'
import { normalizeChartSeries } from './utils'


export const usePainGraphData = ({
    chartData, isShowDetractor
}: Pick<PainGraphProps, 'chartData' | 'isShowDetractor'>) => {
    const calculations = useMemo(() => {
        const scoreLocal = []
        const labelsLocal = []
        const tooltipDataLocal = []
        const localPlotDataLabels = []

        if (chartData?.length) {
            for (const month of chartData ){
                scoreLocal.push(month.score)
                localPlotDataLabels.push(`${month.score} %`)
                labelsLocal.push(formatedDate(month.date, 'MMMM'))
                tooltipDataLocal.push({
                    date: formatedDate(month.date, 'MMMM YYYY'),
                    consultationTotal: numShort(month.consultationTotal),
                    appealTotal: numShort(month.appealTotal),
                    detractorTotal: isShowDetractor && month.detractorTotal ?
                        `${month.detractorTotal}%` : '',
                    score: month.score,
                })
            }
        }

        return {
            score: scoreLocal,
            labels: labelsLocal,
            tooltipData: tooltipDataLocal,
            plotDataLabels: localPlotDataLabels
        }
    }, [chartData])


    return {
        series: [{
            name: 'painScore',
            type: 'bar',
            data: normalizeChartSeries(calculations.score),
        }],
        maxValue: Math.max(...calculations.score),
        categories: calculations.labels,
        plotDataLabels: calculations.plotDataLabels,
        tooltipData: calculations.tooltipData
    }
}

export type PainGraphDataType = ReturnType<typeof usePainGraphData>
