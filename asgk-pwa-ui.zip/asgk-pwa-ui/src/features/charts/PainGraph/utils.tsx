import clsx from 'clsx'

import { getColorNameFromScore } from '@entities/pain'
import { TypographyBody } from '@shared/components/typography'
import { helperStyles } from '@shared/styles'
import type { TooltipOptions } from '@shared/types/apexchart'
import { toHtml } from '@shared/utils/html'

import type { PainGraphDataType } from './usePainGraphData'


const colorCSSConfig = {
    green: '--LineGreen',
    yellow: '--LineYellow',
    red: '--LineRed',
}

export const getTooltip = (options: TooltipOptions, dateLabel: PainGraphDataType['tooltipData'] ) => {
    const { dataPointIndex: index } = options
    const value = dateLabel[index]
    const colorFromScore = getColorNameFromScore(Number(value.score))
    const color = colorCSSConfig[colorFromScore]

    return toHtml(
        <div className={clsx(helperStyles.tooltip, helperStyles.tooltipWrapperThin)}>
            <TypographyBody
                className={helperStyles.tooltipSecondaryColor}
                fontWeight={'500'}
            >
                {value.date}
            </TypographyBody>
            <TypographyBody
                className={helperStyles.tooltipPrimaryColorColor}
                fontWeight={'600'}
            >
                {'Скоринг: '}<span style={{ color: `var(${color})` }}>{`${value.score}%`}</span>
            </TypographyBody>
            <TypographyBody className={helperStyles.tooltipPrimaryColor}>
                {`Консультации: ${value.consultationTotal}`}
            </TypographyBody>
            <TypographyBody className={helperStyles.tooltipPrimaryColor}>
                {`Жалобы: ${value.appealTotal}`}
            </TypographyBody>
            { value.detractorTotal &&
                <TypographyBody className={helperStyles.tooltipPrimaryColor}>
                    {`Детракторы: ${value.detractorTotal}`}
                </TypographyBody>
            }
        </div>
    )
}

export const normalizeChartSeries = (series: number[]): number[] => {
    const max = Math.max(...series)

    return series.map((val) => {
        if (val === 0) {return val}

        /* Нормализированое значение для колонки - 10% от максимальной*/
        return Math.max(max * 0.1, val)
    })
}

