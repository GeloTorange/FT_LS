import type { ApexOptions } from 'apexcharts'
import React, { type FC } from 'react'
import Chart from 'react-apexcharts'
import { isDesktop } from 'react-device-detect'

import type { PainScoringChart } from '@shared/api/pains'
import { Loaders } from '@shared/components/loaders'
import { useGetCSSVar } from '@shared/styles'
import type { TooltipOptions } from '@shared/types/apexchart'

import { usePainGraphData } from './usePainGraphData'
import { getTooltip } from './utils'

import './pain-chart.scss'


export type PainGraphProps = {
    chartData: PainScoringChart[]
    isLoading: boolean
    isBigView: boolean
    isShowDetractor: boolean
}
export const PainGraph: FC<PainGraphProps> = ({ chartData, isLoading, isBigView, isShowDetractor }) => {
    const { series, categories, tooltipData, maxValue, plotDataLabels }
      = usePainGraphData({ chartData, isShowDetractor })
    const fontFamily = useGetCSSVar('--fontFamilyText')
    const textColor = useGetCSSVar('--TextSecondary')
    const columnColor = useGetCSSVar('--BodyGray')

    const options: ApexOptions = {
        chart: {
            type: 'bar',
            id: 'pain-graph',
            fontFamily,
            foreColor: textColor,
            zoom: {
                enabled: false,
            },
            toolbar: {
                show: false,
            },
            animations: { enabled: false },
        },
        plotOptions: {
            bar: {
                horizontal: false,
                borderRadius: 6,
                distributed: false,
                dataLabels: { position: 'top' }
            },
            area: {
                fillTo: 'end',
            },
        },
        dataLabels: {
            enabled: true,
            formatter:  (val: number, { dataPointIndex }:
            { dataPointIndex: number }): string => plotDataLabels[dataPointIndex]
            ,
            style: {
                fontSize: '12px',
                fontFamily,
                fontWeight: 600,
                colors: [textColor],
            },
        },
        stroke: { show: false },
        xaxis: {
            categories,
            axisBorder: { show: false },
            crosshairs: { show: true },
            axisTicks: { show: false },
            tooltip: { enabled: false },
            labels: {
                style: {
                    fontSize: '12px',
                    fontFamily,
                    fontWeight: 600,
                    colors: [textColor],
                },
            },
        },
        yaxis: {
            show: false,
            min: 0,
            max: maxValue
        },
        tooltip: {
            enabled: true,
            shared: true,
            intersect: false,
            fillSeriesColor: false,
            x: {
                show: false,
            },
            marker: {
                show: false,
            },
            custom: (optionsTooltip: TooltipOptions) =>
                getTooltip(optionsTooltip, tooltipData),
        },
        grid: {
            show: false,
            padding: {
                left: isDesktop ? -10 : 0,
                right: isDesktop ? -33 : -30,
                top: isDesktop ? 0 : -20,
                bottom: -10,
            },
        },
        legend: { show: false },
        colors: [columnColor],
        fill: {
            type: 'solid',
        },
        states: {
            hover: {
                filter: {
                    type: 'none',
                },
            },
            active: {
                filter: {
                    type: 'none',
                },
            },
        },
    }

    if (isLoading) {
        return <Loaders.Row count={1} height={'208px'} marginTop={'16px'} marginBottom={'0px'}/>
    }

    return (
        <Chart
            style={{ marginTop: '16px' }}
            options={options}
            series={series}
            type={'bar'}
            height={isBigView ? 214 : 188}
        />
    )
}

