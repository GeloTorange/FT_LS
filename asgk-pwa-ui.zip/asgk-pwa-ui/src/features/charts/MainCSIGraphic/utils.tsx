import clsx from 'clsx'

import { bodyTypography } from '@shared/components/typography/Body'
import { helperStyles } from '@shared/styles'
import { toHtml } from '@shared/utils/html'
import { formatedDate } from '@shared/utils/useful'

export type MainCSITooltipData = {
    // supposedCSI: number[],
    actualCSI: number[],
    graphLabels: string[],
}

export const getMainCSITooltip = (
    tooltipData: MainCSITooltipData,
    dataPointIndex: number,
) => {
    const {
        // supposedCSI,
        actualCSI,
        graphLabels
    } = tooltipData

    const dataLabel = formatedDate(graphLabels[dataPointIndex], 'MMMM YYYY')
    // const supposedCSIPoint = supposedCSI[dataPointIndex]
    const actualCSIPoint = actualCSI[dataPointIndex]


    return toHtml(
        <div className={clsx(helperStyles.tooltip, bodyTypography, helperStyles.tooltipWrapper)}>
            <p className={helperStyles.tooltipTitle}>{dataLabel}</p>
            <div className={helperStyles.tooltipValueContainer}>
                <p>{`Факт: ${actualCSIPoint === null ? '—' : actualCSIPoint}`}</p>
                {/* <div className={clsx(helperStyles.tooltipCircleBase, helperStyles.csiLineGreenColor)} />*/}
            </div>
            {/* <div className={helperStyles.tooltipValueContainer}>*/}
            {/*    <p>План:</p>*/}
            {/*    <div className={clsx(helperStyles.stickDashed, helperStyles.csiLineGreenColor)} />*/}
            {/*    <p>{supposedCSIPoint}</p>*/}
            {/* </div>*/}
        </div>
    )
}

export function calculateStepSize (min: number, max: number) {
    const range = max - min
    const rawStep = range / 4

    return Math.max(0.01, parseFloat(rawStep.toFixed(2)))
}

export function calculateYAxisParams (arr1: number[], arr2: number[]) {
    const combined = [...arr1, ...arr2].filter(val => val !== null && val !== undefined)
    if (combined.length === 0) {
        return { min: 0.0, max: 4.0, stepSize: 1.00 }
    }

    const min = Math.min(...combined)
    // Ограничение максимума 5
    const max = Math.min(Math.max(...combined), 5)

    const stepSize = calculateStepSize(min, max)

    let adjustedMin = parseFloat((min - stepSize).toFixed(2))
    let adjustedMax = parseFloat((max + stepSize).toFixed(2))

    adjustedMin = Math.max(0, adjustedMin)

    adjustedMax = Math.min(5, adjustedMax)

    return {
        min: adjustedMin,
        max: adjustedMax,
        stepSize,
    }
}
