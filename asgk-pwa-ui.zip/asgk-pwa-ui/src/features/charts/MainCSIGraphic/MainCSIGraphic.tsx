import { Form } from 'antd'
import dayjs from 'dayjs'
import React, { type FC, type ReactNode, useContext } from 'react'
import { isDesktop } from 'react-device-detect'

import { useGetTriggerGraphDataQuery, } from '@shared/api/triggers'
import { NoData } from '@shared/components/NoData'
import { CSIOrderTypes, OrderDirections } from '@shared/types/context'
import { AggregateTypes } from '@shared/types/filters'
import { UniversalFilterContext } from '@shared/utils/context'
import { DATE_FORMAT, filterPeriod } from '@shared/utils/defaultDatesHelper'

import styles from './styles.module.scss'
import { CSIGraphicFooter } from './ui/CSIGraphicFoooter'
import { CSIGraphicHeader } from './ui/CSIGraphicHeader'
import { MainCSIApexChart } from './ui/MainCSIApexChart'

type Props = {
    filterComponent: ReactNode,
}

// TODO: используется в новой главной, ждём интеграцию с бэком: данные для графика, выбор селектов сверху, оценка CSI
export const MainCSIGraphic: FC<Props> = ({
    filterComponent
}) => {
    const { filter } = useContext(UniversalFilterContext)
    const [form] = Form.useForm<{ triggerId: string }>()

    const triggerIdWatch = Form.useWatch('triggerId', form)
    const hasStructure = filter.unitId || filter.tribeId || filter.productId

    const getTriggerId = () => {
        if (triggerIdWatch) {
            return triggerIdWatch ? Number(triggerIdWatch) : null
        }

        return hasStructure ? null : 1007
    }
    const triggerId = getTriggerId()

    const { data } = useGetTriggerGraphDataQuery({
        filter: {
            triggerId,
        },
        period: {
            startDate: dayjs(filterPeriod[AggregateTypes.MONTH].startDate).format(DATE_FORMAT.BACKEND),
            endDate: dayjs(filterPeriod[AggregateTypes.MONTH].endDate).format(DATE_FORMAT.BACKEND),
        },
        aggregateType: AggregateTypes.MONTH,
        orderType: CSIOrderTypes.CSI,
        orderDirection: OrderDirections.ASC,
        favoritesFirst: false,
        page: {
            pageIndex: 1,
            pageSize: 1,
        },
    })

    return (
        <div className={styles.mainContainer}>
            <Form
                form={form}
                name={'mainCSIGraphicForm'}
            >
                <CSIGraphicHeader
                    csi={data?.[data?.length - 1]?.csi || 0}
                    filter={filterComponent}
                />
                {/* TODO: Пока используем useGetTriggerGraphDataQuery.
                        Суть в том, что если triggerId нет, то бэк присылает статистику по всем существующим опросам.
                        А на фронте это не нужно показывать
                */}
                {data?.length && triggerId ?
                    <MainCSIApexChart data={data} /> :
                    <NoData className={isDesktop ? styles.noData : styles.noDataMob}/>
                }
                <CSIGraphicFooter/>
            </Form>
        </div>
    )
}
