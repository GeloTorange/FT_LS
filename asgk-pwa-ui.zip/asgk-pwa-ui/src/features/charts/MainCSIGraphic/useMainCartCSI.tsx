import { useMemo } from 'react'
import { isDesktop } from 'react-device-detect'

import type { StatisticData } from '@shared/types/api'

import { calculateYAxisParams } from './utils'

type Props = {
    graphData: StatisticData[];
}

export const useAnswerGraphConfiguration = ({ graphData }: Props) => {
    const {
        actualCSI,
        labels,
    } = useMemo(() => {
        const graphLabelsLocal = []
        const graphCsiDataLocal = []
        // const graphSupposedDataLocal = []

        for (const curElem of graphData) {
            const { date, csi } = curElem
            graphLabelsLocal.push(date)
            graphCsiDataLocal.push(csi)
        }

        return {
            labels: graphLabelsLocal,
            actualCSI: graphCsiDataLocal,
        }

    }, [graphData])

    const tooltipData = {
        actualCSI,
        graphLabels: labels,
    }

    const chartHeight = isDesktop ? 445 : 224

    const yAxisParams = calculateYAxisParams([], actualCSI)

    return {
        // supposedCSIGraphData: supposedCSI,
        actualCSIGraphData: actualCSI,
        graphLabels: labels,
        tooltipData,
        yAxisParams,
        chartHeight
    }
}
