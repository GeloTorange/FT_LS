import type { ApexOptions } from 'apexcharts'
import clsx from 'clsx'
import { type ReactNode } from 'react'
import React, { useMemo } from 'react'
import Graph from 'react-apexcharts'

import { bodyTypography } from '@shared/components/typography/Body'
import type { TooltipOptions } from '@shared/types/apexchart'
import { toHtml } from '@shared/utils/html'
import { typedMemo } from '@shared/utils/useful'

import { helperStyles, useGetCSSVar } from '../../../shared/styles'

import styles from './styles.module.scss'
import '../../../shared/styles/sparkline.css'


type SparklineData<T> = Record<keyof T, string | number | null>

interface SparklineProps<T extends SparklineData<T>, > {
    data: T[];
    yField: keyof T;
    tooltip?: (item: T) => ReactNode
    inverted?: boolean;
    width?: string | number;
    height?: string | number;
    chardId: string
}

export const Sparkline = typedMemo(<T extends SparklineData<T>,>(
    { data, yField, tooltip, inverted, width = 52, height = 32, chardId }: SparklineProps<T>
) => {
    const fontFamily = useGetCSSVar('--fontFamilyText')
    const foreColor = useGetCSSVar('--TextSecondary')
    const bgColor = useGetCSSVar('--Background1')
    const redLine = useGetCSSVar('--LineRed')
    const greenLine = useGetCSSVar('--LineGreen')
    const redBg = useGetCSSVar('--BodyRed2')
    const greenBg = useGetCSSVar('--BodyGreen2')

    const series = [{ data: data.map(item => (item[yField] as number)) }]

    const options = useMemo(() => {
        // логика тренда определяется разницей между последней и предпоследней точкой
        const isUpwardTrend = data.length >= 2 && (data[data.length - 1][yField] > data[data.length - 2][yField])
        const strokeColors = (isUpwardTrend && inverted) || (!isUpwardTrend && !inverted) ? redLine : greenLine
        const mbgColor = (isUpwardTrend && inverted) || (!isUpwardTrend && !inverted) ? redBg : greenBg

        return {
            chart: {
                id: `${chardId}—sparkline}`,
                fontFamily,
                foreColor,
                background: 'transparent',
                sparkline: { enabled: true },
                toolbar: {
                    show: false,
                },
                zoom: {
                    enabled: false,
                },
            },
            xaxis: {
                crosshairs: { show: false },
                labels: { show: false },
                axisTicks: { show: false },
                axisBorder: { show: false },
                // всплывающий тултип на нижней границе оси X categories
                tooltip: { enabled: false },
                animations: {
                    enabled: false,
                    easing: 'linear',
                    dynamicAnimation: {
                        speed: 1000,
                    }
                }
            },
            yaxis: {
                show: true,
                showForNullSeries: true,
                stepSize: 2,
                // всплывающий пунктир тултипа на границе Y при наведении на markers
                tooltip: {
                    enabled: false,
                },
                min: 0,
                max: Math.max(...data.map(item => (item[yField] as number))) + 0.5,
                labels: { show: false },
            },
            tooltip: {
                fixed: {
                    enabled: true,
                    position: 'bottomLeft',
                    offsetX: -48,
                    offsetY: -16,
                },
                enabled: !!tooltip,
                custom: ({ dataPointIndex }: TooltipOptions) => tooltip ? toHtml(
                    <div className={clsx(helperStyles.tooltip, bodyTypography, styles.wrapper)}>
                        {tooltip(data[dataPointIndex])}
                    </div>
                ) : null,
            },
            stroke: {
                show: true,
                curve: 'straight',
                colors: [strokeColors],
                width: 1.5,
            },
            markers: {
                shape: 'circle',
                size: 0,
                colors: bgColor,
                strokeColors,
                strokeWidth: 2,
                hover: { size: 1 },
            },
            fill: {
                type: 'solid',
                colors: [mbgColor],
            },
            grid: {
                show: false,
                padding: {
                    top: 3,
                    right: 5,
                    bottom: 3,
                    left: 1
                }
            }
        } as ApexOptions
    }, [
        data, yField, inverted, redLine, greenLine, redBg, greenBg, chardId, fontFamily, foreColor, tooltip, bgColor
    ])

    return <Graph type={'area'} series={series} options={options} width={width} height={height} />
})
