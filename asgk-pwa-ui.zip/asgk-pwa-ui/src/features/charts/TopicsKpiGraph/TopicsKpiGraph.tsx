import type { FC } from 'react'
import { useMemo } from 'react'
import Graph from 'react-apexcharts'

import type { TopicType } from '@shared/api/topics'

import type { KpiData } from './types'
import { useGraphOptions } from './useGraphOptions'

export interface TopicsKpiGraphProps {
    kpiData: KpiData[],
    type: TopicType,
    height?: string | number,
}

export const TopicsKpiGraph: FC<TopicsKpiGraphProps> = ({ kpiData, type, height }) => {
    const options = useGraphOptions(kpiData, type)
    const style = useMemo(() => ({ height }), [height])

    // выстоа устанавливается через div-обертку, чтобы пердотвратить установку min-height от apexcharts
    return (
        <div style={style}>
            <Graph {...options} height={'100%'} type={'bar'} />
        </div>
    )
}
