import clsx from 'clsx'
import type { FC } from 'react'

import { bodyTypography } from '@shared/components/typography/Body'
import { helperStyles } from '@shared/styles'
import { numShort } from '@shared/utils/formatting'

export interface TooltipProps {
    period: string;
    plan: number;
    fact: number;
}

export const Tooltip: FC<TooltipProps> = ({ period, plan , fact }) => (
    <div className={clsx(helperStyles.tooltip, bodyTypography, helperStyles.tooltipWrapper)}>
        <div className={helperStyles.tooltipSecondaryColor}>{period}</div>
        <div>План: {numShort(plan)}</div>
        <div>Факт: {numShort(fact)}</div>
    </div>

)