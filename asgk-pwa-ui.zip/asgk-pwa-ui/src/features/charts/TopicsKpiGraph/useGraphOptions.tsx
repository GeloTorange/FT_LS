import type { ApexOptions } from 'apexcharts'
import dayjs from 'dayjs'
import { useMemo } from 'react'

import { TopicType } from '@shared/api/topics'
import { useGetCSSVar } from '@shared/styles'
import { AggregateTypes } from '@shared/types/filters'
import { numShortWithoutZero } from '@shared/utils/formatting'

import { getDateLabels } from '../utils'

import type { KpiData } from './types'
import { customTooltipFactory } from './utils'

export type UseGraphOptionsHook = (kpiData: KpiData[], type: TopicType) => ApexOptions

export const useGraphOptions: UseGraphOptionsHook = (kpiData, type) => {
    const fontFamily = useGetCSSVar('--fontFamilyText')
    const foreColor = useGetCSSVar('--TextSecondary')
    const appealStrokeColor = useGetCSSVar('--LineYellow')
    const consultationStrokeColor = useGetCSSVar('--LineElectricBlue')
    const appealFillColor = useGetCSSVar('--BodyYellow')
    const consultationFillColor = useGetCSSVar('--BodyElectricBlue')
    const borderColor = useGetCSSVar('--DividerThin')

    return useMemo(() => {
        const colorIdx = type === TopicType.appeal ? 0 : 1
        const strokeColors = [appealStrokeColor, consultationStrokeColor]
        const fillColors = [appealFillColor, consultationFillColor]

        const periods: string[] = []
        const tooltipPeriods: string[] = []
        const plan: number[] = []
        const fact: number[] = []
        for (let idx = 0; idx < kpiData.length; idx++) {
            const item = kpiData[idx]
            periods.push(getDateLabels(item[0], AggregateTypes.MONTH))
            tooltipPeriods.push(dayjs(item[0]).format('MMMM YYYY'))
            plan.push(item[1])
            fact.push(item[2])
        }

        return {
            options: {
                labels: periods,
                stroke: {
                    dashArray: [6, 0],
                    width: [3, 1],
                    colors: [strokeColors[colorIdx], strokeColors[colorIdx]],
                    curve: 'straight',
                },
                fill: {
                    opacity: 0.75,
                    colors: [strokeColors[colorIdx], fillColors[colorIdx]],
                },
                chart: {
                    toolbar: {
                        show: false,
                    },
                    selection: {
                        enabled: false,
                    },
                    zoom: {
                        enabled: false,
                    },
                    fontFamily,
                    foreColor,
                },
                legend: {
                    show: false,
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        borderRadius: 7,
                        columnWidth: '90%',
                    }
                },
                grid: {
                    borderColor,
                },
                xaxis: {
                    // tickPlacement: 'on', // приводит к сужению грайика (поля по сторонам)
                    axisTicks: { show: false },
                    tooltip: {
                        enabled: false,
                    },
                },
                dataLabels: {
                    enabled: false,
                },
                yaxis: {
                    tooltip: {
                        enabled: false,
                    },
                    labels: {
                        formatter: numShortWithoutZero,
                    },
                },
                tooltip: {
                    custom: customTooltipFactory({ period: tooltipPeriods, plan, fact }),
                    followCursor: true,
                    marker: {
                        show: false,
                    },
                    shared: true,
                    intersect: false,
                },
                states: {
                    hover: {
                        filter: {
                            // type: 'darken',
                            // type: 'none',
                        },
                    },
                    active: {
                        filter: {
                            type: 'none',
                        },
                    },
                },
            },
            series: [
                {
                    name: 'plan',
                    type: 'line',
                    data: plan,
                },
                {
                    name: 'fact',
                    type: 'column',
                    data: fact,
                }
            ],
        }
    }, [
        kpiData,
        type,
        fontFamily,
        foreColor,
        appealStrokeColor,
        appealFillColor,
        consultationStrokeColor,
        consultationFillColor,
        borderColor,
    ])
}
