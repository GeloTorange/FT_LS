export type KpiData = [string, number, number]
