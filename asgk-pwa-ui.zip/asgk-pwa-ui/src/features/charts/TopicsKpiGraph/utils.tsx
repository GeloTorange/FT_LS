import type { TooltipOptions } from '@shared/types/apexchart'
import { toHtml } from '@shared/utils/html'

import { Tooltip } from './Tooltip'

interface CustomTooltipFactoryArgs {
    period: string[];
    plan: number[];
    fact: number[];
}

export const customTooltipFactory = ({ period, plan, fact }: CustomTooltipFactoryArgs) => 
    ({ dataPointIndex }: Partial<TooltipOptions>) => (dataPointIndex === undefined)
        ? undefined
        : toHtml(
            <Tooltip
                period={period[dataPointIndex]}
                plan={plan[dataPointIndex]}
                fact={fact[dataPointIndex]}
            />
        )
 