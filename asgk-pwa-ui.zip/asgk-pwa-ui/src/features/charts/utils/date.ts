import dayjs from 'dayjs'

import { GraphAggregateFormats } from '@shared/types/apexchart'
import { AggregateTypes } from '@shared/types/filters'

let briefMonths: string[] = []

/**
 * Форматирует дату для графиков
 * @param {String} val дата в iso-формате
 * @param {AggregateTypes} aggregate тип форматирования ({@link AggregateTypes})
 * @return {String} отфтрматированная дата ({@link GraphAggregateFormats})
 */
export const getDateLabels = (val: string, aggregate: AggregateTypes) => {
    if (aggregate === AggregateTypes.MONTH) {
        if (!briefMonths.length) {
            briefMonths = Array.from({ length: 12 }).map((_val, idx) =>
                dayjs(`2025-${idx + 1}`).format(GraphAggregateFormats[AggregateTypes.MONTH]).substring(0, 3)
            )
        }
        return briefMonths[dayjs(val).month()]
    }
    return dayjs(val).format(GraphAggregateFormats[aggregate])
}
