export { TrendGraph } from './TrendGraph'
