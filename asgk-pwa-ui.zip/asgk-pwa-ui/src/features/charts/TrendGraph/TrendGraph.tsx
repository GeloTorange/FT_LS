import type { ApexOptions } from 'apexcharts'
import clsx from 'clsx'
import React, { memo } from 'react'
import Graph from 'react-apexcharts'
import { isDesktop } from 'react-device-detect'

import type { TrendChartData } from '@shared/api/trends'
import { TrendTypes } from '@shared/api/trends'
import { useGetCSSVar } from '@shared/styles'
import type { TooltipOptions } from '@shared/types/apexchart'
import { AggregateTypes } from '@shared/types/filters'
import { dateFormatter } from '@shared/utils/formatting'
import '@shared/styles/sparkline.css'

import styles from './styles.module.scss'
import { useTrendGraphData } from './useTrendGraphData'
import { getTooltip } from './utils'


type Props = {
    trendType?: TrendTypes,
    chartData: TrendChartData[],
    aggregateType?: AggregateTypes,
}


export const TrendGraph: React.FC<Props> = memo(({
    trendType = TrendTypes.POSITIVE,
    chartData,
    aggregateType = AggregateTypes.MONTH
}) => {
    const { graphLabels, graphData } = useTrendGraphData({ chartData })
    const cssVars = {
        fontFamily: useGetCSSVar('--fontFamilyText'),
        textColor: useGetCSSVar('--TextSecondary'),
        lineViolet: useGetCSSVar('--LineViolet'),
        lineGreen: useGetCSSVar('--LineGreen'),
        bodyViolet: useGetCSSVar('--BodyViolet'),
        bg1: useGetCSSVar('--Background1')
    }

    const { options, series } = {
        series: [{
            name: 'TrendChart',
            data: graphData,
        }],
        options: {
            chart: {
                id: 'trendChart',
                fontFamily: cssVars.fontFamily,
                // цвет текста на графиках
                foreColor: cssVars.textColor,
                toolbar: {
                    show: false,
                },
                // отступ вправо X
                offsetX: 0,
                // отключить zoom
                zoom: {
                    enabled: false,
                },
            },
            xaxis: {
                categories: graphLabels,
                labels: {
                    formatter: dateFormatter(aggregateType),
                },
                // всплывающий пунктир тултипа на оси Y при наведении на markers
                crosshairs: {
                    show: false,
                },
                axisTicks: {
                    show: false,
                },
                axisBorder: {
                    show: false,
                },
                // всплывающий тултип на нижней границе оси X categories
                tooltip: {
                    enabled: false,
                },
            },
            yaxis: {
                // всплывающий пунктир тултипа на границе Y при наведении на markers
                tooltip: {
                    enabled: false,
                },
                // Чтобы было минимальное пространство снизу
                min: Math.min(...graphData) - 5,
                // Максимальное вычисляем с округлением до ближайшего десятка + 5, чтобы не в нахлёст
                max: Math.round(Math.max(...graphData) / 10 * 10) + 5,
                labels: {
                    show: false,
                },
            },
            tooltip: {
                enabled: true,
                shared: false,
                fillSeriesColor: false,
                x: {
                    show: false,
                    // format: 'dd MM YYYY',
                },
                marker: {
                    show: false
                },
                custom: (optionsTooltip: TooltipOptions) => getTooltip(optionsTooltip, graphLabels),
            },
            // цвет графика
            stroke: {
                show: true,
                curve: 'straight',
                colors: [trendType === '-1' ? cssVars.lineViolet : cssVars.lineGreen],
                width: 2,
            },
            // сетка для графика
            grid: {
                show: false,
                padding: {
                    // убираем лишний отступ снизу что делает апекс
                    bottom: -13,
                    right: 13,
                }
            },
            // цифры над точками в графике
            dataLabels: {
                enabled: true,
                distributed: false,
                offsetX: 0,
                offsetY: -8,
                style: {
                    fontSize: '12px',
                    fontFamily: cssVars.fontFamily,
                    fontWeight: 'normal',
                    colors: [cssVars.textColor]
                },
                // обводка
                background: {
                    enabled: false,
                },
                formatter: (val: string | number) => `${val}%`
            },
            markers: {
                shape: 'circle',
                size: 4,
                colors: cssVars.bg1,
                strokeColors:
                    trendType === TrendTypes.NEGATIVE ? cssVars.lineViolet : cssVars.lineGreen,
                strokeWidth: 3,
                hover: {
                    sizeOffset: 1
                },
            },
            plotOptions: {
                area: {
                    // чтобы было пространство снизу от 0
                    fillTo: 'end',
                },
            },
            fill: {
                type: 'solid',
                colors: [cssVars.bodyViolet],
            },
        } as ApexOptions
    }

    return (
        <Graph
            className={clsx(!isDesktop && styles.graphMob)}
            options={options}
            series={series}
            type={'area'}
            // Примерная нужная высота. Она меняется в зависимости от заголовка тренда
            height={'90%'}
        />
    )
})
