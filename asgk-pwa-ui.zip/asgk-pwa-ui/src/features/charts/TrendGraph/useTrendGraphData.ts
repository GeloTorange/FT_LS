import type { TrendChartData } from '@shared/api/trends'


type Props = {
    chartData: TrendChartData[]
}

export const useTrendGraphData = ({ chartData }: Props) => {
    const graphLabels = []
    const graphData = []

    for (const current of chartData) {
        // условие для скрытия пустых дат, если на графике нужны пропуски - вернуть
        // if (current.trendRatioPct && current.trendRatioPct > 0) {
        graphLabels.push(current.date)
        graphData.push(Number(current.trendRatioPct))
        // }
    }

    return {
        graphLabels,
        graphData
    }
}
