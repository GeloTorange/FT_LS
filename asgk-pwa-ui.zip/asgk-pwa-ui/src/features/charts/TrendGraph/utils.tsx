import clsx from 'clsx'

import { bodyTypographyStyle } from '@shared/components/typography'
import { helperStyles } from '@shared/styles'
import type { TooltipOptions } from '@shared/types/apexchart'
import { dateToUIFormat } from '@shared/utils/formatting'
import { toHtml } from '@shared/utils/html'


export const getTooltip = (options: TooltipOptions, dateLabel: string[] ) => {
    const { series, seriesIndex, dataPointIndex } = options
    const date = dateLabel[dataPointIndex]

    const formatDate = dateToUIFormat(date)
    const value = series[seriesIndex][dataPointIndex]

    return toHtml(
        <div className={clsx(helperStyles.tooltip, bodyTypographyStyle, helperStyles.tooltipWrapper)}>
            <p className={helperStyles.tooltipSecondaryColor}>{formatDate}</p>
            <p>{`Доля: ${value}%`}</p>
        </div>
    )
}
