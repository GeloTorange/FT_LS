import { ThunderboltOutlined } from '@ant-design/icons'
import { Button } from 'antd'
import React, { memo } from 'react'
import { useDispatch } from 'react-redux'

import { setPutMeasureModalForStart } from '@entities/measure'

import styles from './styles.module.scss'

type Props = {
    // наполнить все необходимые пропсы
    isLoading: boolean
}
export const ButtonAddMeasure = memo(({ isLoading, }: Props) => {
    const dispatch = useDispatch()

    const onClick = () => {
        dispatch(setPutMeasureModalForStart({ isShow: true }))
    }

    return (
        !(isLoading) ?
            <Button
                data-testid={'buttonAddReason'}
                size={'large'}
                onClick={onClick}
                icon={<ThunderboltOutlined className={styles.noDataIconBtn} />}
            >
                Добавить меру
            </Button> :
            null
    )
})
