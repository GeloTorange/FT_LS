import type { Question } from '@shared/api/insightHub'

import type { DialogItem, QuestionChain } from '../types'


const composeChainsOfQuestions = (questions: Question[]): QuestionChain[] => {
    const chains: QuestionChain[] = []
    for (const question of questions) {
        if (question.primaryId) {
            let added = false
            for (const chain of chains) {
                const found = chain.chain.find(item => item.questionId === question.primaryId)
                if (found) {
                    chain.chain.push(question)
                    added = true
                    break
                }
            }
            if (!added) {
                chains.push({
                    id: question.questionId,
                    question: question.question,
                    chain: [question],
                })
            }
        } else {
            chains.push({
                id: question.questionId,
                question: question.question,
                chain: [question],
            })
        }
    }
    return chains
}

const composeChainsOfDialogItems = (questions: DialogItem[]): QuestionChain<DialogItem>[] => {
    const chains: QuestionChain<DialogItem>[] = []
    for (const question of questions) {
        const prevChain = chains.length && chains[chains.length - 1]
        if (prevChain && (prevChain.question === question.question)) {
            prevChain.chain.push(question)
        } else {
            chains.push({
                id: question.questionId || '',
                question: question.question,
                chain: [question],
            })
        }
    }
    return chains
}

export function composeChains (questions: Question[]): QuestionChain<Question>[]
export function composeChains (questions: DialogItem[]): QuestionChain<DialogItem>[]
export function composeChains (questions: (Question | DialogItem)[]) {
    if (!questions.length) {
        return []
    }
    return ((questions[0] as Question).dialogId !== undefined)
        ? composeChainsOfQuestions(questions as Question[])
        : composeChainsOfDialogItems(questions as DialogItem[])
}
