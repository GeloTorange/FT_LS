import { parseStrSafety } from '@shared/utils/formatting'

export interface SseEvent<T> {
    id: string | null;
    event: string | null;
    data: T | null;
}

export class SseParserStream<T> extends TransformStream<string, SseEvent<T>> {
    constructor () {
        super({
            transform: (chunk, controller) => {
                const lines = chunk.split('\n').filter(Boolean)
                const event: SseEvent<T> = { id: null, event: null, data: null }
                for (const line of lines) {
                    if (line.startsWith('id:')) {
                        event.id = line.substring(3).trim()
                    } else if (line.startsWith('event:')) {
                        event.event = line.substring(6).trim()
                    } else if (line.startsWith('data:')) {
                        event.data = parseStrSafety(line.substring(5).trim())
                    }
                }
                controller.enqueue(event)
            },
        })
    }
}
