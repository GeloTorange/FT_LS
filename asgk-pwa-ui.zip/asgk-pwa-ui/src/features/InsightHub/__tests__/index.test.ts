import { describe, it, expect } from 'vitest'
import { InsightHubDialog, InsightHubButton } from '../../InsightHub'

describe('InsightHub index', () => {
    it('should be defined', () => {
        expect(InsightHubDialog).toBeDefined()
        expect(InsightHubButton).toBeDefined()
    })
})
