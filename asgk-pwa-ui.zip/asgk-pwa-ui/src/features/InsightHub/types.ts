import type { Question, QuestionData } from '@shared/api/insightHub'

export interface InsightHubParams {
    data?: QuestionData;
    ttlSec?: number;
    limit?: number,
    useSse?: boolean,
}

export interface DialogStateProps {
    dialogId?: string;
    onNewDialog?: (dialogId: string) => void;
}

export interface QuestionChain<T extends Question | DialogItem> {
    id: string;
    question: string;
    chain: T[];
}

export interface DialogItem {
    questionId?: string;
    question: string;
    answer?: string;
    isLiked?: boolean | null;
    isAsking?: boolean;
    isError?: boolean;
    isCanceled?: boolean;
}
