import type { AxiosError } from 'axios'
import type { Dayjs } from 'dayjs'
import dayjs from 'dayjs'
import { useCallback, useEffect, useRef, useState } from 'react'

import type { Question, GetQuestionsParams, VoteParams } from '@shared/api/insightHub'
import {
    cancelQuestion,
    getPreviousQuestions,
    getQuestion,
    askQuestion,
    listenSse,
    voteQuestion,
    useGetDislikeReasonsQuery
} from '@shared/api/insightHub'

import type { DialogStateProps, InsightHubParams, QuestionChain } from '../types'
import { composeChains, SseParserStream } from '../utils'

/* comment: надстрочные комменарии не везде удобны */
/* eslint-disable line-comment-position */

const pullLimit1Sec = 7 // период веремени, по прошествии которое меняется инервал pull-запросов
const pullInterval1Sec = 1 // первый иентервал pull-запросов
const pullInterval2Sec = 3 // второй иентервал pull-запросов

export const useInsightHub = (
    insightHubParams?: InsightHubParams,
    dialogId?: DialogStateProps['dialogId'],
    onNewDialog?: DialogStateProps['onNewDialog']
) => {
    const {
        data: questionData,
        ttlSec: questionTtlSec = 120,
        limit = 10,
        useSse = false
    } = insightHubParams || {}

    const [questions, setQuestions] = useState<{ questions: Question[], chains: QuestionChain<Question>[] }>({
        questions: [],
        chains: [],
    })
    const [isLoading, setIsLoading] = useState(false)
    const [loadingError, setLoadingError] = useState<Error>()

    const [isAnswering, setIsAnswering] = useState(false)

    const [isVoting, setIsVoting] = useState(false)
    const [votingError, setVotingError] = useState<Error>()

    const dialogIdRef = useRef(dialogId || '')
    const abortControllerRef = useRef<AbortController>()

    // параметры для обработки таймаута ожидания ответа
    const answerIntervalRef = useRef<NodeJS.Timeout>()
    const answerTimeoutRef = useRef<NodeJS.Timeout>()
    const answerStartRef = useRef<Dayjs>()
    const questioningIdRef = useRef('')

    // отмена текущих запросов и таймеров
    const clear = useCallback(() => {
        questioningIdRef.current = ''
        clearInterval(answerIntervalRef.current)
        answerIntervalRef.current = undefined
        clearTimeout(answerTimeoutRef.current)
        setIsAnswering(false)
        if (abortControllerRef.current) {
            abortControllerRef.current.abort()
            abortControllerRef.current = undefined
        }
    }, [setIsAnswering])

    useEffect(() => clear, [clear])

    const loadingWrapper = useCallback((params: GetQuestionsParams) => {
        setIsLoading(true)
        setLoadingError(undefined)
        getPreviousQuestions(params)
            .then(({ data }) => { setQuestions({ questions: data, chains: composeChains(data) }) })
            .catch(setLoadingError)
            .finally(() => { setIsLoading(false) })
    }, [setIsLoading, setLoadingError, setQuestions])

    useEffect(() => {
        if (dialogId) {
            // загрузка предыдущих вопросов
            loadingWrapper({ dialogId })
        }
    }, [loadingWrapper, dialogId])

    const loadPrevious = useCallback(() => {
        const before = questions.questions.length ? questions.questions[0].questionedAt : undefined
        loadingWrapper({ before, limit })
    }, [loadingWrapper, questions, limit])


    const abortControllerFactory = useCallback(() => {
        const controller = new AbortController()
        answerTimeoutRef.current = setTimeout(() => {
            controller.abort()
        }, questionTtlSec * 1000)
        return controller
    }, [questionTtlSec])

    const isAskTtlOver = useCallback(
        () => dayjs().diff(answerStartRef.current as Dayjs, 'seconds') > questionTtlSec, 
        [questionTtlSec]
    )

    const updateLastQuestion = useCallback((question: Question, addNew = false) => {
        setQuestions(prev => {
            const prevQuestions = prev.questions
            const newQuestions = [...prevQuestions.slice(0, prevQuestions.length - (addNew ? 0 : 1)), question]
            return {
                questions: newQuestions,
                chains: composeChains(newQuestions),
            }
        })
    }, [setQuestions])
    const updateLastQuestionStatus = useCallback((status: string) => {
        setQuestions(prev => {
            const prevQuestions = prev.questions
            prevQuestions[prevQuestions.length - 1].status = status
            const newQuestions = [...prevQuestions]
            return {
                questions: newQuestions,
                chains: composeChains(newQuestions),
            }
        })
    }, [setQuestions])
    const updateQuestion = useCallback((question: Question) => {
        setQuestions(prev => {
            const prevQuestions = prev.questions
            const foundIdx = prevQuestions.findIndex(item => item.questionId === question.questionId)
            if (foundIdx === -1) {
                return prev
            }
            const newQuestions = [
                ...prevQuestions.slice(0, foundIdx),
                { ...question },
                ...prevQuestions.slice(foundIdx + 1),
            ]
            return {
                questions: newQuestions,
                chains: composeChains(newQuestions),
            }
        })
    }, [setQuestions])

    const startPullRequests = useCallback((questionId: string) => {
        let isPending = false // состояние предыдущего pull-запроса
        const pullQuestion = async (id: string) => {
            if (isAskTtlOver()) {
                updateLastQuestionStatus('ERROR_TIMEOUT')
                clear()
                return
            }
            if (isPending) {
                return
            }

            isPending = true
            abortControllerRef.current = abortControllerFactory()
            try {
                const { data } = await getQuestion(id)
                if (data?.answeredAt) {
                    updateLastQuestion(data)
                    clear()
                }
            } finally {
                isPending = false
            }
        }

        const isAskLimit1Over = () => dayjs().diff(answerStartRef.current as Dayjs, 'seconds') > pullLimit1Sec

        answerIntervalRef.current = setInterval(async () => {
            await pullQuestion(questionId)
            if (isAskLimit1Over()) {
                // переназначаем интервал pull-запросов
                clearInterval(answerIntervalRef.current)
                answerIntervalRef.current = setInterval(async () => {
                    await pullQuestion(questionId)
                }, pullInterval2Sec * 1000)
            }
        }, pullInterval1Sec * 1000)
    }, [
        isAskTtlOver, updateLastQuestion, abortControllerFactory, clear, updateLastQuestionStatus
    ])

    const startSseListening = useCallback((questionId: string) => {
        abortControllerRef.current = abortControllerFactory()

        // Сперва пытаесмся получить ответ через sse-соединение, если оно не получается, то делаем pull-запросы.
        listenSse(questionId, abortControllerRef.current?.signal)
            .then(async (sseData) => {
                const reader = sseData
                    .pipeThrough(new TextDecoderStream() as TransformStream)
                    .pipeThrough(new SseParserStream<Question>())
                    .getReader()
                // comment: безусловынй цикл
                // eslint-disable-next-line no-constant-condition
                while (true) {
                    // comment: требуется для обработки sse-соединения
                    // eslint-disable-next-line no-await-in-loop
                    const { done, value: sseEvent } = await reader.read()
                    if (
                        sseEvent?.data && sseEvent?.id === questionId
                    &&
                    sseEvent?.event === 'answer'
                    ) {
                        updateLastQuestion(sseEvent.data)
                        clear()
                        break
                    }
                    if (done) {
                        if (!sseEvent && !isAskTtlOver()) {
                            startPullRequests(questionId)
                        }
                        break
                    }
                }
            })
            .catch(e => {
                if ((e as AxiosError).code === 'ERR_CANCELED') {
                    setIsAnswering(false)
                } else {
                    startPullRequests(questionId)
                }
            })
            .finally(() => {
                clear()
            })
    }, [
        startPullRequests, updateLastQuestion, abortControllerFactory, clear, isAskTtlOver
    ])

    useEffect(() => {
        if (!questioningIdRef.current && questions.questions.length && (
            questions.questions[questions.questions.length - 1].status === 'WORKING'
        )) {
            setIsAnswering(true)
            const questionId = questions.questions[questions.questions.length - 1].questionId
            questioningIdRef.current = questionId
            if (useSse) {
                startSseListening(questionId)
            } else {
                startPullRequests(questionId)
            }
        }
    }, [
        questions, setIsAnswering, useSse, startSseListening, startPullRequests
    ])

    const ask = useCallback((question: string, primaryId?: string) => {
        clear()
        setIsAnswering(true)

        // показываем отправленный вопрос пользователю
        updateLastQuestion({
            dialogId: dialogIdRef.current,
            questionId: '',
            question,
            questionedAt: '',
            primaryId
        }, true)

        askQuestion({
            dialogId: dialogIdRef.current,
            content: question,
            data: questionData,
            ttlSec: questionTtlSec,
            primaryId,
        })
            .then(({ data: newDialog }) => {
                answerStartRef.current = dayjs()
                updateLastQuestion(newDialog)
                if (!dialogIdRef.current) {
                    dialogIdRef.current = newDialog.dialogId
                    if (onNewDialog) {
                        onNewDialog(newDialog.dialogId)
                    }
                }
            })
            .catch(() => {
                updateLastQuestion({
                    dialogId: dialogIdRef.current,
                    questionId: '',
                    question, questionedAt: '',
                    answeredAt: 'non-empty',
                    status: 'ERROR_QUESTION'
                })
            })
    }, [
        setIsAnswering,
        questionData,
        questionTtlSec,
        onNewDialog,
        updateLastQuestion,
        clear,
    ])

    const cancel = useCallback(() => {
        if (!isAnswering) {
            return
        }

        clear()
        const lastQuestion = questions.questions[questions.questions.length - 1]
        updateLastQuestion({ ...lastQuestion, status: 'CANCELED' })

        if (lastQuestion?.questionId) {
            cancelQuestion(lastQuestion.questionId).then(({ data: canceledQuestion }) => {
                updateLastQuestion(canceledQuestion)
            })
        }
    }, [
        isAnswering, questions, clear, updateLastQuestion
    ])

    const votingWrapper = useCallback((questionId: string, params: VoteParams = {}) => {
        setIsVoting(true)
        setVotingError(undefined)
        voteQuestion(questionId, params)
            .then(({ data }) => { updateQuestion(data)})
            .catch(setVotingError)
            .finally(() => { setIsVoting(false) })
    }, [setIsVoting, setVotingError, updateQuestion])

    const like = useCallback((questionId: string) => {
        votingWrapper(questionId, { like: true })
    }, [votingWrapper])

    const dislike = useCallback((questionId: string, dislikeReasonId?: string, comment?: string) => {
        votingWrapper(questionId, { like: false, dislikeReasonId, comment })
    }, [votingWrapper])

    const cancelVote = useCallback((questionId: string) => {
        votingWrapper(questionId)
    }, [votingWrapper])

    const { data: dislikeReasons } = useGetDislikeReasonsQuery()

    return {
        ...questions,
        loadPrevious, 
        isLoading,
        loadingError, 

        ask, 
        cancel, 
        isAnswering, 
        
        isVoting, 
        votingError, 
        like, 
        dislike, 
        cancelVote,

        dislikeReasons,
    }
}
