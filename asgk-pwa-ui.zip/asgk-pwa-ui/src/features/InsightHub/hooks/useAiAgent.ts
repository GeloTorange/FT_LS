import { useCallback, useEffect, useRef, useState } from 'react'

import { DislikeReason, postDialog, postFeedback, useGetMessageQuery } from '@shared/api/aiHub'
import type { FeedbackParams } from '@shared/api/aiHub'

import type { DialogItem, DialogStateProps, QuestionChain } from '../types'
import { composeChains } from '../utils'


// таблица причин дизлайов (ранее передавалась с бекенда)
export const dislikeReasons = [
    {
        id: DislikeReason.insufficientInfo,
        reason: 'Недостаточно информации',
        commentRequired: false,
    },
    {
        id: DislikeReason.hasError,
        reason: 'Есть ошибка',
        commentRequired: false,
    },
    {
        id: DislikeReason.other,
        reason: 'Другое',
        commentRequired: true,
    },
]


export const useAiAgent = (
    // questions - "живой" обновляемый внутри хука массив, который хранит задаваемые вопросы
    // (используется для сохранения истории вопросов/ответов при закрытии окна диалога)
    questions: DialogItem[],

    dialogId?: DialogStateProps['dialogId'],
    onNewDialog?: DialogStateProps['onNewDialog']
) => {
    const { data: greetingData, isLoading: isGreetingLoading } = useGetMessageQuery()

    const [chains, setChains] = useState<QuestionChain<DialogItem>[]>(composeChains(questions))

    const [isAnswering, setIsAnswering] = useState(false)
    const [isVoting, setIsVoting] = useState(false)

    const dialogIdRef = useRef(dialogId || '')
    const abortControllerRef = useRef<AbortController>()

    // отмена текущих запросов
    const clear = useCallback(() => {
        setIsAnswering(false)
        if (abortControllerRef.current) {
            abortControllerRef.current.abort()
            abortControllerRef.current = undefined
        }
    }, [setIsAnswering])

    useEffect(() => clear, [clear])

    // добаление нового вопроса
    const addAskingQuestion = useCallback((question: string) => {
        questions.push({
            questionId: '',
            question,
            isAsking: true,
        })
        setChains(composeChains(questions))
    }, [])

    // обновление статуса последнего вопроса
    const updateLastQuestion = useCallback((data: Partial<Omit<DialogItem, 'question'>>) => {
        if (questions.length) {
            questions[questions.length - 1] = { ... questions[questions.length - 1], ...data }
            setChains(composeChains(questions))
        }
    }, [])

    // обновление голосования по вопросу
    const updateVotingQuestion = useCallback((
        { questionId, isLiked }: Required<Pick<DialogItem, 'questionId' | 'isLiked'>>
    ) => {
        const found = questions.find(item => item.questionId === questionId)
        if (found) {
            found.isLiked = isLiked
            setChains(composeChains(questions))
        }
    }, [])

    // отправка нового вопроса
    const ask = useCallback((question: string) => {
        clear()
        setIsAnswering(true)

        // показываем отправленный вопрос пользователю
        addAskingQuestion(question)

        abortControllerRef.current = new AbortController()

        postDialog({ conversationId: dialogIdRef.current, question }, { signal: abortControllerRef.current.signal })
            .then((ddd) => {
                if (ddd.data) {
                    const { conversationId, ...other } = ddd.data
                    dialogIdRef.current = conversationId
                    if (onNewDialog) {
                        onNewDialog(conversationId)
                    }
                    updateLastQuestion({ ...other, isAsking: false })
                } else {
                    updateLastQuestion({ isAsking: false, isError: true })
                }
            })
            .catch(() => {
                updateLastQuestion({ isAsking: false, isError: true })
            })
            .finally(() => {
                setIsAnswering(false)
                abortControllerRef.current = undefined
            })
    }, [
        setIsAnswering,
        onNewDialog,
        updateLastQuestion,
        clear,
    ])

    // отмена текущего вопроса
    const cancel = useCallback(() => {
        if (!isAnswering) {
            return
        }
        clear()
        updateLastQuestion({ isAsking: false, isCanceled: true })
    }, [
        isAnswering, questions, clear, updateLastQuestion
    ])

    // отправка голосования (like/dislike)
    const votingWrapper = useCallback((
        questionId: string, 
        params: Omit<FeedbackParams, 'conversationId' | 'questionId'>
    ) => {
        setIsVoting(true)
        return postFeedback({
            ...params,
            conversationId: dialogIdRef.current,
            questionId,
        })
            .then(({ data }) => { updateVotingQuestion(data) })
            .catch((error) => {
                throw error
            })
            .finally(() => { setIsVoting(false) })
    }, [setIsVoting, updateLastQuestion])

    // обработчики голосовалок
    const like = useCallback((questionId: string) => votingWrapper(questionId, { isLiked: true }), [votingWrapper])
    const dislike = useCallback(
        (questionId: string, dislikeReasonId?: string, comment?: string) => 
            votingWrapper(questionId, { isLiked: false, reasonId: dislikeReasonId as DislikeReason, comment }), 
        [votingWrapper]
    )
    const cancelVote = useCallback((questionId: string) =>
        votingWrapper(questionId, { isLiked: null }), [votingWrapper])
    
    return {
        chains,
        isLoading: isGreetingLoading,

        ask, 
        cancel,
        isAnswering, 
        
        isVoting, 
        like,
        dislike,
        cancelVote,

        dislikeReasons,
        greetingMessage: greetingData?.text,
    }
}
