import { Button } from 'antd'
import type { FC } from 'react'
import { isDesktop } from 'react-device-detect'

import { BookmarkOutlined } from '@shared/assets/icons'
import type { ListingTypes } from '@shared/types/listingTypes'
import { clickFavorite } from '@shared/utils/CSI'

import styles from './styles.module.scss'

type Props = {
    isFavorite: boolean,
    id: string,
    type: ListingTypes,
    loadData: () => void,
}

export const ButtonIsFavorite: FC<Props> = ({
    isFavorite,
    id,
    type,
    loadData
}) => {
    const buttonText = isFavorite ? 'В избранном' : 'В избранное'

    return (
        <Button
            size={'large'}
            icon={<BookmarkOutlined className={isFavorite ? styles.filled : undefined}/>}
            onClick={clickFavorite({ id, isFavorite, type, loadData })}
        >
            {isDesktop ? buttonText : null}
        </Button>
    )
}
