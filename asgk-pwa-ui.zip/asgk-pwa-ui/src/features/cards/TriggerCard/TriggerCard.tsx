import { Row, Col, Flex, Space } from 'antd'
import dayjs from 'dayjs'
import React, { useCallback } from 'react'
import { createSearchParams, useNavigate } from 'react-router-dom'

import { Tags } from '@shared/components/tags'
import { TitleForTriggerAndTrendCard } from '@shared/components/TitleForTriggerAndTrendCard'
import { Wrappers } from '@shared/components/wrappers'
import { PAGE_ROUTES } from '@shared/system/router'
import type { StatisticData } from '@shared/types/api'
import type { OnClickEvent } from '@shared/types/handlers'
import { ListingTypes } from '@shared/types/listingTypes'
import { clickFavorite, getTagColor, getViewCSIIncrPct } from '@shared/utils/CSI'
import { numShort } from '@shared/utils/formatting'

import { TypographyCaption } from '../../../shared/components/typography'
// TODO: передавать график через пропсы
import { Charts } from '../../charts'

import type { TriggerCardProps } from './types'


const dateFormat = 'DD MMMM YYYY'
const TYPE = ListingTypes.TRIGGER

export const TriggerCard = ({
    id,
    description,
    title,
    isFavorite,
    loadData,
    statistics,
    navigatePageSearchParams,
    csi,
    csiIncrPct,
    isListView,
}: TriggerCardProps) => {
    const navigate = useNavigate()

    const onClick = () => {
        navigate({
            pathname: `${PAGE_ROUTES.TRIGGERS}/${id}`,
            search: createSearchParams(navigatePageSearchParams || {}).toString(),
        })
    }

    const onClickFavorite: OnClickEvent = useCallback(
        (e) => { clickFavorite({ id, isFavorite, type:TYPE, loadData })(e) },
        [id, isFavorite, TYPE, loadData]
    )

    const sparklineTooltip = useCallback((item: StatisticData) => (
        <Space direction={'vertical'} size={0}>
            <TypographyCaption style={{ color: 'var(--TextSecondary)' }}>
                {dayjs(item.date).format(dateFormat)}
            </TypographyCaption>
            <TypographyCaption>
                {`CSI: ${item.csi === null ? '–' : item.csi}`}
            </TypographyCaption>
            <TypographyCaption>
                {`Ответов: ${numShort(item.countAnswers)}`}
            </TypographyCaption>
        </Space>
    ), [])

    return (
        <Wrappers.Card
            isListView={isListView}
            onClick={onClick}
        >
            <Row
                style={{ height: '100%', alignContent: 'space-between' }}
                gutter={[0, 12]}
            >
                <Col span={24}>
                    <TitleForTriggerAndTrendCard
                        id={id}
                        clickFavorite={onClickFavorite}
                        title={title}
                        description={description}
                        isFavorite={isFavorite}
                    />
                </Col>
                <Col span={24}>
                    <Flex justify={'space-between'} align={'center'}>
                        <Tags.CSI
                            csi={csi}
                            tagColor={getTagColor(csi)}
                        />
                        {statistics?.data?.length > 0 ? (
                            <>
                                <TypographyCaption
                                    type={'secondary'}
                                    style={{ marginLeft: 'auto', marginRight: '9px' }}
                                >
                                    {getViewCSIIncrPct(csiIncrPct)}
                                </TypographyCaption>
                                <Charts.Sparkline<StatisticData>
                                    data={statistics.data}
                                    yField={'csi'}
                                    tooltip={sparklineTooltip}
                                    inverted={false}
                                    chardId={'triggerCard'}
                                />
                            </>
                        ) : (
                            <TypographyCaption type={'secondary'}>
                                нет данных
                            </TypographyCaption>
                        )}
                    </Flex>
                </Col>
            </Row>
        </Wrappers.Card>
    )
}
