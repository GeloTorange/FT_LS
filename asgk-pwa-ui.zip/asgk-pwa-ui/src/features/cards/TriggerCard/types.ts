import type { URLSearchParamsInit } from 'react-router-dom'

import type { StatisticsCSI } from '@shared/types/api'

export type TriggerCardProps = {
    id: number,
    description: string,
    title: string,
    isFavorite: boolean,
    loadData: () => void,
    statistics: StatisticsCSI,
    navigatePageSearchParams?: URLSearchParamsInit | null,
    csi: number,
    csiIncrPct: number,
    isListView?: boolean
}
