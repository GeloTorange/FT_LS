import { CommentCard } from './CommentCard'
import { SummaryCard } from './SummaryCard'
import { TopicCard } from './TopicCard'
import { TrendCard } from './TrendCard'
import { TriggerCard } from './TriggerCard'


export const Cards = {
    Summary: SummaryCard,
    Topic: TopicCard,
    Trend: TrendCard,
    Trigger: TriggerCard,
    Comment: CommentCard,
}
