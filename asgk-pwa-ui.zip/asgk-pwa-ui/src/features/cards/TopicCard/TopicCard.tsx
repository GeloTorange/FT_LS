import { Col, Flex, Row, Space, Typography } from 'antd'
import type { Dayjs } from 'dayjs'
import dayjs from 'dayjs'
import type { CSSProperties, FC } from 'react'
import { useCallback, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'

import { useSummaryQueryStringFilter } from '@entities/summary'
import type { Topic , TopicStatistic } from '@shared/api/topics'
import { TopicType } from '@shared/api/topics'
import { PercentView } from '@shared/components/PercentView'
import { TypographyBody, TypographyCaption } from '@shared/components/typography'
import { Wrappers } from '@shared/components/wrappers'
import { PAGE_ROUTES } from '@shared/system/router'

// TODO: передавать через пропсы
import { Charts } from '../../charts'



export interface TopicCardProps {
    topic: Topic;
    summaryFilter?: {
        startDate?: Dayjs;
        endDate?: Dayjs;
    }
}

const dateFormat = 'DD MMMM YYYY'
const titleStyle: CSSProperties = { margin: 0 }

export const TopicCard: FC<TopicCardProps> = ({ topic, summaryFilter }) => {
    const navigate = useNavigate()
    const [,, generateFilterQueryString] = useSummaryQueryStringFilter()

    const navigateToSummary = useCallback(() => {
        navigate({
            pathname: `${PAGE_ROUTES.TOPICS_SUMMARY}`,
            search: `appealType=${topic.type}&${generateFilterQueryString({
                factorica: topic.factorica,
                tribeId: topic.tribeId,
                startDate: summaryFilter?.startDate,
                endDate: summaryFilter?.endDate,
            })}`,
        })
    }, [
        navigate, topic, summaryFilter, generateFilterQueryString
    ])

    const statisticDelta = useMemo(() => {
        const data = topic.statistic
        let delta: number | null = null
        if (data?.length && (data[0].qty !== 0)) {
            delta = data[data.length - 1].qty / data[0].qty - 1
        }
        return delta
    }, [topic.statistic])

    const sparklineTooltip = useCallback((item: TopicStatistic) => (
        <Space direction={'vertical'} size={0}>
            <TypographyCaption style={{ color: 'var(--TextSecondary)' }} >
                {dayjs(item.startDate).format(dateFormat)}
            </TypographyCaption>
            <TypographyCaption>
                {topic.type === TopicType.appeal && 'Жалоб: '}
                {topic.type === TopicType.consultation && 'Консультаций: '}
                {item.qty.toLocaleString('ru-RU')}
            </TypographyCaption>
        </Space>
    ), [topic.type])

    return (
        <Wrappers.Card onClick={navigateToSummary}>
            <Flex vertical gap={'large'}>
                <Flex vertical>
                    <TypographyBody type={'secondary'}>{topic.tribeName}</TypographyBody>
                    <Typography.Title style={titleStyle} level={4}>{topic.factorica}</Typography.Title>
                </Flex>
                <Row justify={'space-between'} align={'middle'}>
                    <Col>
                        <TypographyCaption type={'secondary'}>
                            {topic.type === TopicType.appeal ? `Жалоб: ${topic.qty}` : null}
                            {topic.type === TopicType.consultation ? `Консультаций: ${topic.qty}` : null}
                        </TypographyCaption>
                    </Col>
                    <Col>
                        <Space>
                            <TypographyCaption type={'secondary'}>
                                <PercentView value={statisticDelta} arrow fractional />
                            </TypographyCaption>
                            <Charts.Sparkline<TopicStatistic>
                                data={topic.statistic || []}
                                yField={'qty'}
                                tooltip={sparklineTooltip}
                                chardId={'topicCard'}
                                inverted
                            />
                        </Space>
                    </Col>
                </Row>
            </Flex>
        </Wrappers.Card>
    )
}
