import { Col, Divider, Flex, Row, Space, Tag } from 'antd'
import type { FC } from 'react'
import React, { useEffect, useState } from 'react'
import { isDesktop } from 'react-device-detect'

import type { InteractionCaseEntity } from '@shared/api/interactionCases'
import { getInteractionCase } from '@shared/api/interactionCases'
import { SharedButton } from '@shared/components/SharedButton'
import { SystemDialog } from '@shared/components/SystemDialog'
import { TypographyBody , TypographyCaption, TypographyTitle1 } from '@shared/components/typography'
import { dateToUIFormat } from '@shared/utils/formatting'

import styles from '../CommentCard/styles.module.scss'

interface SummaryInfoProps {
    summaryAppRowId: string,
    summaryText: string | null,
    isInfoVisible: boolean,
    changeInfoVisible: () => void,
    filtersStr: string,
}

export const SummaryInfo:FC<SummaryInfoProps> = (
    { summaryAppRowId, summaryText, isInfoVisible, changeInfoVisible, filtersStr }
) => {
    const [interaction, setInteraction] = useState<InteractionCaseEntity>()

    useEffect(() => {
        if (isInfoVisible) {
            getInteractionCase(summaryAppRowId)
                .then(response => { setInteraction(response.data) })
        }
    }, [isInfoVisible])

    return (
        <SystemDialog
            open={isInfoVisible}
            onClose={changeInfoVisible}
            modalWidth={1032}
            footer={false}
            drawerHeight={'auto'}
            isDataLoaded={!!interaction}
        >
            <Flex align={'start'}>
                {isDesktop &&
                    <Row gutter={[8, 8]} style={{ rowGap: '0', width: '639px' }} justify={'start'}>
                        <Col span={24} style={{ marginBottom: '8px', height: '40px' }}>
                            <Flex justify={'space-between'} align={'start'} gap={'large'}>
                                <Tag />
                                <SharedButton filtersStr={filtersStr}/>
                            </Flex>
                        </Col>
                        <Col span={24}>
                            <TypographyBody className={styles.modalComment}>
                                {summaryText}
                            </TypographyBody>
                        </Col>
                    </Row>
                }
                {isDesktop &&
                    <Divider
                        type={'vertical'}
                        style={{ height: 'auto', alignSelf:'stretch', margin: '0 24px 0 48px' }}
                    />}
                <Flex vertical gap={'middle'} style={{ paddingBottom: '10px' }}>
                    <Space direction={'vertical'} className={styles.rowDetails}>
                        <TypographyCaption type={'secondary'}>Трайб</TypographyCaption>
                        <TypographyTitle1>{interaction?.tribeName}</TypographyTitle1>
                    </Space>
                    <Space direction={'vertical'} className={styles.rowDetails}>
                        <TypographyCaption type={'secondary'}>Продукт</TypographyCaption>
                        <TypographyTitle1>{interaction?.productName}</TypographyTitle1>
                    </Space>
                    <Space direction={'vertical'} className={styles.rowDetails}>
                        <TypographyCaption type={'secondary'}>
                            Подпродукт
                        </TypographyCaption>
                        <TypographyTitle1>{interaction?.subProductName}</TypographyTitle1>
                    </Space>
                    <Space direction={'vertical'} className={styles.rowDetails}>
                        <TypographyCaption type={'secondary'}>Канал</TypographyCaption>
                        <TypographyTitle1>{interaction?.channelName}</TypographyTitle1>
                    </Space>
                    <Space direction={'vertical'} className={styles.rowDetails}>
                        <TypographyCaption type={'secondary'}>Тематика</TypographyCaption>
                        <TypographyTitle1>{interaction?.subjectName}</TypographyTitle1>
                    </Space>
                    <Space direction={'vertical'} className={styles.rowDetails}>
                        <TypographyCaption type={'secondary'}>Подтематика</TypographyCaption>
                        <TypographyTitle1>{interaction?.subSubjectName}</TypographyTitle1>
                    </Space>
                    <Space direction={'vertical'} className={styles.rowDetails}>
                        <TypographyCaption type={'secondary'}>ID обращения</TypographyCaption>
                        <TypographyTitle1>{interaction?.reqNum}</TypographyTitle1>
                    </Space>
                    <Space direction={'vertical'} className={styles.rowDetails}>
                        <TypographyCaption type={'secondary'}>Дата создания</TypographyCaption>
                        <TypographyTitle1>
                            {dateToUIFormat(interaction?.reqCreated)}
                        </TypographyTitle1>
                    </Space>
                </Flex>
            </Flex>
        </SystemDialog>
    )
}
