import { Col, Flex, Row } from 'antd'
import clsx from 'clsx'
import dayjs from 'dayjs'
import type { FC } from 'react'
import React, { useState } from 'react'
import { isDesktop } from 'react-device-detect'

import type { SummaryContent } from '@shared/api/summaries'
import { SharedButton } from '@shared/components/SharedButton'
import { TypographyBodyParagraph , TypographyBody, TypographyCaption } from '@shared/components/typography'
import { helperStyles } from '@shared/styles'

import styles from '../CommentCard/styles.module.scss'

import { SummaryInfo } from './SummaryInfo'

interface SummaryCardProps {
    summary: SummaryContent;
    appealType?: string;
    isShowProductName?: boolean;
}

const isEmptyValue = (value: string | null) => value == null || value.trim() === ''

const getExpandedSymbol = (expanded) => {
    if (!expanded || isDesktop) {
        return (<TypographyBody
            className={styles.moreText}
        >
            ещё
        </TypographyBody>)
    }
    return null
}

const getSummaryCardLink = (summaryId: string, summaryDate: string, appealType: string) => {
    const startDate = dayjs(summaryDate).format('YYYY-MM-DD')
    const tail = `&startDate=${startDate}&endDate=${startDate}&appealType=${appealType}`

    return `summary?summaryId=${summaryId}${tail}`
}

export const SummaryCard:FC<SummaryCardProps> = ({ summary, appealType, isShowProductName = false }) => {
    const [isInfoVisible, setIsInfoVisible] = useState(false)
    const [isExpanded, setIsExpanded] = useState(false)
    const summaryText = isEmptyValue(summary.msgSumm) ? 'Данные отсутствуют' : summary.msgSumm

    function changeInfoVisible () {
        setIsInfoVisible(!isInfoVisible)
    }

    const expandOrShowModal = () => {
        if (isDesktop) {
            changeInfoVisible()
        } else {
            setIsExpanded(!isExpanded)
        }
    }

    const onExpandHandler = (_, info) => {
        if (!isDesktop) {
            setIsExpanded(info.expanded)
        }
    }

    return (
        <Row
            gutter={[0, 4]}
            justify={'end'}
        >
            <SummaryInfo
                summaryAppRowId={summary.appRowId || ''}
                summaryText={summaryText}
                isInfoVisible={isInfoVisible}
                changeInfoVisible={changeInfoVisible}
                filtersStr={getSummaryCardLink(
                    summary.appRowId || '',
                    summary.appCreated || '',
                    appealType || ''
                )}
            />
            <Col span={24}>
                <div
                    className={ styles.commentCard }
                >
                    <Row
                        gutter={[8, 8]}
                        style={{ rowGap: '0' }}
                    >
                        <Col span={24} style={{ marginBottom: '8px' }}>
                            <Flex justify={'space-between'}>
                                <Flex align={'center'} gap={16}>
                                    <TypographyCaption type={'secondary'} style={{ fontSize: '14px' }}>
                                        {dayjs(summary.appCreated ?? 'Дата неизвестна').format('DD MMMM YYYY')}
                                    </TypographyCaption>
                                </Flex>
                                <Flex align={'center'}>
                                    <SharedButton filtersStr={
                                        getSummaryCardLink(
                                            summary.appRowId || '',
                                            summary.appCreated || '',
                                            appealType || ''
                                        )}
                                    />
                                </Flex>
                            </Flex>
                        </Col>
                        {
                            isShowProductName &&
                            <Col
                                className={helperStyles.cursorPointer}
                                span={24}
                                onClick={expandOrShowModal}
                            >
                                <TypographyBody
                                    fontWeight={'500'}
                                    className={clsx(
                                        helperStyles.ellipsisOneLine,
                                        helperStyles.fullWidth,
                                    )}
                                >
                                    {summary.productName}
                                </TypographyBody>
                            </Col>
                        }
                        <Col
                            span={24}
                            className={helperStyles.cursorPointer}
                            onClick={expandOrShowModal}
                        >
                            <TypographyBodyParagraph
                                className={styles.commentBody}
                                ellipsis={{
                                    rows: 2,
                                    expandable: 'collapsible',
                                    symbol: getExpandedSymbol,
                                    expanded: isDesktop ? false : isExpanded,
                                    onExpand: onExpandHandler
                                }}
                            >
                                {summaryText}
                            </TypographyBodyParagraph>
                        </Col>
                    </Row>
                </div>
            </Col>
        </Row>
    )
}
