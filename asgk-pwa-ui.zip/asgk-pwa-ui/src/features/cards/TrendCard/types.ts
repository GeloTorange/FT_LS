import type { URLSearchParamsInit } from 'react-router-dom'

import type { TrendInfo, TrendTypes } from '@shared/api/trends'

export type TrendCardProps = Pick<TrendInfo,
    'id' | 'chartData' | 'trendRatioPct' | 'trendRatioPctIncr' | 'createdAt'
> &
    {
        isListView?: boolean,
        description?: string,
        title: string,
        isFavorite: boolean,
        loadData: () => void,
        navigatePageSearchParams?: URLSearchParamsInit | null,
        trendType: TrendTypes,
    }
