import { Row, Col, Flex, Space, Badge } from 'antd'
import dayjs from 'dayjs'
import React, { useCallback } from 'react'
import { createSearchParams, useNavigate } from 'react-router-dom'

// TODO: передавать график через пропсы
import { Charts } from '@features/charts'
import { isNewTrend } from '@entities/trends'
import type { TrendChartData } from '@shared/api/trends'
import { Tags } from '@shared/components/tags'
import { TitleForTriggerAndTrendCard } from '@shared/components/TitleForTriggerAndTrendCard'
import { TypographyCaption } from '@shared/components/typography'
import { Wrappers } from '@shared/components/wrappers'
import { useGetCSSVar } from '@shared/styles'
import { PAGE_ROUTES } from '@shared/system/router'
import type { OnClickEvent } from '@shared/types/handlers'
import { ListingTypes } from '@shared/types/listingTypes'
import { clickFavorite, getViewCSIIncrPct } from '@shared/utils/CSI'
import { DATE_FORMAT } from '@shared/utils/defaultDatesHelper'

import type { TrendCardProps } from './types'


const TYPE = ListingTypes.TREND

export const TrendCard = ({
    isListView,
    id,
    description,
    title,
    isFavorite,
    loadData,
    chartData,
    navigatePageSearchParams,
    trendType,
    trendRatioPct,
    trendRatioPctIncr,
    createdAt,
}: TrendCardProps) => {
    const navigate = useNavigate()
    const onNavigate = () => {
        navigate({
            pathname: `${PAGE_ROUTES.TRENDS}/${id}`,
            search: createSearchParams(navigatePageSearchParams || {}).toString(),
        })
    }

    const onClickFavorite: OnClickEvent = useCallback(
        (e) => { clickFavorite({ id, isFavorite, type: TYPE, loadData })(e) },
        [id, isFavorite, loadData]
    )

    const configColors = {
        yellow: useGetCSSVar('--LineYellow'),
    }

    const sparklineTooltip = useCallback((item: TrendChartData) => (
        <Space direction={'vertical'} size={0}>
            <TypographyCaption style={{ color: 'var(--TextSecondary)' }}>
                {dayjs(item.date).format(DATE_FORMAT.FRONTEND)}
            </TypographyCaption>
            <TypographyCaption>
                {`Доля: ${item?.trendRatioPct?.toLocaleString('ru-RU')}%`}
            </TypographyCaption>
        </Space>
    ), [])

    return (
        <Badge
            dot={isNewTrend(createdAt)}
            offset={[-4, 4]}
            color={configColors.yellow}
            styles={{ root: { width: '100%' }}}
            style={{ width: 12, height: 12 }}
        >
            <Wrappers.Card
                isListView={isListView}
                onClick={onNavigate}
            >
                <Row
                    style={{ height: '100%', alignContent: 'space-between' }}
                    gutter={[0, 12]}
                >
                    <Col span={24}>
                        <TitleForTriggerAndTrendCard
                            clickFavorite={onClickFavorite}
                            title={title}
                            description={description}
                            isFavorite={isFavorite}
                        />
                    </Col>
                    <Col span={24}>
                        <Flex justify={'space-between'} align={'flex-end'}>
                            <Tags.Influence isFractions value={trendRatioPct} trendType={trendType}/>
                            {
                                chartData.length > 0
                                    ? <>
                                        <TypographyCaption
                                            type={'secondary'}
                                            style={{ marginLeft: 'auto', marginRight: '9px' }}
                                        >
                                            {getViewCSIIncrPct(trendRatioPctIncr, true)}
                                        </TypographyCaption>
                                        <Charts.Sparkline<TrendChartData>
                                            data={chartData}
                                            yField={'trendRatioPct'}
                                            tooltip={sparklineTooltip}
                                            inverted
                                            chardId={'trendCard'}
                                        />
                                    </>
                                    : <TypographyCaption type={'secondary'}>нет данных</TypographyCaption>
                            }
                        </Flex>
                    </Col>
                </Row>
            </Wrappers.Card>
        </Badge>
    )
}
