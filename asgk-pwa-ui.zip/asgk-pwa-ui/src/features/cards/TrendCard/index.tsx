export { TrendCard } from './TrendCard'
// TODO: он не должен экспортироваться, надо сделать общий тип
export type { TrendCardProps } from './types'
