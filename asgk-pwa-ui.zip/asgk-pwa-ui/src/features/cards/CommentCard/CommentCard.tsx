import { Row, Col, Flex, Button } from 'antd'
import clsx from 'clsx'
import dayjs from 'dayjs'
import React, { useState } from 'react'
import { isDesktop } from 'react-device-detect'

import { Info } from '@shared/assets/icons'
import { SharedButton } from '@shared/components/SharedButton'
import { Tags } from '@shared/components/tags'
import {
    TypographyBody,
    TypographyCaption, TypographyBodyParagraph,
} from '@shared/components/typography'
import { useGetCommentLink } from '@shared/hooks/comment'
import { helperStyles, iconColorsStyles } from '@shared/styles'

import { CommentDetails } from './CommentDetails'
import styles from './styles.module.scss'


export type CommentCardProps = {
    mark: number,
    comment: string,
    date: string,
    commentId: string,
    cmId: string,
    productName: string,
}

export const CommentCard = ({
    mark,
    comment,
    date,
    commentId,
    cmId,
    productName,
}: CommentCardProps) => {
    const [isInfoVisible, setIsInfoVisible] = useState(false)
    const [isExpanded, setIsExpanded] = useState(false)
    const commentLink = useGetCommentLink(cmId)

    const changeInfoVisible = () => {
        setIsInfoVisible(!isInfoVisible)
    }

    const expandOrShowModal = () => {
        if (isDesktop) {
            changeInfoVisible()
        } else {
            setIsExpanded(!isExpanded)
        }
    }
    return (
        <Row gutter={[0, 4]} justify={'end'}>
            <CommentDetails
                mark={mark}
                comment={comment}
                commentId={commentId}
                cmId={cmId}
                isInfoVisible={isInfoVisible}
                changeInfoVisible={changeInfoVisible}
            />
            <Col
                span={24}
            >
                <div className={styles.commentCard}>
                    <Row gutter={[8, 8]} style={{ rowGap: '0' }}>
                        <Col span={24} style={{ marginBottom: '8px' }}>
                            <Flex justify={'space-between'} align={'center'}>
                                <Flex align={'center'} gap={16}>
                                    <Tags.Comment mark={mark} />
                                    <TypographyCaption type={'secondary'} style={{ fontSize: '14px' }}>
                                        {dayjs(date).format('DD MMMM YYYY')}
                                    </TypographyCaption>
                                </Flex>
                                <Flex align={'center'}>
                                    <SharedButton filtersStr={commentLink} />
                                    {!isDesktop &&
                                        <Button
                                            type={'text'}
                                            className={styles.butt}
                                            icon={<Info
                                                onClick={changeInfoVisible}
                                                className={clsx(
                                                    styles.info,
                                                    iconColorsStyles.colorIconSecondary,
                                                )}
                                            />}
                                        />

                                    }
                                </Flex>
                            </Flex>
                        </Col>
                        <Col
                            className={styles.cursorStyle}
                            span={24}
                            onClick={expandOrShowModal}
                        >
                            <TypographyBody
                                fontWeight={'500'}
                                className={clsx(
                                    helperStyles.ellipsisOneLine,
                                    helperStyles.fullWidth,
                                )}
                            >
                                {productName}
                            </TypographyBody>
                        </Col>
                        <Col
                            className={styles.cursorStyle}
                            span={24}
                            onClick={expandOrShowModal}
                        >
                            <TypographyBodyParagraph
                                className={styles.commentBody}
                                ellipsis={{
                                    rows: 2,
                                    expandable: 'collapsible',
                                    symbol: (expanded) => {
                                        if (!expanded || isDesktop) {
                                            return (<TypographyBody
                                                className={styles.moreText}
                                            >
                                                ещё
                                            </TypographyBody>)
                                        }
                                        return null
                                    },
                                    expanded: isDesktop ? false : isExpanded,
                                    onExpand: (_, info) => {
                                        if (!isDesktop) {
                                            setIsExpanded(info.expanded)
                                        }
                                    }
                                }}
                            >
                                {comment}
                            </TypographyBodyParagraph>
                        </Col>
                    </Row>
                </div>
            </Col>
        </Row>
    )
}
