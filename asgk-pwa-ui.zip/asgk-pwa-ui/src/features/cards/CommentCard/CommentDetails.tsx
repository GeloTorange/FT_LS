import { Col, Flex, Row, Space } from 'antd'
import React, { useEffect, useState } from 'react'
import { isDesktop } from 'react-device-detect'

import type { CommentDetailsData } from '@shared/api/comments'
import { getCommentInfo } from '@shared/api/comments'
import { SharedButton } from '@shared/components/SharedButton'
import { SystemDialog } from '@shared/components/SystemDialog'
import { Tags } from '@shared/components/tags'
import {
    TypographyBody, TypographyTitle2,
} from '@shared/components/typography'
import { useGetCommentLink } from '@shared/hooks/comment'
import { dateToUIFormat, formattingVersion } from '@shared/utils/formatting'


import styles from './styles.module.scss'

export type CommentDetailsProps = {
    commentId: string,
    cmId: string,
    isInfoVisible: boolean,
    changeInfoVisible: () => void,
    comment?: string,
    mark?: number,
}

export const CommentDetails: React.FC<CommentDetailsProps> = ({
    commentId,
    cmId,
    isInfoVisible,
    changeInfoVisible,
    comment,
    mark,
}) => {
    const commId = commentId
    const [dataSource, setDataSource] = useState<CommentDetailsData>()
    const commentLink = useGetCommentLink(cmId)

    useEffect(() => {
        if (isInfoVisible) {
            getCommentInfo({ cmId, commId }).then((response) => {
                setDataSource(response.data)
            })
        }
    }, [isInfoVisible])

    return (
        <SystemDialog
            open={isInfoVisible}
            onClose={changeInfoVisible}
            modalWidth={1032}
            footer={false}
            drawerHeight={'auto'}
            isDataLoaded={!!dataSource}
        >
            <Row>
                {isDesktop && <Col span={16} className={styles.fakeDivider}>
                    <Row gutter={[8, 8]} justify={'start'}>
                        <Col span={24} style={{ marginBottom: '8px', height: '40px' }}>
                            <Flex justify={'space-between'} align={'start'} gap={'large'}>
                                <Tags.Details mark={mark || 0} />
                                <SharedButton filtersStr={commentLink} />
                            </Flex>
                        </Col>
                        <Col span={24}>
                            <TypographyTitle2 className={styles.modalComment}>
                                {comment}
                            </TypographyTitle2>
                        </Col>
                    </Row>
                </Col>}
                <Col span={isDesktop ? 7 : 24} style={{ marginLeft: isDesktop ? '24px' : '0' }}>
                    <Flex vertical gap={'middle'} style={{ paddingBottom: '10px' }}>
                        <Space direction={'vertical'} className={styles.rowDetails}>
                            <TypographyBody type={'secondary'}>Трайб</TypographyBody>
                            <TypographyBody>{dataSource?.tribeName}</TypographyBody>
                        </Space>
                        <Space direction={'vertical'} className={styles.rowDetails}>
                            <TypographyBody type={'secondary'}>Продукт</TypographyBody>
                            <TypographyBody>{dataSource?.productName}</TypographyBody>
                        </Space>
                        <Space direction={'vertical'} className={styles.rowDetails}>
                            <TypographyBody type={'secondary'}>
                                Название опроса
                            </TypographyBody>
                            <TypographyBody>{dataSource?.triggerName}</TypographyBody>
                        </Space>
                        <Space direction={'vertical'} className={styles.rowDetails}>
                            <TypographyBody type={'secondary'}>Вопрос</TypographyBody>
                            <TypographyBody>{dataSource?.question}</TypographyBody>
                        </Space>
                        <Flex>
                            <Space
                                direction={'vertical'}
                                className={styles.rowDetailsInGroup}
                            >
                                <TypographyBody type={'secondary'}>ID опроса</TypographyBody>
                                <TypographyBody>{dataSource?.triggerId}</TypographyBody>
                            </Space>
                            <Space
                                direction={'vertical'}
                                className={styles.rowDetailsInGroup}
                            >
                                <TypographyBody type={'secondary'}>ID комментария</TypographyBody>
                                <TypographyBody>{dataSource?.cmId}</TypographyBody>
                            </Space>
                        </Flex>
                        <Flex>
                            <Space
                                direction={'vertical'}
                                className={styles.rowDetailsInGroup}
                            >
                                <TypographyBody type={'secondary'}>
                                    Дата события
                                </TypographyBody>
                                <TypographyBody>
                                    {dateToUIFormat(dataSource?.eventDate)}
                                </TypographyBody>
                            </Space>
                            <Space
                                direction={'vertical'}
                                className={styles.rowDetailsInGroup}
                            >
                                <TypographyBody type={'secondary'}>
                                    Дата комментария
                                </TypographyBody>
                                <TypographyBody>
                                    {dateToUIFormat(dataSource?.answerDate)}
                                </TypographyBody>
                            </Space>
                        </Flex>
                        <Flex>
                            <Space
                                direction={'vertical'}
                                className={styles.rowDetailsInGroup}
                            >
                                <TypographyBody type={'secondary'}>
                                    Версия СБОЛ
                                </TypographyBody>
                                <TypographyBody>
                                    {
                                        formattingVersion({
                                            platform: dataSource?.platform,
                                            version: dataSource?.platformVersion
                                        })
                                    }
                                </TypographyBody>
                            </Space>
                        </Flex>
                    </Flex>
                </Col>
            </Row>
        </SystemDialog>
    )
}
