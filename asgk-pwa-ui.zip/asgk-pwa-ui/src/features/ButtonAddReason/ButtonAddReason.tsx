import { QuestionCircleOutlined } from '@ant-design/icons'
import { Button } from 'antd'
import React, { memo } from 'react'

import type { PainScoringChart } from '@shared/api/pains'

import styles from './styles.module.scss'
import { useAddReasonHandler } from './useAddReasonHandler'


export type ButtonAddReasonProps = {
    AKBTotal?: number
    isLoading: boolean
    chartData: PainScoringChart[]
    painId: string
    isShowDetractor: boolean
}
export const ButtonAddReason = memo(({
    AKBTotal, isLoading, chartData, painId, isShowDetractor
}: ButtonAddReasonProps) => {
    const { onClickAddReason } = useAddReasonHandler({ chartData, painId, AKBTotal, isShowDetractor })

    return (
        <Button
            disabled={isLoading}
            data-testid={'buttonAddReason'}
            size={'large'}
            onClick={onClickAddReason}
            icon={<QuestionCircleOutlined className={styles.noDataIconBtn} />}
        >
            Добавить причину
        </Button>
    )
})
