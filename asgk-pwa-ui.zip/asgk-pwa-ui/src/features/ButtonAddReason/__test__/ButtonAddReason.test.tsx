import { ButtonAddReason } from '../'
import { fireEvent } from '@testing-library/react'
import { renderWithStore } from '../../../__testsUtils__/wrapper-testing-library'
import { vi } from 'vitest'

vi.mock('@entities/pain', () => ({
    usePainPageData: () => ({
        chartData: [{
            consultationTotal: 2,
            appealTotal: 3,
            detractorTotal: 4,
        }],
        painId: 1,
        isLoading: false,
    })
}))
vi.mock('@shared/api/reasons', async () => ({
    ...await vi.importActual('@shared/api/reasons'),
    useGetReasonListQuery: () => ({
        data: { AKB: 123 },
        isFetching: false,
    })
}))

describe('ButtonAddReason', () => {
    it('рендер ButtonAddReason', () => {
        const { getByTestId } = renderWithStore(
            <ButtonAddReason
                painId={'123'}
                chartData={[{
                    date: '11-11-2011',
                    consultationTotal: 12,
                    appealTotal: 12,
                    detractorTotal: 23,
                    score: 43
                }]}
                isLoading={false}
            />
        )

        const btn = getByTestId('buttonAddReason')
        fireEvent.click(btn)

        expect(btn).toBeInTheDocument()
    })
})
