import { useDispatch } from 'react-redux'

import { setCreateReasonForModal, setIsShowModalReason } from '@entities/workspacePain'

import type { ButtonAddReasonProps } from './ButtonAddReason'

export const useAddReasonHandler = ({
    chartData,
    painId,
    AKBTotal,
    isShowDetractor,
}: Omit<ButtonAddReasonProps, 'isLoading'>) => {
    const dispatch = useDispatch()

    const onClickAddReason = () => {
        const lastMonthData = chartData[chartData.length - 1]
        dispatch(setIsShowModalReason())
        dispatch(setCreateReasonForModal({
            reasonData: {
                painId: Number(painId),
                consultationTotal: lastMonthData.consultationTotal,
                appealTotal: lastMonthData.appealTotal,
                detractorTotal: lastMonthData.detractorTotal,
                AKBTotal,
            },
            isShowDetractor,
        }))
    }

    return { onClickAddReason }
}
