import React, { memo, type ReactNode } from 'react'

import { ModalFooterDefault, SystemDialog } from '@shared/components/SystemDialog'
import { TypographyBody, TypographyTitle1 } from '@shared/components/typography'

export type ConfirmCloseModalProps = {
    open: boolean
    onBackToEdit: () => void
    onCloseWithoutSave: () => void
    title?: ReactNode
    content?: ReactNode
    firstButtonLabel?: string
    secondButtonLabel?: string
}

export const ConfirmCloseModal = memo(({
    open,
    onBackToEdit,
    onCloseWithoutSave,
    title = 'Закрыть без сохранения?',
    content = 'Если вы закроете это окно, все внесённые данные будут утеряны.',
    firstButtonLabel = 'Вернуться к редактированию',
    secondButtonLabel = 'Закрыть без сохранения',
}: ConfirmCloseModalProps) => (
    <SystemDialog
        modalWidth={572}
        open={open}
        onClose={onCloseWithoutSave}
        centered
        title={<TypographyTitle1 strong>{title}</TypographyTitle1>}
        footer={
            <ModalFooterDefault
                onCancel={onBackToEdit}
                onApply={onCloseWithoutSave}
                firstButtonLabel={firstButtonLabel}
                secondButtonLabel={secondButtonLabel}
            />
        }
        closable
    >
        <TypographyBody
            style={{
                marginTop: '20px',
                marginBottom: '28px',
                display: 'block',
            }}
        >
            {content}
        </TypographyBody>
    </SystemDialog>
))
