import { Row } from 'antd'
import React, { memo, useCallback, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'

import {
    setNextLocation,
    changeSaveModalVisibility,
    getNextLocation,
    getIsSaveModalVisible,
} from '@entities/saveModal'
import { ModalFooterDefault, SystemDialog } from '@shared/components/SystemDialog'
import { TypographyBody, TypographyTitle1 } from '@shared/components/typography'
import { customHistory } from '@shared/system/router'

import styles from './styles.module.scss'

type Props = {
    shouldBlock: boolean,
    onSave?: () => void,
    isShow?: boolean,
}

export const SaveModal = memo(({
    onSave,
    shouldBlock,
    isShow
}: Props) => {
    const dispatch = useDispatch()

    const isVisible = useSelector(getIsSaveModalVisible)
    const nextLocation = useSelector(getNextLocation)

    const navigate = useNavigate()

    useEffect(() => {
        if (!shouldBlock || isVisible) return () => {}

        // Блокировка внутренней навигации
        const unblock = customHistory.block((tx) => {
            dispatch(changeSaveModalVisibility(true))
            dispatch(setNextLocation(tx.location.pathname))
        })

        return () => {
            unblock()
        }
    }, [shouldBlock, isVisible, dispatch])

    const close = () => {
        dispatch(changeSaveModalVisibility(false))
    }

    const navigateCallback = useCallback(() => {
        navigate({
            pathname: nextLocation
        })
    }, [navigate, nextLocation])

    const onClick = (saveClick = false) => () => {
        if (saveClick && onSave) {
            onSave()
        }
        close()
        navigateCallback()
    }

    return (
        <SystemDialog
            modalWidth={475}
            open={isShow || isVisible}
            onClose={close}
            centered
            title={
                <TypographyTitle1 strong >
                    Сохранить внесённые изменения?
                </TypographyTitle1>
            }
            footer={
                <ModalFooterDefault
                    onCancel={onClick()}
                    onApply={onClick(true)}
                    firstButtonLabel={'Не сохранять'}
                    secondButtonLabel={'Сохранить'}
                />
            }
        >
            <Row
                className={styles.row}
            >
                <TypographyBody>
                    Если вы не сохраните изменения, они будут утеряны.
                </TypographyBody>
            </Row>
        </SystemDialog>
    )
})
