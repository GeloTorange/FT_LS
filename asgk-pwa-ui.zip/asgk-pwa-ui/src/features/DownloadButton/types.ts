import type { ReactNode } from 'react'

export type DownloadButtonProps = {
    iconComponent?: ReactNode
    texts: {
        inButton: string
        validation?: string
        timer?: string
    }
    // все данные для запроса по клику готовы - валидны
    isValid?: boolean
    maxWidthOverlay?: string
    onClick: () => void
    // время до разблокировки в секундах с бэка
    secondsFromBackend?: number
    // хэндлер для запуска при финише таймера
    onFinishTimer?: () => void
    localStorageName?: string
}
