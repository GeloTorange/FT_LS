import { DownloadOutlined } from '@ant-design/icons'
import { Button, Tooltip } from 'antd'
import { useMemo, useState } from 'react'

import { TypographyBody, TypographyCaption } from '@shared/components/typography'

import { useSaveInLocalStorage, useSetInitialSeconds, useTimerControl } from './hooks'
import { TimerText } from './TimerText'
import type { DownloadButtonProps } from './types'

// Кнопка для скачивания файла (на ветке CV-5950-universal
// есть версия с более универсальным решением, но нужно доработать под конкретные кейсы)
export const DownloadButton = ({
    iconComponent,
    texts,
    isValid,
    maxWidthOverlay,
    onClick,
    secondsFromBackend,
    onFinishTimer,
    localStorageName,
}: DownloadButtonProps) => {
    const [seconds, setSeconds] = useState(secondsFromBackend)

    // Устанавливаем начальное значение
    useSetInitialSeconds({
        setSeconds,
        secondsFromBackend,
        secondsState: seconds,
        localStorageName,
    })
    // Сохраняем секунды, если они есть, в localStorage при уходе со страницы
    useSaveInLocalStorage({
        seconds,
        localStorageName,
    })
    // Все что касается работы таймера
    useTimerControl({
        seconds,
        setSeconds,
        onFinishTimer,
    })

    // Возвращает текст в зависимости от состояния
    const tooltipTitle = useMemo(() => {
        if (isValid) {
            if (!seconds) {
                return null
            }

            return (
                texts.timer && seconds ?
                    <>
                        {texts.timer}&nbsp;
                        <TimerText seconds={seconds} />
                    </> : null
            )
        }
        return texts.validation
    }, [isValid, texts.validation, texts.timer, seconds])

    return (
        <Tooltip
            forceRender
            placement={'bottom'}
            title={tooltipTitle ? <TypographyCaption>{tooltipTitle}</TypographyCaption> : null}
            styles={{
                root: {
                    maxWidth: maxWidthOverlay || 'auto',
                    borderRadius: '12px'
                },
                body: {
                    padding: '12px 16px'
                }
            }}
        >
            <Button
                disabled={!isValid || !!seconds}
                icon={iconComponent || <DownloadOutlined />}
                size={'large'}
                onClick={onClick}
            >
                <TypographyBody>
                    {texts.inButton}
                </TypographyBody>
            </Button>
        </Tooltip>
    )
}
