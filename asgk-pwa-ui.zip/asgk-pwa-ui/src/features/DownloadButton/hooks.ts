import { type Dispatch, type SetStateAction, useCallback, useEffect, useRef } from 'react'

export type UseGetInitialSecondProps = {
    setSeconds: (sec?: number) => void
    secondsState?: number
    secondsFromBackend?: number,
    localStorageName?: string
}
// Устанавливает значение в секундах таймера данными с бэка или из localStorage
export const useSetInitialSeconds = ({
    setSeconds,
    secondsState,
    secondsFromBackend,
    localStorageName = '',
}: UseGetInitialSecondProps) => {
    // Достаем из localStorage и вычисляем относительно текущего времени
    const getSecondsFromStorage = () => {
        if (!localStorageName) return undefined

        const timeData = localStorage.getItem(localStorageName)?.split('_')
        const snapshotTime = Number(timeData?.[0])
        const oldSeconds = Number(timeData?.[1])
        // Если время есть и записано корректно
        if (timeData && !isNaN(snapshotTime) && !isNaN(Number(oldSeconds))) {
            // Достаем текущее время в секундах
            const timeSecNow = Math.floor(Date.now() / 1000)

            if (timeSecNow - Number(snapshotTime) > 0) {
                // Вычисляем разницу между слепками
                const differenceTime = timeSecNow - Number(snapshotTime)
                // отнимаем сколько успело пройти от таймера, что сохранили
                return oldSeconds - differenceTime
            }
        }
        return undefined
    }

    const removeLocalStorageTime = () => {
        localStorage.removeItem(localStorageName)
    }

    // Синхронизация таймер с бэка и локального
    useEffect(() => {
        const secondsFromStorage = getSecondsFromStorage()

        // если время из localStorage актуальнее
        if (secondsFromStorage && secondsFromStorage > 0 && secondsState !== secondsFromStorage) {
            setSeconds(secondsFromStorage)
            removeLocalStorageTime()
            // Если время из бэка актуальнее
        } else if (secondsState !== secondsFromBackend) {
            setSeconds(secondsFromBackend)
        }
        // comment: важно чтобы только на secondsFromBackend реагировал
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [secondsFromBackend])
}

type UseSaveInLocalStorageProps = {
    seconds?: number
    localStorageName?: string
}
// Сохраняем секунды, если они есть, в localStorage при уходе со страницы
export const useSaveInLocalStorage = ({
    seconds,
    localStorageName,
}: UseSaveInLocalStorageProps) => {
    // Сохранение в стор секунд, если остались
    const setTimeForStorage = () => {
        if (seconds && localStorageName) {
            const timeSecNow = Math.floor(Date.now() / 1000)
            localStorage.setItem(localStorageName, `${timeSecNow}_${seconds}`)
        }
    }

    window.addEventListener('unload', () => {
        setTimeForStorage()
    })

    useEffect(() => {
        window.addEventListener('unload', () => { setTimeForStorage() })

        return () => {
            // возможно тут есть рассинхрон с пром версией из-за двойного рендера в StrictMode
            setTimeForStorage()
        }
    }, [seconds])

    useEffect(() => () => {
        window.removeEventListener('unload', () => { setTimeForStorage() })
    }, [])
}
type UseTimerControlProps = {
    onFinishTimer?: () => void
    seconds?: number
    setSeconds: Dispatch<SetStateAction<number | undefined>>
}
export const useTimerControl = ({
    onFinishTimer,
    seconds,
    setSeconds,
}: UseTimerControlProps) => {
    const timeoutId = useRef<NodeJS.Timeout>()

    const onFinishTimerLocal = useCallback(() => {
        onFinishTimer?.()
    }, [onFinishTimer])

    // Дергаем таймаут по секунде
    useEffect(() => {
        if (seconds && seconds > 0) {
            timeoutId.current = setTimeout(() => { setSeconds(seconds - 1) }, 1000)
        }
    }, [seconds])
    // Очищаем таймаут на всякий
    useEffect(() => () => {
        clearTimeout(timeoutId.current)
    }, [])

    // Сбрасываем состояния, когда таймер закончился
    useEffect(() => {
        if (seconds !== undefined && seconds <= 0) {
            onFinishTimerLocal()
            setSeconds(undefined)
            clearTimeout(timeoutId.current)
        }
    }, [onFinishTimerLocal, seconds])
}
