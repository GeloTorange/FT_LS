import React from 'react'
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import { act } from 'react'
import { DownloadButton } from '../DownloadButton'

// Упростим типографику и TimerText для предсказуемого DOM
vi.mock('@shared/components/typography', () => ({
    TypographyBody: ({ children }: { children: React.ReactNode }) => <span>{children}</span>,
    TypographyCaption: ({ children }: { children: React.ReactNode }) => <span>{children}</span>,
}))

describe('DownloadButton (component)', () => {
    const texts = {
        inButton: 'Скачать',
        timer: 'Повторно через',
        validation: 'Некорректно',
    }

    beforeEach(() => {
        vi.useFakeTimers()
        localStorage.clear()
    })

    afterEach(() => {
        vi.useRealTimers()
        vi.restoreAllMocks()
        localStorage.clear()
    })

    it('кнопка дизейблится при невалидной форме', () => {
        render(
            <DownloadButton
                texts={texts}
                isValid={false}
                onClick={vi.fn()}
                secondsFromBackend={undefined}
                onFinishTimer={vi.fn()}
                localStorageName={undefined}
            />,
        )

        const btn = screen.getByRole('button', { name: /скачать/i })
        expect(btn).toBeDisabled()
    })

    it('кнопка активна и вызывает onClick, когда форма валидна и таймера нет', () => {
        const onClick = vi.fn()
        render(
            <DownloadButton
                texts={texts}
                isValid
                onClick={onClick}
                secondsFromBackend={undefined}
                onFinishTimer={vi.fn()}
                localStorageName={'download_btn_test'}
            />,
        )

        const btn = screen.getByRole('button', { name: /скачать/i })
        expect(btn).not.toBeDisabled()
        fireEvent.click(btn)
        expect(onClick).toHaveBeenCalled()
    })

    it(
        'кнопка неактивна во время таймера и становится активной после его завершения, вызывая onFinishTimer',
        async () => {
            const onFinish = vi.fn()
            render(
                <DownloadButton
                    texts={texts}
                    isValid
                    onClick={vi.fn()}
                    secondsFromBackend={2}
                    onFinishTimer={onFinish}
                    localStorageName={'download_btn_timer'}
                />,
            )

            const btn = screen.getByRole('button', { name: /скачать/i })
            // во время таймера
            expect(btn).toBeDisabled()

            // ждем 2 секунды поэтапно и дожидаемся эффектов
            await act(async () => {
                await vi.advanceTimersByTimeAsync(1000)
            })
            await act(async () => {
                await vi.advanceTimersByTimeAsync(1000)
            })

            // Форсируем прогон эффектов после обновления стейта
            await act(async () => {})

            // Проверяем, что колбэк завершения вызвался и кнопка активна
            expect(onFinish).toHaveBeenCalledTimes(1)
            expect(btn).not.toBeDisabled()
        })
})
