import { renderHook } from '@testing-library/react-hooks'
import { vi, describe, it, expect, beforeEach, afterEach } from 'vitest'
import { useSaveInLocalStorage, useSetInitialSeconds, useTimerControl } from '../hooks'

describe('hooks: DownloadButton', () => {
    const LOCAL_KEY = 'download_timer_test'

    beforeEach(() => {
        localStorage.clear()
        vi.useRealTimers()
    })

    afterEach(() => {
        localStorage.clear()
        vi.restoreAllMocks()
    })

    describe('useSetInitialSeconds', () => {
        it('должен установить секунды из localStorage, если они актуальнее бэкенда и удалить запись', async () => {
            const nowMs = 1_700_000_000_000
            const nowSec = Math.floor(nowMs / 1000)
            vi.spyOn(Date, 'now').mockReturnValue(nowMs)

            // В сторе сохраним слепок 5 секунд назад, общий таймер был 20 секунд
            const snapshot = `${nowSec - 5}_20`
            localStorage.setItem(LOCAL_KEY, snapshot)

            const setSeconds = vi.fn()

            renderHook(() => {
                useSetInitialSeconds({
                    setSeconds,
                    // текущее состояние отличается от ожидаемого из стора (15)
                    secondsState: 10,
                    secondsFromBackend: 12,
                    localStorageName: LOCAL_KEY,
                })
            },
            )

            // ожидаем 15 секунд (20 - 5 прошедших)
            expect(setSeconds).toHaveBeenCalledWith(15)
            expect(localStorage.getItem(LOCAL_KEY)).toBeNull()
        })

        it('должен установить секунды из бэкенда, если записи в localStorage нет или она неактуальна', () => {
            const setSeconds = vi.fn()

            renderHook(() => {
                useSetInitialSeconds({
                    setSeconds,
                    secondsState: 5,
                    secondsFromBackend: 8,
                    localStorageName: LOCAL_KEY,
                })
            },
            )

            expect(setSeconds).toHaveBeenCalledWith(8)
        })

        it('не должен повторно срабатывать при изменении только secondsState ' +
            '(эффект зависит только от secondsFromBackend)', () => {
            const setSeconds = vi.fn()

            const { rerender } = renderHook(
                (props: { state: number; backend: number }) => {
                    useSetInitialSeconds({
                        setSeconds,
                        secondsState: props.state,
                        secondsFromBackend: props.backend,
                        localStorageName: LOCAL_KEY,
                    })
                },
                { initialProps: { state: 1, backend: 2 }},
            )

            // первый вызов из-за initial backend
            expect(setSeconds).toHaveBeenCalledTimes(1)
            expect(setSeconds).toHaveBeenLastCalledWith(2)

            // меняем только state, backend тот же
            rerender({ state: 3, backend: 2 })
            expect(setSeconds).toHaveBeenCalledTimes(1)

            // меняем backend — должен сработать снова
            rerender({ state: 3, backend: 4 })
            expect(setSeconds).toHaveBeenCalledTimes(2)
            expect(setSeconds).toHaveBeenLastCalledWith(4)
        })
    })

    describe('useSaveInLocalStorage', () => {
        it('должен сохранять секунды в localStorage при событии unload', () => {
            const nowMs = 1_700_000_000_000
            const nowSec = Math.floor(nowMs / 1000)
            vi.spyOn(Date, 'now').mockReturnValue(nowMs)

            renderHook(() => { useSaveInLocalStorage({ seconds: 9, localStorageName: LOCAL_KEY }) },
            )

            // Имитируем уход со страницы
            window.dispatchEvent(new Event('unload'))

            const stored = localStorage.getItem(LOCAL_KEY)
            expect(stored).toBe(`${nowSec}_9`)
        })

        it('должен очищать таймер и сохранять секунды при размонтировании', () => {
            const nowMs = 1_700_000_100_000
            const nowSec = Math.floor(nowMs / 1000)
            vi.spyOn(Date, 'now').mockReturnValue(nowMs)

            const { unmount } = renderHook(() => {
                useSaveInLocalStorage({
                    seconds: 11,
                    localStorageName: LOCAL_KEY,
                })
            })

            unmount()

            expect(localStorage.getItem(LOCAL_KEY)).toBe(`${nowSec}_11`)
        })
    })

    describe('useTimerControl', () => {
        beforeEach(() => {
            vi.useFakeTimers()
        })

        afterEach(() => {
            vi.useRealTimers()
            vi.clearAllTimers()
        })

        it('уменьшает секунды на 1 спустя 1 секунду', async () => {
            const setSeconds = vi.fn()

            renderHook(() => {
                useTimerControl({
                    seconds: 3,
                    setSeconds,
                })
            })

            await vi.advanceTimersByTimeAsync(1000)
            expect(setSeconds).toHaveBeenCalledWith(2)
        })

        it('очищает таймер при размонтировании — после unmount setSeconds не вызывается', async () => {
            const setSeconds = vi.fn()

            const { unmount } = renderHook(() => {
                useTimerControl({
                    seconds: 5,
                    setSeconds,
                })
            })

            // сразу размонтируем и пробуем прокрутить таймеры
            unmount()
            await vi.advanceTimersByTimeAsync(2000)

            expect(setSeconds).not.toHaveBeenCalled()
        })

        it('при seconds <= 0 вызывает onFinishTimer и сбрасывает секунды в undefined', () => {
            const onFinish = vi.fn()
            const setSeconds = vi.fn()

            renderHook(() => {
                useTimerControl({
                    seconds: 0,
                    setSeconds,
                    onFinishTimer: onFinish,
                })
            })

            expect(onFinish).toHaveBeenCalledTimes(1)
            expect(setSeconds).toHaveBeenCalledWith(undefined)
        })
    })
})
