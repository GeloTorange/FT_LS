type TimerTextProps = {
    seconds: number,
}
export const TimerText = ({
    seconds
}: TimerTextProps) => {
    const getTimerText = (c: number) => {
        const minutes = Math.floor(c / 60)
        const secondsTimer = c % 60

        return `${minutes}:${secondsTimer < 10 ? '0' : ''}${secondsTimer}`
    }

    return (
        <span>{
            getTimerText(seconds)
        }</span>
    )
}
