import { TriggersSelect } from './TriggersSelect'

export const Filters = {
    TriggersSelect: TriggersSelect
}
