import type { SelectProps } from 'antd'
import type { DefaultOptionType } from 'antd/es/select'
import { isDesktop } from 'react-device-detect'

import { useGetAllTriggersForFilterQuery } from '@shared/api/triggers'
import { SelectFilterInput } from '@shared/components/formInputs'
import { TypographyBody } from '@shared/components/typography'
import type { AllListParams } from '@shared/types/api'

import styles from './styles.module.scss'

export const filterOption = (input: string, option?: DefaultOptionType) => {
    if (typeof option?.label === 'string' && typeof option?.value === 'string') {
        return Boolean(
            option?.label?.toUpperCase().includes(input.toUpperCase()) ||
                option?.value?.toUpperCase().includes(input.toUpperCase())
        )
    }
    return false
}

export const optionRender = (option: { data: DefaultOptionType }) => (
    <div className={styles.triggerListWrapper}>
        <TypographyBody fontWeight={'500'} type={'secondary'}>
            ID {option.data.value}
        </TypographyBody>
        <TypographyBody fontWeight={'400'}>
            {option.data.label}
        </TypographyBody>
    </div>
)

export type TriggersSelectProps = {
    initialValue?: string | null,
    argForReq?: AllListParams,
    isShowLabel?: boolean,
    disabled?: boolean,
    isSelectFirstOptions?: boolean,
    propsSelect?: SelectProps,
    placeholder?: string,
    name?: string,
    label?: string,
}

export const TriggersSelect = ({
    initialValue = null,
    argForReq = {},
    isShowLabel = true,
    disabled = false,
    isSelectFirstOptions,
    propsSelect,
    placeholder = 'Опрос',
    name = 'triggerId',
    label = 'Опрос'
}: TriggersSelectProps) => (
    <SelectFilterInput
        initialValue={initialValue}
        disabled={disabled}
        name={name}
        argForReq={argForReq}
        useGetData={useGetAllTriggersForFilterQuery}
        placeholder={placeholder}
        label={isShowLabel ? label : undefined}
        minWidthPopup={isDesktop ? '360px' : 'auto'}
        isSelectFirstOptions={isSelectFirstOptions}
        propsSelect={{
            filterOption,
            optionRender,
            ...propsSelect,
        }}
        isOffSort
    />
)
