/// <reference types="react-scripts" />
// Нужно для корректной работы TypeScript
