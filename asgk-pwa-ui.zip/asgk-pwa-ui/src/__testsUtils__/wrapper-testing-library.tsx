import type { queries } from '@testing-library/dom'
import type { RenderResult } from '@testing-library/react'
import { render } from '@testing-library/react'
import type { JSXElementConstructor, PropsWithChildren, ReactElement } from 'react'
import React from 'react'
import { Provider } from 'react-redux'
import { MemoryRouter } from 'react-router-dom'

import { store } from '@app/store'
import type { FilterContextType } from '@shared/types/context'
import {
    UniversalFilterContext,
} from '@shared/utils/context'

// Обертка со стором
export const WrapWithStore = ({ children }: PropsWithChildren): JSX.Element => (
    <Provider store={store}>
        {children}
    </Provider>
)

export const WrapWithStoreAndRouter = ({ children }: PropsWithChildren): JSX.Element => (
    <Provider store={store}>
        <MemoryRouter>
            {children}
        </MemoryRouter>
    </Provider>
)

export const renderWithStore = (
    ui: ReactElement<unknown, string | JSXElementConstructor<unknown>>,
    options?: Record<string, unknown>,
    withRouter = false,
): RenderResult<typeof queries> => render(ui, {
    wrapper: withRouter ? WrapWithStoreAndRouter : WrapWithStore,
    ...options
})

export const WrapWithUniversalContext =
    <T, >(value: T) => ({ children }: PropsWithChildren) => (
        <MemoryRouter>
            <UniversalFilterContext.Provider
            // @ts-expect-error - надо исправлять тип в UniversalFilterContext
                value={value}
            >
                {children}
            </UniversalFilterContext.Provider>
        </MemoryRouter>
    )

export const WrapAllStore = <T extends FilterContextType>(valueFilter: T) =>
    ({ children }: PropsWithChildren) =>
        <Provider store={store}>
            <MemoryRouter>
                <UniversalFilterContext.Provider
                    value={valueFilter}
                >
                    {children}
                </UniversalFilterContext.Provider>
            </MemoryRouter>
        </Provider>
