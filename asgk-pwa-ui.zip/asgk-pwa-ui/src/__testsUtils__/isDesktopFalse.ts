import * as deviceDetect from 'react-device-detect'

export const isDesktopFalse = () => {
    // @ts-expect-error - для теста переопределяем
    deviceDetect.isDesktop = false
}

