export const setConfig = vi.fn()
export const setMeta = vi.fn()
export const setProfile = vi.fn()
export const sendEvent = vi.fn()
