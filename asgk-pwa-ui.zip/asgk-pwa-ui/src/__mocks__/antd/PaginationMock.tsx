import { FC } from "react"

type Props = { onChange: (a: number, b: number) => void }

export const PaginationMock: FC<Props> = (props) => {
    const onPageChange = () => props.onChange(2, 10)
    const onSizeChange = () => props.onChange(1, 20)

    return (
        <div data-testid={'pagination'}>
            <button data-testid={'change-page'} onClick={onPageChange}>Сменить страницу</button>
            <button data-testid={'change-size'} onClick={onSizeChange}>Сменить размер страницы</button>
        </div>
    )
}
