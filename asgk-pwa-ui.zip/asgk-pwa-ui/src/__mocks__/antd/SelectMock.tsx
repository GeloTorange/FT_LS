import type { SelectProps } from 'antd/es/select'
import type { CustomTagProps } from 'rc-select/lib/BaseSelect'
import type { FC } from 'react'
import React from 'react'

// Нужно для того, чтобы дергать колбэки, которые обычно дернуть не можем или сложно
export const SelectMock: FC<SelectProps<number[]>> = ({
    open,
    value,
    onOpenChange,
    tagRender,
    popupRender,
    placeholder,
    classNames,
}) => {
    const onClickOpen = () => onOpenChange?.(!open)

    return (
        <div data-testid={'mock-select'} className={classNames?.root}>
            {/* Симулируем значение */}
            {value && <div data-testid={'select-value'}>{JSON.stringify(value)}</div>}

            {/* Кнопка для открытия/закрытия popup */}
            <button data-testid={'select-trigger'} onClick={onClickOpen}>
                {placeholder}
            </button>

            {/* Popup если открыт */}
            {open && (
                <div data-testid={'select-popup'} className={classNames?.popup?.root}>
                    {popupRender?.(<div>test</div>)}
                </div>
            )}

            {/* Теги */}
            <div data-testid={'select-tags'}>
                {Array.isArray(value) && value.map((val: number, index: number) => {
                    const args = {
                        label: val,
                        value: val,
                        disabled: false,
                        onClose: () => {
                        }
                    } as CustomTagProps
                    return (
                        <span key={val} data-testid={`tag-${val}`}>
                            {tagRender?.(args)}
                            {index < value.length - 1 ? ',' : ''}
                        </span>
                    )
                }
                )}
            </div>
        </div>
    )
}
