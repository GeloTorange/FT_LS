import { DropdownProps } from "antd"
import { FC, useState } from "react"

export const DropdownMock: FC<DropdownProps> = ({
    menu,
    children,
 }) => {
    const [isShow, setIsShow] = useState(false)

    return (
        <div data-testid="mock-dropdown">
            <div
                data-testid="dropdown-trigger"
                onClick={() => {
                    setIsShow(!isShow)
                }}
            >
                {children}
            </div>
            <div data-testid="dropdown-menu">
                {isShow && menu?.items?.map((item) => (
                    <div
                        key={item?.key}
                        data-testid={`menu-item-${item?.key}`}
                        onClick={e => {
                            e.stopPropagation()
                            // @ts-ignore
                            item?.onClick?.(item)
                        }}
                    >
                        {/* @ts-ignore*/}
                        {item?.label}
                    </div>
                ))}
            </div>
        </div>
    )
}
