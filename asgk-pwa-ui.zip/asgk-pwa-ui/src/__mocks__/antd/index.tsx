const antd = require('antd')
import { SelectMock } from './SelectMock'
import { DropdownMock } from './DropdownMock'
import { PaginationMock } from './PaginationMock'

const obj = {
    ...antd,
    Select: SelectMock,
    Dropdown: DropdownMock,
    Pagination: PaginationMock,
}

module.exports = obj
