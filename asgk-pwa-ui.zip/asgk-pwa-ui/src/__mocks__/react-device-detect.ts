const isDesktop = true
const isMobile = false

export { isDesktop, isMobile }
