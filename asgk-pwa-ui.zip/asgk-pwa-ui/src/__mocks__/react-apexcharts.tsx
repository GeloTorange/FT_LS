import React from 'react'

export default () => <div data-testid="graph-mock" />
