import vitest from 'eslint-plugin-vitest'

export const vitestLintConfig = {
    files: ['**/*.spec.ts', '**/*.spec.tsx', '**/*.test.ts', '**/*.test.tsx'],
    plugins: {
        vitest
    },
    rules: {
        ...vitest.configs.recommended.rules,
    },
    languageOptions: {
        globals: {
            ...vitest.environments.env.globals,
        },
    },
}
