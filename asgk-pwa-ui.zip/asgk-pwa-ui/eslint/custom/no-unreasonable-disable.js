const eslintDisableRegExp = /^ ?eslint-disable[\w-]* .+$/
const commentRegExp = /^ ?comment: .{10,}/

const getMessage = (value) => `Inline-конфигурация "${value.trim()}" без комментария к причине отключения,
    Пример правильного использования:
    /* comment: 10+ символов */
    /* ${value.trim()} */`

export const noUnreasonableDisable = {
    meta: {
        docs: {
            description: 'disallow uncommented inline eslint disables',
            category: 'Best Practices',
            recommended: true
        },
        schema: [
            {
                type: 'object',
                properties: {
                    terms: {
                        type: 'array',
                        items: {
                            type: 'string'
                        }
                    },
                    message: {
                        type: 'string'
                    }
                },
                additionalProperties: false
            }
        ]
    },

    create: function (context) {
        const sourceCode = context.getSourceCode()
        function checkComment (comment, index, comments) {
            const ruleDisabled = eslintDisableRegExp.test(comment.value)

            if (ruleDisabled) {
                const previousComment = comments[index - 1]

                let ruleReasonCommented = false

                if (previousComment && (previousComment.loc.end.line + 1 === comment.loc.start.line)) {
                    ruleReasonCommented = commentRegExp.test(previousComment.value)
                }

                if (!ruleReasonCommented) {
                    context.report({
                        node: comment,
                        message: getMessage(comment.value)
                    })
                }
            }
        }

        return {
            Program: function () {
                const comments = sourceCode.getAllComments()

                comments.filter(function (token) {
                    return token.type !== 'Shebang'
                }).forEach(checkComment)
            }
        }
    }
}
