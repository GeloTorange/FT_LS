export const customRules = {
    // Подсветка ф-ий где можно сократить return
    'arrow-body-style': ['error', 'as-needed'],
    '@stylistic/semi': ['error', 'never'],
    '@stylistic/no-extra-semi': 'error',
    // Обеспечить единообразие отступов
    '@stylistic/indent': [
        'warn',
        4,
        {
            SwitchCase: 1,
            VariableDeclarator: 1,
            outerIIFEBody: 1,
            MemberExpression: 1,
            FunctionDeclaration: {
                parameters: 1,
                body: 1,
            },
            FunctionExpression: {
                parameters: 1,
                body: 1,
            },
            CallExpression: {
                arguments: 1,
            },
            ArrayExpression: 1,
            ObjectExpression: 1,
        },
    ],
    // Запретить не нужные скобки
    // '@stylistic/no-extra-parens': [
    //     'warn',
    //     'all',
    //     {
    //         conditionalAssign: true,
    //         nestedBinaryExpressions: false,
    //         returnAssign: false,
    //         ignoreJSX: 'all',
    //     },
    // ],
    // Обеспечьте одинаковый интервал до и после ключевых слов
    '@stylistic/keyword-spacing': [
        'warn',
        {
            before: true,
            after: true,
            overrides: {
                return: { after: true },
                throw: { after: true },
                case: { after: true },
            },
        },
    ],
    // Обеспечить последовательное использование обратных кавычек, двойных или одинарных кавычек
    '@stylistic/quotes': [
        'warn',
        'single',
        { avoidEscape: true, allowTemplateLiterals: false },
    ],
    // Обеспечивает постоянный интервал перед скобками функций
    '@stylistic/space-before-function-paren': ['warn', 'always'],
    // Это правило направлено на обеспечение наличия пробелов вокруг инфиксных операторов.
    '@stylistic/space-infix-ops': [
        'warn',
        {
            int32Hint: true,
        },
    ],

    // Чтобы не было двойных пробелов
    'no-multi-spaces': 'error',
    // максимальное кол-во символов в строке
    'max-len': ['error', 120],
    'array-element-newline': ['error', 'consistent'],
    // indent: ["error", 4],
    quotes: ['error', 'single', { allowTemplateLiterals: true }],
    'brace-style': ['error', '1tbs', { allowSingleLine: true }],
    'react/react-in-jsx-scope': 'off',
    // Обеспечить постоянный интервал внутри скобок {}
    'object-curly-spacing': ['error', 'always', { objectsInObjects: false }],
    // Чтобы в onClick и подобных не объявлять ф-ии
    'no-restricted-syntax': [
        'error',
        {
            selector:
                'JSXAttribute[name.name=/^on[A-Z]/] > JSXExpressionContainer > ArrowFunctionExpression, JSXAttribute[name.name=/^on[A-Z]/] > JSXExpressionContainer > FunctionExpression',
            message:
                'Не объявляйте функции прямо в `onClick`/`onChange`. Вынесите их в отдельную функцию.',
        },
    ],
    'arrow-spacing': ['warn', { before: true, after: true }]
}
