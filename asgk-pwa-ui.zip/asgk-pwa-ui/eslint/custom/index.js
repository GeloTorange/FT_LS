import { customRules } from './rules.js'
import { ignores } from '../ignores.js'
import unusedImports from 'eslint-plugin-unused-imports'
import eslintConfigPrettier from 'eslint-config-prettier'
import { noUnreasonableDisable } from './no-unreasonable-disable.js'


export const customLintConfig = {
    plugins: {
        'unused-imports': unusedImports,
        custom: {
            rules: {
                'no-unreasonable-disable': noUnreasonableDisable,
            }
        }
    },
    files: ['src/**/*.{js{,x},ts{,x}}'],
    rules: {
        ...eslintConfigPrettier.rules,
        ...customRules,
        // Включаем правило для удаления неиспользуемых импортов
        'unused-imports/no-unused-imports': 'error',
        // Чтобы был коммент если eslint-disable
        'custom/no-unreasonable-disable': 'warn',
    },
    ignores,
}
