export default {
    // Require that member overloads be consecutive
    '@typescript-eslint/adjacent-overload-signatures': 'error',
    // Требуется использовать T[] для массивов вместо Array<T>
    '@typescript-eslint/array-type': [
        'warn',
        {
            default: 'array',
            readonly: 'array',
        },
    ],
    // Bans @ts-<directive> comments from being used or requires descriptions after directive
    '@typescript-eslint/ban-ts-comment': 'error',
    // Bans // tslint:<rule-flag> comments from being used
    '@typescript-eslint/ban-tslint-comment': 'error',
    // корректное описание объекта
    '@typescript-eslint/no-empty-object-type': 'error',
    // ф-ий
    '@typescript-eslint/no-unsafe-function-type': 'error',
    // и базовых типов
    '@typescript-eslint/no-wrapper-object-types': 'error',
    // Ensures that literals on classes are exposed in a consistent style
    '@typescript-eslint/class-literal-property-style': 'off',
    // Enforce or disallow the use of the record type
    '@typescript-eslint/consistent-indexed-object-style': 'off',
    // Enforces consistent usage of type assertions
    '@typescript-eslint/consistent-type-assertions': 'off',
    // Consistent with type definition either interface or type
    '@typescript-eslint/consistent-type-definitions': 'off',
    // Enforces consistent usage of type exports
    '@typescript-eslint/consistent-type-exports': 'warn',
    // Enforces consistent usage of type imports
    '@typescript-eslint/consistent-type-imports': 'warn',
    // Требовать явных возвращаемых типов для функций и методов класса
    '@typescript-eslint/explicit-function-return-type': 'off',
    // Require explicit accessibility modifiers on class properties and methods
    '@typescript-eslint/explicit-member-accessibility': 'off',
    // Требовать явного указания типов возвращаемых значений и аргументов для экспортируемых функций и публичных методов классов
    '@typescript-eslint/explicit-module-boundary-types': 'off',
    // Require a consistent member declaration order
    '@typescript-eslint/member-ordering': 'off',
    // Enforces using a particular method signature syntax.
    '@typescript-eslint/method-signature-style': 'off',
    // Enforces naming conventions for
    // typeLike - class, interface, typeAlias, enum, typeParameter
    // across a codebase
    '@typescript-eslint/naming-convention': [
        'warn',
        {
            selector: 'typeLike',
            format: ['PascalCase'],
        },
    ],
    // Requires that .toString() is only called on objects which provide useful information when stringified
    '@typescript-eslint/no-base-to-string': 'off',
    // Disallow non-null assertion in locations that may be confusing
    '@typescript-eslint/no-confusing-non-null-assertion': 'error',
    // Requires expressions of type void to appear in statement position
    '@typescript-eslint/no-confusing-void-expression': 'warn',
    // Disallow the delete operator with computed key expressions
    '@typescript-eslint/no-dynamic-delete': 'off',
    // Disallow the declaration of empty interfaces
    '@typescript-eslint/no-empty-interface': 'error',
    // Disallow usage of the any type
    '@typescript-eslint/no-explicit-any': 'warn',
    // Disallow extra non-null assertion
    '@typescript-eslint/no-extra-non-null-assertion': 'error',
    // Forbids the use of classes as namespaces
    '@typescript-eslint/no-extraneous-class': 'off',
    // Disallows explicit type declarations for variables or parameters initialized to a number, string, or boolean
    '@typescript-eslint/no-inferrable-types': 'error',
    // Disallows usage of void type outside of generic or return types
    '@typescript-eslint/no-invalid-void-type': 'off',
    // Enforce valid definition of new and constructor
    '@typescript-eslint/no-misused-new': 'error',
    // Disallow the use of custom TypeScript modules and namespaces
    '@typescript-eslint/no-namespace': 'error',
    // Disallows using a non-null assertion after an optional chain expression
    '@typescript-eslint/no-non-null-asserted-optional-chain': 'error',
    // Disallows non-null assertions using the ! postfix operator
    '@typescript-eslint/no-non-null-assertion': 'warn',
    // Require or disallow parameter properties in class constructors
    '@typescript-eslint/parameter-properties': 'off',
    // Disallows invocation of require()
    '@typescript-eslint/no-require-imports': 'off',
    // Disallow aliasing this
    '@typescript-eslint/no-this-alias': 'error',
    // Disallow the use of type aliases
    '@typescript-eslint/no-type-alias': 'off',
    // Flags unnecessary equality comparisons against boolean literals
    '@typescript-eslint/no-unnecessary-boolean-literal-compare': 'warn',
    // TODO: Вернуть это правило в режим warn и проверить все места где изменилось.
    // Выкл так как не всегда правда.
    // Предотвращает условные операторы, тип которых всегда истинен или всегда ложен
    '@typescript-eslint/no-unnecessary-condition': 'off',
    // Warns when a namespace qualifier is unnecessary
    '@typescript-eslint/no-unnecessary-qualifier': 'off',
    // Enforces that type arguments will not be used if not required
    '@typescript-eslint/no-unnecessary-type-arguments': 'off',
    // Disallows unnecessary constraints on generic types
    '@typescript-eslint/no-unnecessary-type-constraint': 'warn',
    // Disallows calling an function with an any type value
    '@typescript-eslint/no-unsafe-argument': 'off',
    // Disallows the use of require statements except in import statements
    '@typescript-eslint/no-var-requires': 'error',
    // Prefers a non-null assertion over explicit type cast when possible
    '@typescript-eslint/non-nullable-type-assertion-style': 'off',
    // Prefer usage of as const over literal type
    '@typescript-eslint/prefer-as-const': 'error',
    // Prefer initializing each enums member value
    '@typescript-eslint/prefer-enum-initializers': 'off',
    // Prefer a ‘for-of’ loop over a standard ‘for’ loop if the index is only used to access the array being iterated
    '@typescript-eslint/prefer-for-of': 'off',
    // Use function types instead of interfaces with call signatures
    '@typescript-eslint/prefer-function-type': 'off',
    // Enforce includes method over indexOf method
    '@typescript-eslint/prefer-includes': 'off',
    // Require that all enum members be literal values to prevent unintended enum member name shadow issues
    '@typescript-eslint/prefer-literal-enum-member': 'off',
    // Require the use of the namespace keyword instead of the module keyword to declare custom TypeScript modules
    '@typescript-eslint/prefer-namespace-keyword': 'error',
    // Enforce the usage of the nullish coalescing operator instead of logical chaining
    '@typescript-eslint/prefer-nullish-coalescing': 'off',
    // Prefer using concise optional chain expressions instead of chained logical ands
    '@typescript-eslint/prefer-optional-chain': 'off',
    // Requires that private members are marked as readonly if they're never modified outside of the constructor
    '@typescript-eslint/prefer-readonly': 'off',
    // Requires that function parameters are typed as readonly to prevent accidental mutation of inputs
    '@typescript-eslint/prefer-readonly-parameter-types': 'off',
    // Prefer using type parameter when calling Array#reduce instead of casting
    '@typescript-eslint/prefer-reduce-type-parameter': 'off',
    // Enforce that this is used when only this type is returned
    '@typescript-eslint/prefer-return-this-type': 'off',
    // Enforce the use of String#startsWith and String#endsWith instead of other equivalent methods of checking substrings
    '@typescript-eslint/prefer-string-starts-ends-with': 'off',
    // Recommends using @ts-expect-error over @ts-ignore
    '@typescript-eslint/prefer-ts-expect-error': 'off',
    // Requires any function or method that returns a Promise to be marked async
    '@typescript-eslint/promise-function-async': 'off',
    // Requires Array#sort calls to always provide a compareFunction
    '@typescript-eslint/require-array-sort-compare': 'off',
    // Enforce constituents of a type union/intersection to be sorted alphabetically.
    '@typescript-eslint/sort-type-constituents': 'off',
    // Restricts the types allowed in boolean expressions
    '@typescript-eslint/strict-boolean-expressions': 'off',
    // Exhaustiveness checking in switch with union type
    '@typescript-eslint/switch-exhaustiveness-check': 'off',
    // Sets preference level for triple slash directives versus ES6-style import declarations
    '@typescript-eslint/triple-slash-reference': 'error',
    // Require consistent spacing around type annotations
    '@typescript-eslint/type-annotation-spacing': 'off',
    // Requires type annotations to exist
    '@typescript-eslint/typedef': 'off',
    // Warns for any two overloads that could be unified into one by using a union or an optional/rest parameter
    '@typescript-eslint/unified-signatures': 'off',

    /*
      This is a requiring type checking ruleset
      */

    // Disallows awaiting a value that is not a Thenable
    '@typescript-eslint/await-thenable': 'error',
    // Выключил потому что все промисы обрабатываются в requestWrapper.
    // Требует надлежащей обработки значений типа Promise.
    '@typescript-eslint/no-floating-promises': 'off',
    // Disallow iterating over an array with a for-in loop
    '@typescript-eslint/no-for-in-array': 'error',
    // Выключил, стоит включить если нужно сделать надежнее код.
    // Избегайте использования обещаний в местах, не предназначенных для их обработки.
    '@typescript-eslint/no-misused-promises': 'off',
    // Warns if a type assertion does not change the type of an expression
    '@typescript-eslint/no-unnecessary-type-assertion': 'error',
    // Disallows assigning any to variables and properties
    '@typescript-eslint/no-unsafe-assignment': 'error',
    // Disallows calling an any type value
    '@typescript-eslint/no-unsafe-call': 'error',
    // Disallows member access on any typed variables
    '@typescript-eslint/no-unsafe-member-access': 'error',
    // Disallows returning any from a function
    '@typescript-eslint/no-unsafe-return': 'error',
    // Enforce that RegExp#exec is used instead of String#match if no global flag is provided
    '@typescript-eslint/prefer-regexp-exec': 'error',
    // When adding two variables, operands must both be of type number or of type string
    '@typescript-eslint/restrict-plus-operands': 'error',
    // Enforce template literal expressions to be of string type
    '@typescript-eslint/restrict-template-expressions': 'error',
    // Enforces unbound methods are called with their expected scope
    '@typescript-eslint/unbound-method': 'error',

    /*
      This is a compatibility ruleset that:
          - disables rules from eslint:recommended which are already handled by TypeScript.
          - enables rules that make sense due to TS's typechecking / transpilation.
      */

    'constructor-super': 'off', // ts(2335) & ts(2377)
    'getter-return': 'off', // ts(2378)
    'no-const-assign': 'off', // ts(2588)
    'no-dupe-args': 'off', // ts(2300)
    'no-dupe-keys': 'off', // ts(1117)
    'no-func-assign': 'off', // ts(2539)
    'no-import-assign': 'off', // ts(2539) & ts(2540)
    'no-new-symbol': 'off', // ts(2588)
    'no-obj-calls': 'off', // ts(2349)
    'no-setter-return': 'off', // ts(2408)
    'no-this-before-super': 'off', // ts(2376)
    'no-undef': 'off', // ts(2304)
    'no-unreachable': 'off', // ts(7027)
    'no-unsafe-negation': 'off', // ts(2365) & ts(2360) & ts(2358)
    'no-var': 'error', // ts transpiles let/const to var, so no need for vars any more
    'prefer-const': 'error', // ts provides better types with const
    'prefer-rest-params': 'error', // ts provides better types with rest args over arguments
    'prefer-spread': 'error', // ts transpiles spread to apply, so no need for manual apply
    'valid-typeof': 'off', // ts(2367)
    // Отлючаем обязательность в описании типов в jsdoc, так как описываем типы в TS
    'valid-jsdoc': [
        'warn',
        {
            prefer: {
                arg: 'param',
                argument: 'param',
                returns: 'return',
                abstract: 'virtual',
            },
            preferType: {
                function: 'Function',
                boolean: 'Boolean',
                number: 'Number',
                array: 'Array',
                object: 'Object',
                string: 'String',
                moment: 'Moment',
                date: 'Date',
            },
            requireParamType: false,
            requireReturnType: false,
        },
    ],

    /*
      In some cases, ESLint provides a rule itself, but it doesn't support TypeScript syntax
      either it crashes, or it ignores the syntax, or it falsely reports against it.
      In these cases, we create what we call an extension rule
      a rule within our plugin that has the same functionality, but also supports TypeScript.
      */
    'comma-dangle': 'off',
    'default-param-last': 'off',
    'dot-notation': 'off',
    'func-call-spacing': 'off',
    'init-declarations': 'off',
    'keyword-spacing': 'off',
    'lines-between-class-members': 'off',
    'no-array-constructor': 'off',
    'no-dupe-class-members': 'off',
    'no-duplicate-imports': 'off',
    'no-empty-function': 'off',
    'no-implied-eval': 'off',
    'no-invalid-this': 'off',
    'no-loop-func': 'off',
    'no-loss-of-precision': 'off',
    'no-magic-numbers': 'off',
    'no-redeclare': 'off',
    'no-shadow': 'off',
    'no-throw-literal': 'off',
    'babel/no-unused-expressions': 'off',
    'no-unused-vars': 'off',
    'no-use-before-define': 'off',
    'no-useless-constructor': 'off',
    'babel/quotes': 'off',
    'require-await': 'off',
    'return-await': 'off',
    semi: 'off',
    'space-before-function-paren': 'off',
    'space-infix-ops': 'off',
    'react/prop-types': 'off',
    /**
     * Требует написание лишнего кода для описания defaultProps. Не учитывает наличие обработки внутри функции
     * Данная проверка на опциональность (undefined) итак учитывается TypeScript.
     */
    'react/require-default-props': 'off',

    // Require or disallow trailing comma
    '@typescript-eslint/comma-dangle': [
        'off',
        {
            arrays: 'only-multiline',
            objects: 'always-multiline',
            imports: 'only-multiline',
            exports: 'only-multiline',
            functions: 'never',
        },
    ],
    // Enforce default parameters to be last
    '@typescript-eslint/default-param-last': 'warn',
    // enforce dot notation whenever possible
    '@typescript-eslint/dot-notation': ['warn', { allowKeywords: true }],
    // require or disallow initialization in variable declarations
    '@typescript-eslint/init-declarations': 'off',
    // Require or disallow an empty line between class members
    '@typescript-eslint/lines-between-class-members': 'off',
    // Disallow generic Array constructors
    '@typescript-eslint/no-array-constructor': 'error',
    // Disallow duplicate class members
    '@typescript-eslint/no-dupe-class-members': 'error',
    // Disallow empty functions
    '@typescript-eslint/no-empty-function': [
        'error',
        {
            allow: ['arrowFunctions', 'functions', 'methods'],
        },
    ],
    // Disallow the use of eval()-like methods
    '@typescript-eslint/no-implied-eval': 'error',
    // Disallow this keywords outside of classes or class-like objects
    '@typescript-eslint/no-invalid-this': 'off',
    // Disallow function declarations that contain unsafe references inside loop statements
    '@typescript-eslint/no-loop-func': 'error',
    // Disallow literal numbers that lose precision
    '@typescript-eslint/no-loss-of-precision': 'error',
    // TODO: обсудить
    // Выключил, но надо обсудить. Запретить магические числа
    '@typescript-eslint/no-magic-numbers': [
        'off',
        {
            ignore: [0, 1, -1, 100],
            ignoreArrayIndexes: false,
            enforceConst: true,
            detectObjects: false,
        },
    ],
    // Disallow variable redeclaration
    '@typescript-eslint/no-redeclare': 'error',
    // Disallow variable declarations from shadowing variables declared in the outer scope
    '@typescript-eslint/no-shadow': 'warn',
    // Disallow throwing literals as exceptions
    '@typescript-eslint/only-throw-error': 'error',
    // Disallow unused expressions
    '@typescript-eslint/no-unused-expressions': [
        'error',
        {
            allowShortCircuit: false,
            allowTernary: false,
        },
    ],
    // Disallow unused variables
    '@typescript-eslint/no-unused-vars': [
        'warn',
        {
            vars: 'local',
            args: 'after-used',
        },
    ],
    // Disallow the use of variables before they are defined
    '@typescript-eslint/no-use-before-define': 'error',
    // Disallow unnecessary constructors
    '@typescript-eslint/no-useless-constructor': 'error',
    // Disallow async functions which have no await expression
    '@typescript-eslint/require-await': 'off',
    // Enforces consistent returning of awaited values
    '@typescript-eslint/return-await': 'error',
}
