import tsEslint from 'typescript-eslint'
import globals from 'globals'
import rules from './rules.js'

const languageOptions = {
    parser: tsEslint.parser,
    parserOptions: {
        ecmaVersion: 'latest',
        // Показывает на какие файлы смотреть и не смотреть
        project: './tsconfig.eslint.json',
    // projectService: true
    },
    globals: {
        ...globals.browser,
        ...globals.node,
        ...globals.es2020,
    },
}

/** @type {import('eslint').Linter.FlatConfig[]} */
export const typescriptLintConfig = [
    ...tsEslint.configs.recommended,
    {
        name: 'typescript-sbol',
        files: ['src/**/*.ts', 'src/**/*.tsx'],
        languageOptions,
        rules,
    },
    {
        name: 'typescript-sbol-test',
        files: ['**/*.spec.ts', '**/*.spec.tsx', '**/*.test.ts', '**/*.test.tsx'],
        languageOptions,
        rules: {
            ...rules,
            'no-console': 'off',
            'no-magic-numbers': 'off',
            'no-mixed-operators': 'off',
            'no-underscore-dangle': 'off',
            'sonarjs/no-duplicate-string': 'off',
            '@typescript-eslint/unbound-method': 'off',
        },
    },
]
