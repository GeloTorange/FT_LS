export default {
    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/catch-error-name.md
    // Принудительно задает определенное имя параметра в блоках catch.
    // TODO: в текущем виде линтинг падает, если использовать имя переменной e
    'unicorn/catch-error-name': [
        'off',
        { caughtErrorsIgnorePattern: '^(e|error)$' },
    ],

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/explicit-length-check.md
    // Требует явного сравнения свойства length.
    // TODO: Обсудить это!
    'unicorn/explicit-length-check': 'off',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/filename-case.md
    // Задает стиль именования файлов.
    // "unicorn/filename-case": ["warn", { case: "kebabCase" }],

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/no-abusive-eslint-disable.md
    // Требует указания правил для отключения в комментариях eslint-disable.
    'unicorn/no-abusive-eslint-disable': 'warn',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/no-process-exit.md
    // Запрещает использование process.exit().
    'unicorn/no-process-exit': 'error',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/throw-new-error.md
    // Требует использования new при выбросе ошибки.
    'unicorn/throw-new-error': 'error',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/number-literal-case.md
    // Задает нижний регистр для идентификатора и верхний регистр для числовых литералов.
    'unicorn/number-literal-case': 'error',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/escape-case.md
    // Требует использования заглавных букв в escape-последовательностях.
    'unicorn/escape-case': 'warn',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/no-array-instanceof.md
    // Требует использования Array.isArray() вместо instanceof Array.
    'unicorn/no-instanceof-array': 'warn',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/no-new-buffer.md
    // Требует использования Buffer.from() и Buffer.alloc() вместо устаревшего new Buffer().
    'unicorn/no-new-buffer': 'error',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/no-hex-escape.md
    // Требует использования Unicode escape-последовательностей вместо шестнадцатеричных.
    'unicorn/no-hex-escape': 'error',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/custom-error-definition.md
    // Обеспечивает правильное наследование от Error.
    'unicorn/custom-error-definition': 'warn',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/prefer-starts-ends-with.md
    // Предпочитает String#startsWith и String#endsWith вместо более сложных альтернатив.
    // TODO: IE11, полифил
    'unicorn/prefer-starts-ends-with': 'off',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/prefer-type-error.md
    // Требует выброса TypeError в условиях проверки типов.
    'unicorn/prefer-type-error': 'error',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/no-fn-reference-in-iterator.md
    // Запрещает передачу ссылки на функцию напрямую в методы итератора.
    'unicorn/no-fn-reference-in-iterator': 'off',

    // export {} from './foo', вместо импорта и потом экспорта
    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/main/docs/rules/prefer-export-from.md
    'unicorn/prefer-export-from': ['error', { ignoreUsedVariables: true }],

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/new-for-builtins.md
    // Требует использования new для всех встроенных объектов, кроме String, Number и Boolean.
    'unicorn/new-for-builtins': 'error',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/better-regex.md
    // Требует использования сокращенных форм regex для улучшения читаемости.
    'unicorn/better-regex': 'warn',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/prefer-spread.md
    // Выкл. Предпочитает оператор расширения (...) вместо Array.from().
    'unicorn/prefer-spread': 'off',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/error-message.md
    // Требует передачи сообщения при выбросе встроенной ошибки.
    'unicorn/error-message': 'error',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/prefer-add-event-listener.md
    // Предпочитает addEventListener вместо on-функций.
    'unicorn/prefer-add-event-listener': 'error',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/prefer-exponentiation-operator.md
    // Предпочитает оператор возведения в степень (**) вместо Math.pow().
    // TODO: babel
    'unicorn/prefer-exponentiation-operator': 'off',

    // https://github.com/sindresorhus/eslint-plugin-unicorn/blob/master/docs/rules/no-console-spaces.md
    // Запрещает использование начальных/конечных пробелов между параметрами console.log.
    'unicorn/no-console-spaces': 'off',
}
