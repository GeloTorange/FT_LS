import bestPractice from './best-practices.js'
import possibleErrors from './possible-errors.js'
// import promise from './promise.js'
import sonarjs from './sonarjs.js'
import stylistic from './stylistic.js'
import unicorn from './unicorn.js'
import variables from './variables.js'
import { ignores } from '../../ignores.js'
import globals from 'globals'

const coreRules = {
    ...bestPractice,
    ...possibleErrors,
    // ...promise,
    ...sonarjs,
    ...stylistic,
    ...unicorn,
    ...variables,
}

export const coreLintConfig = {
    rules: coreRules,
    // чтобы в js и тестах eslint знал про window, global и пр.
    languageOptions: {
        ecmaVersion: 2021,
        sourceType: 'module',
        parserOptions: {
            ecmaFeatures: {
                generators: false,
                objectLiteralDuplicateProperties: false,
                arrowFunctions: true,
                blockBindings: true,
                classes: true,
                defaultParams: true,
                destructuring: true,
                modules: true,
                objectLiteralShorthandMethods: true,
                objectLiteralShorthandProperties: true,
                spread: true,
                templateStrings: true,
                experimentalObjectRestSpread: true,
            },
        },
        globals: {
            ...globals.browser,
            ...globals.node,
            ...globals.es2020,
        },
    },
    ignores
}
