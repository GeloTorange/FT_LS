import reactPlugin from 'eslint-plugin-react'
import reactHooksPlugin from 'eslint-plugin-react-hooks'
import typescriptParser from '@typescript-eslint/parser'
import { reactRules } from './rules/react.js'
import { reactHooksRules } from './rules/react-hooks.js'

export const reactLintConfig = {
    name: 'react-sbol',
    files: ['src/**/*.tsx'],
    plugins: {
        react: reactPlugin,
        'react-hooks': reactHooksPlugin
    },
    languageOptions: {
        parser: typescriptParser,
        parserOptions: {
            project: './tsconfig.eslint.json',
            jsxPragma: 'React',
            ecmaVersion: 'latest',
        }
    },
    settings: {
        react: {
            pragma: 'React',
            version: 'detect'
        }
    },
    rules: {
        ...reactRules,
        ...reactHooksRules
    }
}
