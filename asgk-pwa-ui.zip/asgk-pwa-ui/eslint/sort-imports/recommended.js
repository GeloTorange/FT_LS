import { layers } from './config.js'

const LAYERS_REVERSED = [...layers].reverse()

/** @type {import('eslint').Linter.FlatConfig[]} */
export default {
    rules: {
        'import/order': [
            'warn',
            {
                alphabetize: {
                    order: 'asc',
                    caseInsensitive: true,
                },
                'newlines-between': 'never',
                pathGroups: LAYERS_REVERSED.map((layer) => ({
                    pattern: `**/?(*)${layer}{,/**}`,
                    group: 'internal',
                    position: 'after',
                })),
                distinctGroup: false,
                pathGroupsExcludedImportTypes: ['builtin'],
                groups: ['builtin', 'external', 'internal', 'parent', 'sibling', 'index'],
            },
        ],
    },
}
