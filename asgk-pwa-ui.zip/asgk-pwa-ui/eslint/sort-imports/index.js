import recommended from './recommended.js'
import withNewLines from './withNewLines.js'
import importPlugin from 'eslint-plugin-import'

export const eslintSortImports = [
    importPlugin.flatConfigs.recommended,
    recommended,
    withNewLines
]
