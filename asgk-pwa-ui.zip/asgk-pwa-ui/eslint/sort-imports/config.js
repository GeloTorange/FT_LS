export const layers = ['shared', 'entities', 'features', 'widgets', 'pages', 'app']
