export const ignores = [
    '**/node_modules/**/*',
    'coverage/**/*',
    'src/react-app-env.d.ts',
    'src/vite-env.d.ts',
    'src/__mocks__/*',
    'src/__testsUtils__/svgMock.js',
]
    
