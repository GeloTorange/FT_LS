import js from '@eslint/js'
import tsEslint from 'typescript-eslint'
import eslintReact from 'eslint-plugin-react'
import eslintReactHooks from 'eslint-plugin-react-hooks'
import eslintReactRefresh from 'eslint-plugin-react-refresh'
import prettierPlugin from 'eslint-plugin-prettier'
import sonarjs from 'eslint-plugin-sonarjs'
import unicorn from 'eslint-plugin-unicorn'
import eslintFSD from './eslint/fsd.js'
import { eslintSortImports } from './eslint/sort-imports/index.js'
import { typescriptLintConfig } from './eslint/sbol-rules/typescript/index.js'
import { coreLintConfig } from './eslint/sbol-rules/core/index.js'
import { reactLintConfig } from './eslint/sbol-rules/react/index.js'
import stylistic from '@stylistic/eslint-plugin'
import { customLintConfig } from './eslint/custom/index.js'
import { vitestLintConfig } from './eslint/vitest.js'

/** @type {import('eslint').Linter.FlatConfig[]} */
export default tsEslint.config(
    {
        plugins: {
            '@typescript-eslint': tsEslint.plugin,
            react: eslintReact,
            'react-hooks': eslintReactHooks,
            'react-refresh': eslintReactRefresh,
            prettier: prettierPlugin,
            '@stylistic': stylistic,
            sonarjs: sonarjs,
            unicorn: unicorn,
        },
    },
    js.configs.recommended,
    coreLintConfig,
    reactLintConfig,
    ...typescriptLintConfig,
    customLintConfig,
    {
        files: ['src/**/*.{js{,x},ts{,x}}'],
        // чтобы в тестах на правила слоев не ругался
        ignores: ['src/**/*.test.{js{,x},ts{,x}}'],
        extends: [eslintFSD, ...eslintSortImports],
    },
    vitestLintConfig,
)
