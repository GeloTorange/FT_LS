# *.http.conf - добавляется в http секцию
# *.server.conf - добавляется в основную server секцию
