Content of this forlder will be deliver to /usr/local/openresty/nginx/conf/custom.d/ for customization IAMProxy.
This is test file.